# CSMA — Debian Deployment Guide

**Cybersecurity Maturity Assessment Framework**
Next.js 15 · PostgreSQL 16 · Prisma ORM

---

## Table of Contents

1. [Resource Requirements](#1-resource-requirements)
2. [Path A — Docker Compose (Recommended)](#2-path-a--docker-compose-recommended)
   - [2.1 Prerequisites](#21-prerequisites)
   - [2.2 Deploy Steps](#22-deploy-steps)
3. [Path B — Manual Bare-Metal](#3-path-b--manual-bare-metal)
   - [3.1 Prerequisites](#31-prerequisites)
   - [3.2 Deploy Steps](#32-deploy-steps)
4. [Production Hardening (Optional)](#4-production-hardening-optional)
   - [4.1 systemd Service](#41-systemd-service)
   - [4.2 Nginx Reverse Proxy](#42-nginx-reverse-proxy)
   - [4.3 Let's Encrypt TLS](#43-lets-encrypt-tls)
   - [4.4 Firewall (ufw)](#44-firewall-ufw)
   - [4.5 Security Notes](#45-security-notes)
5. [Default Seed Accounts](#5-default-seed-accounts)
6. [Troubleshooting](#6-troubleshooting)

---

## 1. Resource Requirements

| Tier | vCPU | RAM | Disk | Use Case |
|------|------|-----|------|----------|
| Minimum | 1 | 1 GB | 10 GB | Demo / development |
| Recommended | 2 | 2 GB | 20 GB | Production, small organisation |

> **Note:** The `npm run build` step is memory-intensive. If you have less than 2 GB RAM, set `NODE_OPTIONS=--max-old-space-size=2048` before building (see [Troubleshooting](#6-troubleshooting)).

**Database backups**

```bash
pg_dump csma_db > backup_$(date +%Y%m%d).sql
```

Store backups off-host (object storage, NAS, or equivalent). Schedule this with cron or your preferred backup tool.

---

## 2. Path A — Docker Compose (Recommended)

Docker Compose is the easiest and most reliable deployment method. It runs the app and database in isolated containers with a single command.

### 2.1 Prerequisites

**Fresh Debian 12 (Bookworm) host with a non-root sudo user.**

#### Install Docker Engine (official repo — do not use the distro package)

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg

sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg \
  | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/debian \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install -y \
  docker-ce docker-ce-cli containerd.io \
  docker-buildx-plugin docker-compose-plugin

# Allow your user to run Docker without sudo
sudo usermod -aG docker $USER
newgrp docker

# Verify
docker --version
docker compose version
```

#### Install Git

```bash
sudo apt-get install -y git
```

### 2.2 Deploy Steps

#### Step 1 — Copy the project to `/opt/csma`

If you have the project as a tarball or zip, extract it. If you are cloning from a repository:

```bash
sudo mkdir -p /opt/csma
sudo chown $USER:$USER /opt/csma
git clone <your-repo-url> /opt/csma
```

Or copy files directly from your local machine using `scp` or `rsync`:

```bash
# From your local machine
rsync -av --exclude=node_modules --exclude=.next \
  /path/to/csma/ user@your-server:/opt/csma/
```

#### Step 2 — Configure environment variables

```bash
cd /opt/csma
cp .env.example .env
```

Open `.env` with a text editor (e.g. `nano .env`) and set the following values:

```dotenv
# Database — points to the postgres container (hostname = "postgres" in Compose)
DATABASE_URL="postgresql://csma_user:csma_password@postgres:5432/csma_db"

# NextAuth — MUST be a strong random string, minimum 32 bytes
AUTH_SECRET="<generate below>"

# Public URLs — replace with your actual domain or server IP
NEXTAUTH_URL="http://your-domain.example.com"
NEXT_PUBLIC_APP_URL="http://your-domain.example.com"

# App defaults (keep as-is unless you need to change them)
NEXT_PUBLIC_APP_NAME="CSMA"
UPLOAD_DIR="./uploads"
MAX_FILE_SIZE_MB=10
SESSION_MAX_AGE=28800
```

Generate a strong `AUTH_SECRET`:

```bash
openssl rand -base64 32
```

Paste the output as the value for `AUTH_SECRET`. Do **not** leave the placeholder value.

> **Important:** The `.env` file contains credentials. It is excluded from version control by `.gitignore`. Never commit it.

#### Step 3 — Verify the `next.config.ts` standalone output setting

The Dockerfile builds a [Next.js standalone output](https://nextjs.org/docs/app/api-reference/config/next-config-js/output). Open `/opt/csma/next.config.ts` and confirm it contains `output: 'standalone'`:

```typescript
const nextConfig: NextConfig = {
  output: 'standalone',   // <-- this line must be present
  // ... rest of config
};
```

If the line is missing, add it before building:

```bash
# Quick check
grep "standalone" /opt/csma/next.config.ts

# If missing, add it (or edit the file manually with nano/vim):
sed -i "s/const nextConfig: NextConfig = {/const nextConfig: NextConfig = {\n  output: 'standalone',/" \
  /opt/csma/next.config.ts
```

#### Step 4 — Build and start all services

```bash
cd /opt/csma
docker compose up -d --build
```

The first run downloads the base images and builds the application. This can take 3–5 minutes depending on your internet connection and CPU. Subsequent starts are much faster.

#### Step 5 — Run database migrations and seed data

Wait for the containers to be healthy, then run:

```bash
# Check that both containers are up and healthy
docker compose ps

# Apply migrations
docker compose exec app npx prisma migrate deploy

# Seed with demo data and default accounts
docker compose exec app npx prisma db seed
```

> **Note:** The Dockerfile already runs `prisma migrate deploy` at container startup via its `CMD`. Running it manually here is a safe no-op if migrations have already been applied, but it is useful to verify the database connection is working correctly before seeding.

#### Step 6 — Verify and access

```bash
# Check container status
docker compose ps

# Tail application logs
docker compose logs app --tail=50

# Tail database logs
docker compose logs postgres --tail=20
```

You should see output like:

```
csma_app   | ✓ Ready in 2.3s
csma_app   | ○ Compiled / in ...
```

Open your browser at `http://<server-ip>:3000`.

#### Stopping and restarting

```bash
# Stop without removing containers or volumes
docker compose stop

# Start again
docker compose start

# Stop and remove containers (data volumes are preserved)
docker compose down

# Stop and remove everything including volumes (DESTROYS ALL DATA)
docker compose down -v
```

#### Updating to a new version

```bash
cd /opt/csma
git pull   # or copy new files

docker compose down
docker compose up -d --build

# Apply any new migrations
docker compose exec app npx prisma migrate deploy
```

---

## 3. Path B — Manual Bare-Metal

Use this path if you cannot or do not want to use Docker. You install Node.js and PostgreSQL directly on the host OS.

### 3.1 Prerequisites

**Fresh Debian 12 (Bookworm) host with a non-root sudo user.**

#### Install Node.js 20 LTS (via NodeSource)

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify
node --version   # should show v20.x.x
npm --version
```

#### Install PostgreSQL 16 (via official PGDG repo)

```bash
sudo apt-get install -y postgresql-common
sudo /usr/share/postgresql-common/pgdg/apt.postgresql.org.sh

sudo apt-get install -y postgresql-16
sudo systemctl enable --now postgresql

# Verify
sudo systemctl status postgresql
psql --version   # should show psql (PostgreSQL) 16.x
```

#### Create the database user and database

```bash
sudo -u postgres psql <<EOF
CREATE USER csma_user WITH PASSWORD 'csma_password';
CREATE DATABASE csma_db OWNER csma_user;
GRANT ALL PRIVILEGES ON DATABASE csma_db TO csma_user;
EOF
```

> **Security:** Change `csma_password` to a strong unique password and use the same value in your `.env` `DATABASE_URL`. Do not reuse the default.

### 3.2 Deploy Steps

#### Step 1 — Create the deployment user and copy the project

```bash
# Create a dedicated non-root user to run the app
sudo useradd -r -m -s /bin/bash csma

# Create the app directory and set ownership
sudo mkdir -p /opt/csma
sudo chown csma:csma /opt/csma
```

Copy or clone the project files into `/opt/csma`. Then fix ownership:

```bash
sudo chown -R csma:csma /opt/csma
```

#### Step 2 — Install dependencies

```bash
cd /opt/csma
sudo -u csma npm install --legacy-peer-deps --omit=dev
```

`--legacy-peer-deps` is required because some Radix UI and React 19 peer dependency declarations are not yet fully aligned.

#### Step 3 — Configure environment variables

```bash
sudo -u csma cp /opt/csma/.env.example /opt/csma/.env
sudo -u csma nano /opt/csma/.env   # or use vim, etc.
```

Set the following values:

```dotenv
# Database — points to the local PostgreSQL instance
DATABASE_URL="postgresql://csma_user:csma_password@localhost:5432/csma_db"

# NextAuth — MUST be a strong random string, minimum 32 bytes
AUTH_SECRET="<generate below>"

# Public URLs
NEXTAUTH_URL="http://your-domain.example.com"
NEXT_PUBLIC_APP_URL="http://your-domain.example.com"

# App defaults
NEXT_PUBLIC_APP_NAME="CSMA"
UPLOAD_DIR="./uploads"
MAX_FILE_SIZE_MB=10
SESSION_MAX_AGE=28800
```

Generate a strong `AUTH_SECRET`:

```bash
openssl rand -base64 32
```

Set permissions so only the `csma` user can read the file:

```bash
sudo chmod 600 /opt/csma/.env
sudo chown csma:csma /opt/csma/.env
```

#### Step 4 — Generate Prisma client and apply migrations

```bash
cd /opt/csma
sudo -u csma npx prisma generate
sudo -u csma npx prisma migrate deploy
```

#### Step 5 — Seed the database

```bash
cd /opt/csma
sudo -u csma npx prisma db seed
```

This creates demo data and the default user accounts. See [Default Seed Accounts](#5-default-seed-accounts) for credentials — **change them immediately after first login**.

#### Step 6 — Build the application

> If the build runs out of memory, prefix with `NODE_OPTIONS=--max-old-space-size=2048`.

```bash
cd /opt/csma
sudo -u csma npm run build
```

The build output goes to `/opt/csma/.next/`. This step takes 1–3 minutes.

#### Step 7 — Start the application

```bash
cd /opt/csma
sudo -u csma npm start
```

By default Next.js binds to port 3000. Open your browser at `http://<server-ip>:3000`.

To run as a persistent background service, continue to [Section 4.1 — systemd Service](#41-systemd-service).

---

## 4. Production Hardening (Optional)

The steps below turn the bare-metal install into a proper production service with process supervision, TLS termination, and a firewall. Apply them after completing Path B.

### 4.1 systemd Service

Create the unit file:

```bash
sudo nano /etc/systemd/system/csma.service
```

Paste the following content:

```ini
[Unit]
Description=CSMA Next.js App
After=network.target postgresql.service

[Service]
Type=simple
User=csma
WorkingDirectory=/opt/csma
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=csma
EnvironmentFile=/opt/csma/.env
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=HOSTNAME=127.0.0.1

[Install]
WantedBy=multi-user.target
```

> **Note:** `HOSTNAME=127.0.0.1` binds Next.js to localhost only. Nginx (configured below) handles public traffic. Do not bind to `0.0.0.0` in production unless you have a separate firewall rule blocking port 3000 from the internet.

Enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now csma

# Verify
sudo systemctl status csma
```

### 4.2 Nginx Reverse Proxy

#### Install Nginx

```bash
sudo apt-get install -y nginx
sudo systemctl enable --now nginx
```

#### Create the site configuration

```bash
sudo nano /etc/nginx/sites-available/csma
```

Paste the following (replace `your-domain.example.com` with your actual domain):

```nginx
server {
    listen 80;
    server_name your-domain.example.com;

    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade            $http_upgrade;
        proxy_set_header   Connection         'upgrade';
        proxy_set_header   Host               $host;
        proxy_set_header   X-Real-IP          $remote_addr;
        proxy_set_header   X-Forwarded-For    $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto  $scheme;
        proxy_cache_bypass $http_upgrade;
        client_max_body_size 20M;
    }
}
```

Enable the site and test:

```bash
sudo ln -s /etc/nginx/sites-available/csma /etc/nginx/sites-enabled/csma
sudo nginx -t       # should print "syntax is ok" and "test is successful"
sudo systemctl reload nginx
```

### 4.3 Let's Encrypt TLS

> Requires a DNS A record for `your-domain.example.com` pointing to this server's public IP, and port 80 open from the internet.

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.example.com
```

Certbot will automatically edit the Nginx config to add HTTPS and redirect HTTP to HTTPS.

Test automatic renewal:

```bash
sudo certbot renew --dry-run
```

Certbot installs a systemd timer that renews certificates automatically. No manual action is needed.

After obtaining the certificate, update your `.env` to use HTTPS:

```dotenv
NEXTAUTH_URL="https://your-domain.example.com"
NEXT_PUBLIC_APP_URL="https://your-domain.example.com"
```

Then restart the app:

```bash
sudo systemctl restart csma
```

### 4.4 Firewall (ufw)

```bash
sudo apt-get install -y ufw

sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'   # allows ports 80 and 443

sudo ufw enable

# Verify
sudo ufw status verbose
```

> **Do not** add a rule for port 3000. The app should only be accessible through Nginx.

### 4.5 Security Notes

| Item | Action |
|------|--------|
| Port 3000 | Never expose publicly — Nginx terminates all inbound traffic |
| Default seed passwords | Change immediately after first login (see [Section 5](#5-default-seed-accounts)) |
| `AUTH_SECRET` | Must be a minimum 32-byte random string; rotate if compromised |
| App user | Always run as the non-root `csma` user, never as root |
| PostgreSQL access | Edit `/etc/postgresql/16/main/pg_hba.conf` to restrict connections to `localhost` only; reload with `sudo systemctl reload postgresql` |
| OS patches | Run `sudo apt-get update && sudo apt-get upgrade` regularly; consider unattended-upgrades for security patches |
| `.env` permissions | Keep `chmod 600 /opt/csma/.env` so only the `csma` user can read credentials |
| Uploads directory | Store user-uploaded files outside the web root if possible; ensure the directory is not served directly by Nginx |

---

## 5. Default Seed Accounts

Running `npx prisma db seed` creates the following accounts with demo data:

| Role | Email | Default Password |
|------|-------|-----------------|
| Admin | `admin@csma.local` | `Admin@1234!` |
| Assessor | `assessor@csma.local` | `Assessor@1234!` |
| Customer | `alice@acme.com` | `Customer@1234!` |
| Customer | `bob@globaltech.com` | `Customer@1234!` |

**Change all passwords immediately after your first login.**

The seed also creates three demo customer profiles (ACME Corporation, GlobalTech Industries, HealthFirst Medical) and several completed assessments based on NIST CSF and ISO 27001 templates. You can delete the demo data through the admin interface once you have set up your real data.

---

## 6. Troubleshooting

### View application logs

```bash
# Docker Compose
docker compose logs app --tail=100

# systemd (bare-metal)
journalctl -u csma -f
```

### Check Prisma migration status

```bash
# Docker Compose
docker compose exec app npx prisma migrate status

# Bare-metal
cd /opt/csma && sudo -u csma npx prisma migrate status
```

### Port 3000 already in use

```bash
ss -tlnp | grep 3000
```

Identify and stop the conflicting process, or change the `PORT` in your `.env` and systemd unit.

### PostgreSQL connection refused

```bash
# Check the service is running
sudo systemctl status postgresql

# Test the connection manually
psql -h localhost -U csma_user -d csma_db

# Check pg_hba.conf allows local password auth
sudo grep -E "csma|md5|scram" /etc/postgresql/16/main/pg_hba.conf
```

If you see `peer` authentication instead of `md5` or `scram-sha-256` for localhost connections, edit `pg_hba.conf` and reload:

```bash
sudo systemctl reload postgresql
```

### Permission denied on uploads directory

```bash
sudo chown -R csma:csma /opt/csma/uploads
sudo chmod 755 /opt/csma/uploads
```

Or for Docker Compose, the uploads volume is managed automatically. If permissions are wrong inside the container:

```bash
docker compose exec app chown -R nextjs:nodejs /app/uploads
```

### "Module not found" or missing dependency after deploy

```bash
cd /opt/csma
sudo -u csma npm install --legacy-peer-deps
```

### Build fails with out-of-memory error

```bash
cd /opt/csma
sudo -u csma NODE_OPTIONS=--max-old-space-size=2048 npm run build
```

### Docker build fails — cannot find `.next/standalone`

The Dockerfile copies from `.next/standalone`, which requires `output: 'standalone'` in `next.config.ts`. Check and fix:

```bash
grep "standalone" /opt/csma/next.config.ts
```

If missing, open `/opt/csma/next.config.ts` and add `output: 'standalone'` inside the `nextConfig` object, then rebuild:

```bash
docker compose up -d --build
```

### Database is empty after container restart

Named Docker volumes persist data across restarts. If you used `docker compose down -v`, the volumes were deleted. Re-run migrations and seed:

```bash
docker compose exec app npx prisma migrate deploy
docker compose exec app npx prisma db seed
```

### Nginx returns 502 Bad Gateway

The app is not running or not listening on port 3000.

```bash
# Check app status
sudo systemctl status csma

# Check what is listening on 3000
ss -tlnp | grep 3000

# Restart if needed
sudo systemctl restart csma
```

### NextAuth errors — "AUTH_SECRET is not defined"

The `.env` file is missing or the `AUTH_SECRET` variable is empty. Verify:

```bash
grep AUTH_SECRET /opt/csma/.env
```

Generate and set a value:

```bash
echo "AUTH_SECRET=$(openssl rand -base64 32)" >> /opt/csma/.env
sudo systemctl restart csma
```

---

*Guide version: May 2026. Covers CSMA v1.0.0 on Debian 12 (Bookworm).*
