#!/usr/bin/env bash
# =============================================================================
# CSMA — Server-side installation script
# Runs on a fresh Debian 12 host (as root or via sudo).
# Uploaded and executed automatically by deploy-to-server.sh
# =============================================================================
set -euo pipefail

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${BLUE}[•]${RESET} $*"; }
success() { echo -e "${GREEN}[✓]${RESET} $*"; }
warn()    { echo -e "${YELLOW}[!]${RESET} $*"; }
step()    { echo; echo -e "${BOLD}${BLUE}━━ $* ${RESET}"; }
die()     { echo -e "${RED}[✗]${RESET} $*" >&2; exit 1; }

# ── Must run as root ─────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
  die "This script must be run as root (or via sudo)."
fi

# ── Config ───────────────────────────────────────────────────────────────────
INSTALL_DIR="/opt/csma"
TARBALL="/tmp/csma_deploy.tar.gz"
APP_USER="csma"
COMPOSE_PROJECT="csma"

# ── Banner ────────────────────────────────────────────────────────────────────
echo -e "${BOLD}"
echo "  ╔═══════════════════════════════════════════════════╗"
echo "  ║    CSMA — Cybersecurity Maturity Assessment       ║"
echo "  ║           Server Installation Script              ║"
echo "  ╚═══════════════════════════════════════════════════╝"
echo -e "${RESET}"
echo "  Host     : $(hostname -f 2>/dev/null || hostname)"
echo "  Date     : $(date)"
echo "  Debian   : $(cat /etc/debian_version 2>/dev/null || echo 'unknown')"
echo

# ── Detect server IP ─────────────────────────────────────────────────────────
# Used only for the post-install summary URL. The app itself does NOT need the
# public IP hardcoded — NextAuth v5 (trustHost:true) derives the canonical URL
# from the incoming Host header at runtime, so auth works after IP changes too.
#
# Detection order:
#   1. EC2 IMDS v2 (token-based, preferred on modern EC2)
#   2. EC2 IMDS v1 (legacy, may be disabled on hardened instances)
#   3. Generic public-IP lookup (works on any cloud / bare-metal)
#   4. Private IP fallback (LAN / local docker installs)

_imds_token=$(curl -sf --max-time 3 \
  -X PUT "http://169.254.169.254/latest/api/token" \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 60" 2>/dev/null || true)

if [[ -n "${_imds_token}" ]]; then
  PUBLIC_IP=$(curl -sf --max-time 3 \
    -H "X-aws-ec2-metadata-token: ${_imds_token}" \
    "http://169.254.169.254/latest/meta-data/public-ipv4" 2>/dev/null || true)
fi

if [[ -z "${PUBLIC_IP:-}" ]]; then
  PUBLIC_IP=$(curl -sf --max-time 3 \
    "http://169.254.169.254/latest/meta-data/public-ipv4" 2>/dev/null || true)
fi

if [[ -z "${PUBLIC_IP:-}" ]]; then
  PUBLIC_IP=$(curl -sf --max-time 5 "https://api.ipify.org" 2>/dev/null || true)
fi

# Keep the private IP for informational messages; fall back to it for the URL
# if all public-IP lookups failed (LAN-only deployment).
SERVER_IP=$(hostname -I | awk '{print $1}')
PUBLIC_IP="${PUBLIC_IP:-${SERVER_IP}}"

info "Private IP  : ${SERVER_IP}"
info "Public IP   : ${PUBLIC_IP}"

# ── Step 1: System update ─────────────────────────────────────────────────────
step "Step 1/7 — Updating system packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get upgrade -y -qq
apt-get install -y -qq \
  ca-certificates curl gnupg git openssl \
  lsb-release apt-transport-https
success "System packages updated"

# ── Step 2: Install Docker Engine ────────────────────────────────────────────
step "Step 2/7 — Installing Docker Engine"

if command -v docker &>/dev/null; then
  DOCKER_VER=$(docker --version)
  warn "Docker already installed: ${DOCKER_VER} — skipping install"
else
  info "Adding Docker's official GPG key and repository..."
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/debian/gpg \
    | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg

  # Resolve the Debian codename robustly — works on Bookworm, Trixie, and beyond
  DEBIAN_CODENAME="$(. /etc/os-release && echo "${VERSION_CODENAME:-}")"
  if [[ -z "${DEBIAN_CODENAME}" ]]; then
    DEBIAN_CODENAME="$(lsb_release -cs 2>/dev/null || echo "bookworm")"
  fi
  info "Detected Debian codename: ${DEBIAN_CODENAME}"

  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
    https://download.docker.com/linux/debian \
    ${DEBIAN_CODENAME} stable" \
    | tee /etc/apt/sources.list.d/docker.list > /dev/null

  apt-get update -qq
  apt-get install -y -qq \
    docker-ce docker-ce-cli containerd.io \
    docker-buildx-plugin docker-compose-plugin

  systemctl enable --now docker
  success "Docker Engine installed: $(docker --version)"
fi

# ── Step 3: Extract project files ────────────────────────────────────────────
step "Step 3/7 — Extracting project files"

[[ -f "${TARBALL}" ]] || die "Project archive not found at ${TARBALL}"

mkdir -p "${INSTALL_DIR}"
tar -xzf "${TARBALL}" -C "${INSTALL_DIR}" 2>/tmp/csma_tar_err; _TAR_RC=$?
# Filter out macOS PAX xattr noise (com.apple.provenance etc.) — harmless on Linux
grep -v "LIBARCHIVE\.xattr\|Ignoring unknown extended header" /tmp/csma_tar_err >&2 || true
rm -f /tmp/csma_tar_err
[[ ${_TAR_RC} -eq 0 ]] || die "Failed to extract archive (exit ${_TAR_RC})"
rm -f "${TARBALL}"
rm -f /tmp/csma_server_setup.sh

success "Project extracted to ${INSTALL_DIR}"

# ── Step 4: Configure environment ────────────────────────────────────────────
step "Step 4/7 — Configuring environment"

ENV_FILE="${INSTALL_DIR}/.env"

if [[ -f "${ENV_FILE}" ]]; then
  warn ".env already exists — backing up to .env.bak and regenerating"
  cp "${ENV_FILE}" "${ENV_FILE}.bak"
fi

# Generate a cryptographically strong AUTH_SECRET
AUTH_SECRET=$(openssl rand -base64 32)

# ENCRYPTION_KEY: preserve from backup so previously encrypted DB values (AI API keys)
# remain readable. Only generate a new key on a truly fresh install.
EXISTING_ENC_KEY=""
if [[ -f "${ENV_FILE}.bak" ]]; then
  EXISTING_ENC_KEY=$(grep -E '^ENCRYPTION_KEY=' "${ENV_FILE}.bak" \
    | head -1 | sed 's/^ENCRYPTION_KEY=["'"'"']*//' | sed 's/["'"'"']*$//' || true)
fi

if [[ -n "${EXISTING_ENC_KEY}" && ${#EXISTING_ENC_KEY} -eq 64 ]]; then
  ENCRYPTION_KEY="${EXISTING_ENC_KEY}"
  info "Preserving existing ENCRYPTION_KEY from previous install (required to decrypt stored secrets)"
else
  ENCRYPTION_KEY=$(openssl rand -hex 32)
  info "Generated new ENCRYPTION_KEY (first install)"
fi

cat > "${ENV_FILE}" <<EOF
# ─── Database ────────────────────────────────────────────────────
# Points to the 'postgres' Docker Compose service
DATABASE_URL="postgresql://csma_user:csma_password@postgres:5432/csma_db"

# ─── NextAuth ────────────────────────────────────────────────────
# NEXTAUTH_URL is intentionally NOT set here.
# NextAuth v5 with trustHost:true derives the canonical URL from the incoming
# Host header — no hardcoded IP needed. Removing it means auth continues to
# work correctly after every EC2 restart (when the public IP changes).
AUTH_SECRET="${AUTH_SECRET}"

# ─── File Upload ─────────────────────────────────────────────────
UPLOAD_DIR="./uploads"
MAX_FILE_SIZE_MB=10

# ─── Session ─────────────────────────────────────────────────────
SESSION_MAX_AGE=28800

# ─── Encryption (AI API key storage) ─────────────────────────────
# 64-character hex string (32 random bytes). DO NOT change after first install —
# changing this will render any stored AI API keys unreadable.
ENCRYPTION_KEY="${ENCRYPTION_KEY}"
EOF

chmod 600 "${ENV_FILE}"
success ".env written (AUTH_SECRET + ENCRYPTION_KEY auto-generated, permissions 600)"

# ── Step 5: Build Docker images ───────────────────────────────────────────────
step "Step 5/7 — Building and starting Docker containers"
info "This step builds the Next.js production image — may take 5–8 minutes..."

cd "${INSTALL_DIR}"
docker compose -p "${COMPOSE_PROJECT}" up -d --build

success "Containers started"

# ── Step 6: Wait for healthy containers ───────────────────────────────────────
step "Step 6/7 — Waiting for services to be ready"

# 6a: Wait for Postgres
MAX_WAIT=90
ELAPSED=0
info "Waiting for Postgres to become healthy (up to ${MAX_WAIT}s)..."

until docker compose -p "${COMPOSE_PROJECT}" exec -T postgres \
    pg_isready -U csma_user -d csma_db -q 2>/dev/null; do
  if [[ $ELAPSED -ge $MAX_WAIT ]]; then
    die "Postgres did not become healthy within ${MAX_WAIT}s. Check: docker compose logs postgres"
  fi
  sleep 3
  ELAPSED=$((ELAPSED + 3))
  echo -n "."
done
echo
success "Postgres is ready (waited ${ELAPSED}s)"

# 6b: Wait for the app HTTP endpoint.
# The container CMD runs: ./node_modules/.bin/prisma migrate deploy && node server.js
# The app only becomes reachable once both steps succeed — so HTTP up == migrations done.
MAX_APP_WAIT=180
APP_ELAPSED=0
info "Waiting for app HTTP endpoint (up to ${MAX_APP_WAIT}s — includes Prisma migration time)..."

until curl -sf --max-time 5 "http://127.0.0.1:3000" -o /dev/null 2>/dev/null; do
  if [[ $APP_ELAPSED -ge $MAX_APP_WAIT ]]; then
    warn "App did not respond within ${MAX_APP_WAIT}s — will attempt seed anyway."
    warn "Check logs with: docker compose -p csma logs app"
    break
  fi
  sleep 5
  APP_ELAPSED=$((APP_ELAPSED + 5))
  echo -n "."
done
echo

if curl -sf --max-time 5 "http://127.0.0.1:3000" -o /dev/null 2>/dev/null; then
  success "App is responding (waited ${APP_ELAPSED}s) — migrations complete"
else
  warn "App is not yet serving HTTP — dumping container logs for diagnosis:"
  echo -e "${YELLOW}──── app container logs (last 100 lines) ────${RESET}"
  docker compose -p "${COMPOSE_PROJECT}" logs --tail 100 app 2>&1 || true
  echo -e "${YELLOW}────────────────────────────────────────────${RESET}"
  warn "Proceeding with seed attempt anyway (will fail if container is still restarting)"
fi

# ── Step 7: Seed demo data ─────────────────────────────────────────────────────
step "Step 7/7 — Seeding demo data"

# Prisma migrations are handled inside the container CMD, so we only need to
# load the seed here. The seed was compiled from seed.ts to plain JS by esbuild
# during the Docker build — no npx / tsx / ts-node required.
info "Loading seed data..."
docker compose -p "${COMPOSE_PROJECT}" exec -T app \
  node prisma/seed.js
success "Seed data loaded"

# ── Final status check ────────────────────────────────────────────────────────
echo
info "Container status:"
docker compose -p "${COMPOSE_PROJECT}" ps

# Quick health check
echo
info "Checking HTTP response from app..."
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
  --max-time 15 "http://127.0.0.1:3000" 2>/dev/null || echo "000")

if [[ "${HTTP_STATUS}" == "200" || "${HTTP_STATUS}" == "307" || "${HTTP_STATUS}" == "302" ]]; then
  success "App is responding (HTTP ${HTTP_STATUS})"
else
  warn "App returned HTTP ${HTTP_STATUS} — may still be starting. Check: docker compose -p csma logs app"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo
echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${BOLD}${GREEN}  ✓  CSMA installation complete!${RESET}"
echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo
echo -e "  ${BOLD}Access URL:${RESET}     ${BLUE}http://${PUBLIC_IP}:3000${RESET}"
echo -e "  ${BOLD}Install dir:${RESET}    ${INSTALL_DIR}"
echo
echo -e "  ${BOLD}Default credentials (change these immediately!):${RESET}"
echo -e "  ┌─────────────────────────────────────────────────────┐"
echo -e "  │  Admin    : admin@csma.local     / Admin@1234!      │"
echo -e "  │  Assessor : assessor@csma.local  / Assessor@1234!   │"
echo -e "  │  Customer : alice@acme.com       / Customer@1234!   │"
echo -e "  │  Customer : bob@globaltech.com   / Customer@1234!   │"
echo -e "  └─────────────────────────────────────────────────────┘"
echo
echo -e "  ${BOLD}Useful commands:${RESET}"
echo -e "  • Manage      : ${YELLOW}sudo bash ${INSTALL_DIR}/scripts/manage.sh${RESET}"
echo -e "  • View logs   : ${YELLOW}sudo bash ${INSTALL_DIR}/scripts/manage.sh logs${RESET}"
echo -e "  • Status      : ${YELLOW}sudo bash ${INSTALL_DIR}/scripts/manage.sh status${RESET}"
echo -e "  • Backup DB   : ${YELLOW}sudo bash ${INSTALL_DIR}/scripts/manage.sh backup${RESET}"
echo
echo -e "  ${BOLD}${RED}⚠  Change all default passwords before exposing to the internet!${RESET}"
echo -e "  ${BOLD}${RED}⚠  Set up Nginx + TLS if this is a production deployment.${RESET}"
echo
