#!/usr/bin/env bash
# =============================================================================
# CSMA — Server management script
# Run directly on the server (as root or via sudo).
#
# Usage:
#   sudo bash /opt/csma/scripts/manage.sh <command>
#
# Commands:
#   start      Start all containers (safe to run if already up)
#   stop       Stop all containers, preserve data
#   restart    Rebuild app image and restart (postgres unchanged)
#   status     Show container health, uptime, and port bindings
#   logs       Follow app logs  (Ctrl-C to exit)
#   db-logs    Follow postgres logs
#   migrate    Run any pending Prisma migrations
#   seed       (Re-)load demo seed data
#   backup     Dump the database to /opt/csma/backups/
#   shell-app  Open a shell inside the app container
#   shell-db   Open a psql session in the postgres container
#   update     Extract a new tarball from /tmp/csma_deploy.tar.gz and rebuild
#   reset      ⚠  Wipe ALL data and start fresh (destructive!)
# =============================================================================
set -euo pipefail

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${BLUE}[•]${RESET} $*"; }
success() { echo -e "${GREEN}[✓]${RESET} $*"; }
warn()    { echo -e "${YELLOW}[!]${RESET} $*"; }
die()     { echo -e "${RED}[✗]${RESET} $*" >&2; exit 1; }
header()  { echo; echo -e "${BOLD}${BLUE}━━ $* ${RESET}"; }

# ── Config ────────────────────────────────────────────────────────────────────
INSTALL_DIR="/opt/csma"
COMPOSE_PROJECT="csma"
BACKUP_DIR="${INSTALL_DIR}/backups"
DB_USER="csma_user"
DB_NAME="csma_db"

# ── Guards ────────────────────────────────────────────────────────────────────
[[ $EUID -eq 0 ]] || die "Please run as root: sudo bash $0 $*"
[[ -d "${INSTALL_DIR}" ]]        || die "Install directory not found: ${INSTALL_DIR}"
[[ -f "${INSTALL_DIR}/docker-compose.yml" ]] || die "docker-compose.yml missing from ${INSTALL_DIR}"
command -v docker >/dev/null 2>&1 || die "docker not found"

cd "${INSTALL_DIR}"

# ── Helper: compose wrapper ───────────────────────────────────────────────────
dc() { docker compose -p "${COMPOSE_PROJECT}" "$@"; }

# ── Helper: wait for postgres ─────────────────────────────────────────────────
wait_for_postgres() {
  local max=60 elapsed=0
  info "Waiting for Postgres to be healthy..."
  until dc exec -T postgres pg_isready -U "${DB_USER}" -d "${DB_NAME}" -q 2>/dev/null; do
    [[ $elapsed -ge $max ]] && die "Postgres not healthy after ${max}s"
    sleep 3; elapsed=$((elapsed + 3)); echo -n "."
  done
  echo
  success "Postgres ready"
}

# ── Helper: wait for app HTTP ─────────────────────────────────────────────────
wait_for_app() {
  local max=120 elapsed=0
  info "Waiting for app HTTP endpoint (up to ${max}s)..."
  until curl -sf --max-time 5 "http://127.0.0.1:3000" -o /dev/null 2>/dev/null; do
    if [[ $elapsed -ge $max ]]; then
      warn "App did not respond within ${max}s — check: dc logs app"
      return 1
    fi
    sleep 5; elapsed=$((elapsed + 5)); echo -n "."
  done
  echo
  success "App is responding"
}

# ── Commands ──────────────────────────────────────────────────────────────────
CMD="${1:-help}"

case "${CMD}" in

  # ── start ──────────────────────────────────────────────────────────────────
  start)
    header "Starting CSMA"
    dc up -d
    wait_for_postgres
    wait_for_app
    SERVER_IP=$(hostname -I | awk '{print $1}')
    success "CSMA is running at http://${SERVER_IP}:3000"
    ;;

  # ── stop ───────────────────────────────────────────────────────────────────
  stop)
    header "Stopping CSMA"
    dc down
    success "Containers stopped (data volumes preserved)"
    ;;

  # ── restart ────────────────────────────────────────────────────────────────
  restart)
    header "Restarting app container"
    dc restart app
    wait_for_app
    success "App restarted"
    ;;

  # ── status ─────────────────────────────────────────────────────────────────
  status)
    header "CSMA container status"
    dc ps
    echo
    SERVER_IP=$(hostname -I | awk '{print $1}')
    HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://127.0.0.1:3000" 2>/dev/null || echo "000")
    if [[ "${HTTP_STATUS}" == "200" || "${HTTP_STATUS}" == "307" || "${HTTP_STATUS}" == "302" ]]; then
      success "App HTTP → ${HTTP_STATUS}  (http://${SERVER_IP}:3000)"
    else
      warn "App HTTP → ${HTTP_STATUS}  (app may be starting or unhealthy)"
    fi
    ;;

  # ── logs ───────────────────────────────────────────────────────────────────
  logs)
    exec dc logs -f --tail 100 app
    ;;

  # ── db-logs ────────────────────────────────────────────────────────────────
  db-logs)
    exec dc logs -f --tail 100 postgres
    ;;

  # ── migrate ────────────────────────────────────────────────────────────────
  migrate)
    header "Running Prisma migrations"
    wait_for_postgres
    dc exec -T app node node_modules/prisma/build/index.js migrate deploy
    success "Migrations applied"
    ;;

  # ── seed ───────────────────────────────────────────────────────────────────
  seed)
    header "Loading seed data"
    wait_for_postgres
    dc exec -T app node prisma/seed.js
    success "Seed data loaded"
    ;;

  # ── backup ─────────────────────────────────────────────────────────────────
  backup)
    header "Backing up database"
    mkdir -p "${BACKUP_DIR}"
    STAMP=$(date +%Y%m%d_%H%M%S)
    OUTFILE="${BACKUP_DIR}/${DB_NAME}_${STAMP}.sql.gz"
    info "Dumping to ${OUTFILE} ..."
    dc exec -T postgres pg_dump -U "${DB_USER}" "${DB_NAME}" | gzip > "${OUTFILE}"
    SIZE=$(du -sh "${OUTFILE}" | cut -f1)
    success "Backup saved: ${OUTFILE} (${SIZE})"
    echo
    info "Existing backups:"
    ls -lh "${BACKUP_DIR}"/*.sql.gz 2>/dev/null || echo "  (none)"
    ;;

  # ── shell-app ──────────────────────────────────────────────────────────────
  shell-app)
    exec dc exec app sh
    ;;

  # ── shell-db ───────────────────────────────────────────────────────────────
  shell-db)
    exec dc exec postgres psql -U "${DB_USER}" "${DB_NAME}"
    ;;

  # ── update ─────────────────────────────────────────────────────────────────
  update)
    header "Updating CSMA from tarball"
    TARBALL="/tmp/csma_deploy.tar.gz"
    [[ -f "${TARBALL}" ]] || die "No tarball found at ${TARBALL}. Upload one first with:
  scp csma_deploy.tar.gz root@<server>:/tmp/csma_deploy.tar.gz"

    info "Stopping app container..."
    dc stop app

    info "Extracting new files..."
    tar -xzf "${TARBALL}" -C "${INSTALL_DIR}" 2>/tmp/manage_tar_err; _RC=$?
    grep -v "LIBARCHIVE\|unknown extended header" /tmp/manage_tar_err >&2 || true
    rm -f /tmp/manage_tar_err
    [[ ${_RC} -eq 0 ]] || die "Extraction failed (exit ${_RC})"
    rm -f "${TARBALL}"

    info "Rebuilding and restarting containers..."
    dc up -d --build app

    wait_for_postgres
    wait_for_app
    success "Update complete"
    ;;

  # ── reset ──────────────────────────────────────────────────────────────────
  reset)
    header "⚠  Full reset"
    warn "This will DELETE all data (database + uploads) and restart fresh."
    echo -n "  Type YES to confirm: "
    read -r CONFIRM
    [[ "${CONFIRM}" == "YES" ]] || { info "Aborted."; exit 0; }

    info "Stopping containers and removing volumes..."
    dc down -v
    rm -rf "${INSTALL_DIR}/uploads"
    mkdir -p "${INSTALL_DIR}/uploads"

    info "Restarting..."
    dc up -d
    wait_for_postgres
    wait_for_app

    info "Running migrations..."
    dc exec -T app node node_modules/prisma/build/index.js migrate deploy

    info "Seeding demo data..."
    dc exec -T app node prisma/seed.js

    success "Reset complete — fresh CSMA instance running"
    ;;

  # ── help ───────────────────────────────────────────────────────────────────
  help|--help|-h|"")
    echo
    echo -e "${BOLD}CSMA Server Management${RESET}"
    echo -e "Usage: sudo bash ${INSTALL_DIR}/scripts/manage.sh <command>"
    echo
    echo -e "${BOLD}Commands:${RESET}"
    echo -e "  ${GREEN}start${RESET}      Start all containers"
    echo -e "  ${GREEN}stop${RESET}       Stop all containers (data preserved)"
    echo -e "  ${GREEN}restart${RESET}    Restart the app container"
    echo -e "  ${GREEN}status${RESET}     Show container health and HTTP status"
    echo -e "  ${GREEN}logs${RESET}       Follow app logs (Ctrl-C to exit)"
    echo -e "  ${GREEN}db-logs${RESET}    Follow postgres logs"
    echo -e "  ${GREEN}migrate${RESET}    Apply pending Prisma migrations"
    echo -e "  ${GREEN}seed${RESET}       Load demo seed data"
    echo -e "  ${GREEN}backup${RESET}     Dump database to ${BACKUP_DIR}/"
    echo -e "  ${GREEN}shell-app${RESET}  Shell inside app container"
    echo -e "  ${GREEN}shell-db${RESET}   psql session in postgres container"
    echo -e "  ${GREEN}update${RESET}     Apply a new tarball from /tmp/csma_deploy.tar.gz"
    echo -e "  ${RED}reset${RESET}      ⚠  Wipe all data and start fresh"
    echo
    ;;

  *)
    die "Unknown command: ${CMD}  (run without args to see usage)"
    ;;
esac
