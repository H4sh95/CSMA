#!/usr/bin/env bash
# =============================================================================
# CSMA — Local deploy helper
# Usage:
#   bash scripts/deploy-to-server.sh user@server-ip
#   bash scripts/deploy-to-server.sh user@server-ip -i ~/.ssh/my_key
#   bash scripts/deploy-to-server.sh user@server-ip -i ~/.ssh/my_key --port 2222
# =============================================================================
set -euo pipefail

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${BLUE}[•]${RESET} $*"; }
success() { echo -e "${GREEN}[✓]${RESET} $*"; }
warn()    { echo -e "${YELLOW}[!]${RESET} $*"; }
die()     { echo -e "${RED}[✗]${RESET} $*" >&2; exit 1; }

# ── Banner ────────────────────────────────────────────────────────────────────
echo -e "${BOLD}"
echo "  ╔═══════════════════════════════════════════╗"
echo "  ║       CSMA — Deploy to Remote Server      ║"
echo "  ╚═══════════════════════════════════════════╝"
echo -e "${RESET}"

# ── Argument parsing ──────────────────────────────────────────────────────────
if [[ $# -lt 1 ]]; then
  echo -e "Usage: bash scripts/deploy-to-server.sh user@server-ip [OPTIONS]"
  echo
  echo "Options:"
  echo "  -i <path>     Path to SSH private key file"
  echo "  --port <n>    SSH port (default: 22)"
  echo
  echo "Examples:"
  echo "  bash scripts/deploy-to-server.sh ubuntu@1.2.3.4"
  echo "  bash scripts/deploy-to-server.sh ubuntu@1.2.3.4 -i ~/.ssh/my_key"
  echo "  bash scripts/deploy-to-server.sh ubuntu@1.2.3.4 -i ~/.ssh/my_key --port 2222"
  exit 1
fi

REMOTE="$1"; shift

SSH_PORT="22"
IDENTITY_FILE=""

# Parse remaining flags
while [[ $# -gt 0 ]]; do
  case "$1" in
    -i)
      [[ $# -ge 2 ]] || die "-i requires a path argument"
      IDENTITY_FILE="$2"; shift 2 ;;
    --port)
      [[ $# -ge 2 ]] || die "--port requires a number argument"
      SSH_PORT="$2"; shift 2 ;;
    *)
      die "Unknown option: $1  (run with no args to see usage)" ;;
  esac
done

# Validate key file if provided
if [[ -n "${IDENTITY_FILE}" ]]; then
  IDENTITY_FILE="${IDENTITY_FILE/#\~/$HOME}"   # expand ~ manually
  [[ -f "${IDENTITY_FILE}" ]] || die "Key file not found: ${IDENTITY_FILE}"
  [[ -r "${IDENTITY_FILE}" ]] || die "Key file not readable: ${IDENTITY_FILE}"
fi

# Build option arrays (arrays avoid word-splitting bugs with paths that contain spaces)
# NOTE: ssh uses -p (lowercase) for port; scp uses -P (uppercase) — they differ.
SSH_ARGS=(-p "${SSH_PORT}" -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15)
SCP_ARGS=(-P "${SSH_PORT}" -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15)

if [[ -n "${IDENTITY_FILE}" ]]; then
  SSH_ARGS+=(-i "${IDENTITY_FILE}")
  SCP_ARGS+=(-i "${IDENTITY_FILE}")
fi

# ── Locate project root ───────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
TARBALL="/tmp/csma_deploy_$(date +%Y%m%d_%H%M%S).tar.gz"

info "Project root  : ${PROJECT_ROOT}"
info "Remote target : ${REMOTE}"
info "SSH port      : ${SSH_PORT}"
[[ -n "${IDENTITY_FILE}" ]] && info "Identity file : ${IDENTITY_FILE}"
echo

# ── Preflight checks ──────────────────────────────────────────────────────────
info "Running preflight checks..."

command -v ssh  >/dev/null 2>&1 || die "'ssh' not found. Install OpenSSH client."
command -v scp  >/dev/null 2>&1 || die "'scp' not found. Install OpenSSH client."
command -v tar  >/dev/null 2>&1 || die "'tar' not found."

[[ -f "${PROJECT_ROOT}/package.json" ]]       || die "package.json not found in ${PROJECT_ROOT}"
[[ -f "${PROJECT_ROOT}/docker-compose.yml" ]] || die "docker-compose.yml not found"
[[ -f "${PROJECT_ROOT}/prisma/schema.prisma" ]]|| die "prisma/schema.prisma not found"
[[ -f "${PROJECT_ROOT}/scripts/server-setup.sh" ]] || die "scripts/server-setup.sh not found"

success "Preflight passed"
echo

# ── Test SSH connectivity ─────────────────────────────────────────────────────
info "Testing SSH connection to ${REMOTE}..."
if ! ssh "${SSH_ARGS[@]}" "${REMOTE}" "echo 'SSH OK'" >/dev/null 2>&1; then
  die "Cannot connect to ${REMOTE} on port ${SSH_PORT}. Check credentials/firewall."
fi
success "SSH connection OK"
echo

# ── Create tarball (exclude heavy/sensitive dirs) ─────────────────────────────
info "Creating project archive (excluding node_modules, .next, uploads, .env)..."

# COPYFILE_DISABLE=1 prevents macOS tar from embedding Apple extended attributes
# (com.apple.provenance, com.apple.macl, etc.) which produce harmless but noisy
# warnings when the archive is extracted on Linux.
COPYFILE_DISABLE=1 tar -czf "${TARBALL}" \
  --exclude='./.next' \
  --exclude='./node_modules' \
  --exclude='./.git' \
  --exclude='./uploads/*' \
  --exclude='./.env' \
  --exclude='./coverage' \
  --exclude='./*.tsbuildinfo' \
  -C "${PROJECT_ROOT}" \
  .

TARBALL_SIZE=$(du -sh "${TARBALL}" | cut -f1)
success "Archive created: ${TARBALL} (${TARBALL_SIZE})"
echo

# ── Transfer files ────────────────────────────────────────────────────────────
info "Uploading project archive to server..."
scp "${SCP_ARGS[@]}" "${TARBALL}" "${REMOTE}:/tmp/csma_deploy.tar.gz"
success "Archive uploaded"

info "Uploading server setup script..."
scp "${SCP_ARGS[@]}" "${PROJECT_ROOT}/scripts/server-setup.sh" "${REMOTE}:/tmp/csma_server_setup.sh"
success "Setup script uploaded"
echo

# ── Cleanup local tarball ─────────────────────────────────────────────────────
rm -f "${TARBALL}"

# ── Run setup on server ───────────────────────────────────────────────────────
info "Starting remote setup (this may take 5-10 minutes)..."
echo -e "${YELLOW}──────────────────────────────────────────────────────${RESET}"

ssh "${SSH_ARGS[@]}" -t "${REMOTE}" \
  "chmod +x /tmp/csma_server_setup.sh && sudo bash /tmp/csma_server_setup.sh"

echo -e "${YELLOW}──────────────────────────────────────────────────────${RESET}"
echo
success "Deployment complete!"
echo
echo -e "  ${BOLD}Your CSMA instance should now be running.${RESET}"
echo -e "  Open ${BLUE}http://$(echo "${REMOTE}" | cut -d@ -f2):3000${RESET} in your browser."
echo
