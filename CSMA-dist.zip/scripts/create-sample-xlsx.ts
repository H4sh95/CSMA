/**
 * Script: create-sample-xlsx.ts
 *
 * Generates a sample CSMA assessment template XLSX file with NIST CSF-style
 * content and writes it to ./sample-template.xlsx.
 *
 * Run with:
 *   tsx scripts/create-sample-xlsx.ts
 */

import * as XLSX from "xlsx";
import path from "path";
import fs from "fs";

// ─── Sample data ──────────────────────────────────────────────────────────────

interface TemplateRow {
  Domain: string;
  Category: string;
  Code: string;
  Description: string;
  Label: string;
  Scoring: number;
}

const sampleRows: TemplateRow[] = [
  {
    Domain: "Identify",
    Category: "Asset Management",
    Code: "ID.AM-1",
    Description:
      "Physical devices and systems within the organization are inventoried, documented, and maintained with assigned ownership.",
    Label: "Hardware Asset Inventory",
    Scoring: 5,
  },
  {
    Domain: "Identify",
    Category: "Asset Management",
    Code: "ID.AM-2",
    Description:
      "Software platforms and applications within the organization are inventoried, classified by criticality, and kept up to date.",
    Label: "Software Asset Inventory",
    Scoring: 5,
  },
  {
    Domain: "Identify",
    Category: "Risk Assessment",
    Code: "ID.RA-1",
    Description:
      "Asset vulnerabilities are identified, tracked, and documented. A vulnerability management process is in place and regularly executed.",
    Label: "Vulnerability Identification",
    Scoring: 5,
  },
  {
    Domain: "Protect",
    Category: "Access Control",
    Code: "PR.AC-1",
    Description:
      "Identities and credentials are issued, managed, verified, revoked, and audited for authorized devices, users, and processes.",
    Label: "Identity & Credential Management",
    Scoring: 5,
  },
  {
    Domain: "Protect",
    Category: "Access Control",
    Code: "PR.AC-4",
    Description:
      "Access permissions and authorizations are managed, incorporating the principles of least privilege and separation of duties.",
    Label: "Least Privilege & Separation of Duties",
    Scoring: 5,
  },
  {
    Domain: "Protect",
    Category: "Awareness & Training",
    Code: "PR.AT-1",
    Description:
      "All users are informed and trained on cybersecurity policies, procedures, and awareness topics on at least an annual basis.",
    Label: "User Awareness Training",
    Scoring: 3,
  },
  {
    Domain: "Detect",
    Category: "Anomalies & Events",
    Code: "DE.AE-1",
    Description:
      "A baseline of network operations and expected data flows for users and systems is established, documented, and maintained.",
    Label: "Network Baseline Establishment",
    Scoring: 5,
  },
  {
    Domain: "Detect",
    Category: "Security Continuous Monitoring",
    Code: "DE.CM-1",
    Description:
      "The network is monitored to detect potential cybersecurity events. Monitoring includes intrusion detection systems, SIEM, and log analysis.",
    Label: "Continuous Network Monitoring",
    Scoring: 5,
  },
  {
    Domain: "Respond",
    Category: "Response Planning",
    Code: "RS.RP-1",
    Description:
      "A response plan is executed during or after a cybersecurity incident. The plan is documented, tested, and updated regularly.",
    Label: "Incident Response Plan Execution",
    Scoring: 5,
  },
  {
    Domain: "Recover",
    Category: "Recovery Planning",
    Code: "RC.RP-1",
    Description:
      "A recovery plan is executed during or after a cybersecurity incident. Backup processes are in place and tested at least annually.",
    Label: "Recovery Plan Execution",
    Scoring: 5,
  },
];

// ─── Build workbook ───────────────────────────────────────────────────────────

const headers: Array<keyof TemplateRow> = [
  "Domain",
  "Category",
  "Code",
  "Description",
  "Label",
  "Scoring",
];

// Build rows array: header first, then data
const wsData: unknown[][] = [
  headers,
  ...sampleRows.map((row) => headers.map((h) => row[h])),
];

const wb = XLSX.utils.book_new();
const ws = XLSX.utils.aoa_to_sheet(wsData);

// ── Column widths ──────────────────────────────────────────────────────────────
ws["!cols"] = [
  { wch: 12 },  // Domain
  { wch: 28 },  // Category
  { wch: 12 },  // Code
  { wch: 80 },  // Description
  { wch: 40 },  // Label
  { wch: 10 },  // Scoring
];

// ── Freeze the header row ──────────────────────────────────────────────────────
ws["!freeze"] = { xSplit: 0, ySplit: 1, topLeftCell: "A2", activePane: "bottomLeft", state: "frozen" };

XLSX.utils.book_append_sheet(wb, ws, "Assessment Template");

// ─── Output path ──────────────────────────────────────────────────────────────

const outputPath = path.resolve(process.cwd(), "sample-template.xlsx");

try {
  const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
  fs.writeFileSync(outputPath, buffer);
  console.log(`\nSample XLSX template written to: ${outputPath}`);
  console.log(`  Rows:    ${sampleRows.length} items`);
  console.log(`  Domains: ${[...new Set(sampleRows.map((r) => r.Domain))].join(", ")}`);
  console.log(`\nTo use this template:`);
  console.log(`  1. Log in as Admin or Assessor`);
  console.log(`  2. Navigate to Templates > Upload Template`);
  console.log(`  3. Upload sample-template.xlsx`);
  console.log(`  4. Activate the template`);
  console.log(`  5. Create a new Assessment and select this template\n`);
} catch (err) {
  console.error("Failed to write XLSX file:", err);
  process.exit(1);
}
