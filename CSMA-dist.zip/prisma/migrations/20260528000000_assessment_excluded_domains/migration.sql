-- Add excludedDomains column to Assessment.
-- Domains listed here are skipped during scoring and not shown during conduct.
ALTER TABLE "Assessment" ADD COLUMN "excludedDomains" TEXT[] NOT NULL DEFAULT '{}';
