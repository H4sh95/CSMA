-- Add AI-related AuditAction enum values
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'AI_SETTINGS_UPDATED';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'AI_SETTINGS_ENABLED';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'AI_SETTINGS_DISABLED';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'AI_ANALYSIS_GENERATED';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'AI_ANALYSIS_REGENERATED';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'AI_ANALYSIS_FAILED';

-- CreateTable: AiSettings
CREATE TABLE "AiSettings" (
    "id" TEXT NOT NULL,
    "isEnabled" BOOLEAN NOT NULL DEFAULT false,
    "endpoint" TEXT,
    "deployment" TEXT,
    "model" TEXT,
    "encryptedApiKey" TEXT,
    "systemPromptTemplate" TEXT,
    "recommendationStyle" TEXT NOT NULL DEFAULT 'detailed',
    "maxTokens" INTEGER NOT NULL DEFAULT 2000,
    "temperature" DOUBLE PRECISION NOT NULL DEFAULT 0.3,
    "includeAssessorComments" BOOLEAN NOT NULL DEFAULT true,
    "includeHistorical" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "updatedById" TEXT,

    CONSTRAINT "AiSettings_pkey" PRIMARY KEY ("id")
);

-- CreateTable: AiAnalysis
CREATE TABLE "AiAnalysis" (
    "id" TEXT NOT NULL,
    "assessmentId" TEXT NOT NULL,
    "versionNumber" INTEGER NOT NULL DEFAULT 1,
    "generatedById" TEXT,
    "generationMode" TEXT NOT NULL DEFAULT 'manual',
    "provider" TEXT NOT NULL DEFAULT 'azure_openai',
    "modelUsed" TEXT,
    "deploymentUsed" TEXT,
    "currentState" TEXT NOT NULL,
    "immediateActions" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "mediumTermActions" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "longTermActions" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "deduplicationApplied" BOOLEAN NOT NULL DEFAULT false,
    "deduplicationSummary" TEXT,
    "status" TEXT NOT NULL DEFAULT 'success',
    "errorMessage" TEXT,
    "tokenCount" INTEGER,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AiAnalysis_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "AiAnalysis_assessmentId_idx" ON "AiAnalysis"("assessmentId");
CREATE INDEX "AiAnalysis_generatedById_idx" ON "AiAnalysis"("generatedById");
CREATE INDEX "AiAnalysis_status_idx" ON "AiAnalysis"("status");

-- AddForeignKey: AiSettings -> User
ALTER TABLE "AiSettings"
    ADD CONSTRAINT "AiSettings_updatedById_fkey"
    FOREIGN KEY ("updatedById") REFERENCES "User"("id")
    ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey: AiAnalysis -> Assessment
ALTER TABLE "AiAnalysis"
    ADD CONSTRAINT "AiAnalysis_assessmentId_fkey"
    FOREIGN KEY ("assessmentId") REFERENCES "Assessment"("id")
    ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey: AiAnalysis -> User
ALTER TABLE "AiAnalysis"
    ADD CONSTRAINT "AiAnalysis_generatedById_fkey"
    FOREIGN KEY ("generatedById") REFERENCES "User"("id")
    ON DELETE SET NULL ON UPDATE CASCADE;
