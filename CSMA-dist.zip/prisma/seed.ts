import { PrismaClient, Role, ProfileStatus, TemplateStatus, AssessmentStatus } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function randomScore(min = 2, max = 5): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const COMMENTS: string[] = [
  "Controls are well documented and regularly reviewed.",
  "Partial implementation exists; remediation underway.",
  "Process is defined but not consistently followed.",
  "Strong evidence of implementation with audit trail.",
  "Needs significant improvement; gaps identified.",
  "Automated tooling in place and functioning correctly.",
  "Manual process with inconsistent outcomes.",
  "Policy exists but awareness training is lacking.",
  "Recently updated to reflect current best practices.",
  "Third-party validation completed successfully.",
];

function randomComment(): string {
  return COMMENTS[Math.floor(Math.random() * COMMENTS.length)];
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  // ── Users ────────────────────────────────────────────────────────────────

  const adminPassword = await bcrypt.hash("Admin@1234!", 12);
  const assessorPassword = await bcrypt.hash("Assessor@1234!", 12);
  const customerPassword = await bcrypt.hash("Customer@1234!", 12);

  const admin = await prisma.user.upsert({
    where: { email: "admin@csma.local" },
    update: {},
    create: {
      email: "admin@csma.local",
      name: "System Administrator",
      passwordHash: adminPassword,
      role: Role.ADMIN,
      isActive: true,
    },
  });

  const assessor = await prisma.user.upsert({
    where: { email: "assessor@csma.local" },
    update: {},
    create: {
      email: "assessor@csma.local",
      name: "Jane Assessor",
      passwordHash: assessorPassword,
      role: Role.ASSESSOR,
      isActive: true,
    },
  });

  const alice = await prisma.user.upsert({
    where: { email: "alice@acme.com" },
    update: {},
    create: {
      email: "alice@acme.com",
      name: "Alice Johnson",
      passwordHash: customerPassword,
      role: Role.CUSTOMER,
      isActive: true,
    },
  });

  const bob = await prisma.user.upsert({
    where: { email: "bob@globaltech.com" },
    update: {},
    create: {
      email: "bob@globaltech.com",
      name: "Bob Smith",
      passwordHash: customerPassword,
      role: Role.CUSTOMER,
      isActive: true,
    },
  });

  // ── Customer Profiles ────────────────────────────────────────────────────

  const acme = await prisma.customerProfile.upsert({
    where: { identifier: "ACME-001" },
    update: {},
    create: {
      name: "ACME Corporation",
      identifier: "ACME-001",
      industry: "Finance",
      region: "North America",
      country: "USA",
      primaryContact: "Alice Johnson",
      primaryEmail: "alice@acme.com",
      status: ProfileStatus.ACTIVE,
      createdById: admin.id,
    },
  });

  const globalTech = await prisma.customerProfile.upsert({
    where: { identifier: "GTI-001" },
    update: {},
    create: {
      name: "GlobalTech Industries",
      identifier: "GTI-001",
      industry: "Technology",
      region: "Europe",
      country: "UK",
      primaryContact: "Bob Smith",
      primaryEmail: "bob@globaltech.com",
      status: ProfileStatus.ACTIVE,
      createdById: admin.id,
    },
  });

  const healthFirst = await prisma.customerProfile.upsert({
    where: { identifier: "HFM-001" },
    update: {},
    create: {
      name: "HealthFirst Medical",
      identifier: "HFM-001",
      industry: "Healthcare",
      region: "North America",
      country: "USA",
      status: ProfileStatus.ACTIVE,
      createdById: admin.id,
    },
  });

  // ── User-Customer Access ─────────────────────────────────────────────────

  await prisma.userCustomerAccess.upsert({
    where: { userId_profileId: { userId: alice.id, profileId: acme.id } },
    update: {},
    create: { userId: alice.id, profileId: acme.id },
  });

  await prisma.userCustomerAccess.upsert({
    where: { userId_profileId: { userId: bob.id, profileId: globalTech.id } },
    update: {},
    create: { userId: bob.id, profileId: globalTech.id },
  });

  // ── Assessor Assignments ─────────────────────────────────────────────────

  for (const profile of [acme, globalTech, healthFirst]) {
    await prisma.assessorAssignment.upsert({
      where: {
        assessorId_profileId: { assessorId: assessor.id, profileId: profile.id },
      },
      update: {},
      create: { assessorId: assessor.id, profileId: profile.id },
    });
  }

  // ── Template 1: NIST CSF Assessment v1.0 ─────────────────────────────────

  const nistTemplate = await prisma.template.upsert({
    where: {
      // Templates don't have a natural unique key other than id; use findFirst guard
      id: (
        await prisma.template.findFirst({ where: { name: "NIST CSF Assessment v1.0" } })
      )?.id ?? "nist-template-seed",
    },
    update: {},
    create: {
      id: "nist-template-seed",
      name: "NIST CSF Assessment v1.0",
      version: "1.0",
      description:
        "National Institute of Standards and Technology Cybersecurity Framework assessment covering the five core functions.",
      status: TemplateStatus.ACTIVE,
      uploadedById: admin.id,
      rowCount: 15,
    },
  });

  interface ItemDef {
    domain: string;
    category: string;
    code: string;
    description: string;
    label: string;
    scoring: number;
    orderIndex: number;
  }

  const nistItems: ItemDef[] = [
    // Identify – Asset Management
    {
      domain: "Identify",
      category: "Asset Management",
      code: "ID-AM-1",
      description: "Physical devices and systems within the organization are inventoried.",
      label: "Physical Asset Inventory",
      scoring: 5,
      orderIndex: 1,
    },
    {
      domain: "Identify",
      category: "Asset Management",
      code: "ID-AM-2",
      description: "Software platforms and applications within the organization are inventoried.",
      label: "Software Asset Inventory",
      scoring: 5,
      orderIndex: 2,
    },
    {
      domain: "Identify",
      category: "Asset Management",
      code: "ID-AM-3",
      description: "Organizational communication and data flows are mapped.",
      label: "Data Flow Mapping",
      scoring: 5,
      orderIndex: 3,
    },
    // Protect – Access Control
    {
      domain: "Protect",
      category: "Access Control",
      code: "PR-AC-1",
      description: "Identities and credentials are issued, managed, verified, revoked, and audited for authorized devices, users and processes.",
      label: "Identity & Credential Management",
      scoring: 5,
      orderIndex: 4,
    },
    {
      domain: "Protect",
      category: "Access Control",
      code: "PR-AC-2",
      description: "Physical access to assets is managed and protected.",
      label: "Physical Access Management",
      scoring: 5,
      orderIndex: 5,
    },
    {
      domain: "Protect",
      category: "Access Control",
      code: "PR-AC-3",
      description: "Remote access is managed.",
      label: "Remote Access Management",
      scoring: 5,
      orderIndex: 6,
    },
    // Detect – Continuous Monitoring
    {
      domain: "Detect",
      category: "Continuous Monitoring",
      code: "DE-CM-1",
      description: "The network is monitored to detect potential cybersecurity events.",
      label: "Network Monitoring",
      scoring: 5,
      orderIndex: 7,
    },
    {
      domain: "Detect",
      category: "Continuous Monitoring",
      code: "DE-CM-2",
      description: "The physical environment is monitored to detect potential cybersecurity events.",
      label: "Physical Environment Monitoring",
      scoring: 5,
      orderIndex: 8,
    },
    {
      domain: "Detect",
      category: "Continuous Monitoring",
      code: "DE-CM-3",
      description: "Personnel activity is monitored to detect potential cybersecurity events.",
      label: "Personnel Activity Monitoring",
      scoring: 5,
      orderIndex: 9,
    },
    // Respond – Response Planning
    {
      domain: "Respond",
      category: "Response Planning",
      code: "RS-RP-1",
      description: "Response plan is executed during or after an incident.",
      label: "Incident Response Execution",
      scoring: 5,
      orderIndex: 10,
    },
    {
      domain: "Respond",
      category: "Response Planning",
      code: "RS-RP-2",
      description: "Response activities are coordinated with internal and external stakeholders.",
      label: "Stakeholder Coordination",
      scoring: 5,
      orderIndex: 11,
    },
    {
      domain: "Respond",
      category: "Response Planning",
      code: "RS-RP-3",
      description: "Lessons learned are incorporated into response strategies.",
      label: "Response Lessons Learned",
      scoring: 5,
      orderIndex: 12,
    },
    // Recover – Recovery Planning
    {
      domain: "Recover",
      category: "Recovery Planning",
      code: "RC-RP-1",
      description: "Recovery plan is executed during or after a cybersecurity incident.",
      label: "Recovery Plan Execution",
      scoring: 5,
      orderIndex: 13,
    },
    {
      domain: "Recover",
      category: "Recovery Planning",
      code: "RC-RP-2",
      description: "Recovery strategies are updated.",
      label: "Recovery Strategy Updates",
      scoring: 5,
      orderIndex: 14,
    },
    {
      domain: "Recover",
      category: "Recovery Planning",
      code: "RC-RP-3",
      description: "Public relations and reputation are repaired after an incident.",
      label: "Reputation Recovery",
      scoring: 5,
      orderIndex: 15,
    },
  ];

  // Upsert NIST items by templateId + code
  const nistItemRecords: Array<{ id: string; domain: string; category: string; scoring: number }> = [];
  for (const item of nistItems) {
    const existing = await prisma.templateItem.findFirst({
      where: { templateId: nistTemplate.id, code: item.code },
    });
    if (existing) {
      nistItemRecords.push(existing);
    } else {
      const created = await prisma.templateItem.create({
        data: { templateId: nistTemplate.id, ...item },
      });
      nistItemRecords.push(created);
    }
  }

  // ── Template 2: ISO 27001 Assessment v1.0 ────────────────────────────────

  const isoTemplate = await prisma.template.upsert({
    where: {
      id: (
        await prisma.template.findFirst({ where: { name: "ISO 27001 Assessment v1.0" } })
      )?.id ?? "iso-template-seed",
    },
    update: {},
    create: {
      id: "iso-template-seed",
      name: "ISO 27001 Assessment v1.0",
      version: "1.0",
      description:
        "ISO/IEC 27001 information security management system assessment covering key Annex A control domains.",
      status: TemplateStatus.ACTIVE,
      uploadedById: admin.id,
      rowCount: 12,
    },
  });

  const isoItems: ItemDef[] = [
    // A.5 Information Security Policies
    {
      domain: "A.5 Information Security Policies",
      category: "Information Security Policies",
      code: "A.5.1.1",
      description: "A set of policies for information security shall be defined, approved by management, published and communicated.",
      label: "Information Security Policy",
      scoring: 5,
      orderIndex: 1,
    },
    {
      domain: "A.5 Information Security Policies",
      category: "Information Security Policies",
      code: "A.5.1.2",
      description: "The policies for information security shall be reviewed at planned intervals or if significant changes occur.",
      label: "Policy Review Process",
      scoring: 5,
      orderIndex: 2,
    },
    {
      domain: "A.5 Information Security Policies",
      category: "Information Security Policies",
      code: "A.5.1.3",
      description: "Management shall actively support security within the organization through clear direction, demonstrated commitment and explicit assignment.",
      label: "Management Commitment",
      scoring: 5,
      orderIndex: 3,
    },
    // A.6 Organisation of Information Security
    {
      domain: "A.6 Organisation of Info Security",
      category: "Organisation of Info Security",
      code: "A.6.1.1",
      description: "All information security responsibilities shall be defined and allocated.",
      label: "Information Security Roles",
      scoring: 5,
      orderIndex: 4,
    },
    {
      domain: "A.6 Organisation of Info Security",
      category: "Organisation of Info Security",
      code: "A.6.1.2",
      description: "Conflicting duties and areas of responsibility shall be segregated to reduce opportunities for unauthorised modification.",
      label: "Segregation of Duties",
      scoring: 5,
      orderIndex: 5,
    },
    {
      domain: "A.6 Organisation of Info Security",
      category: "Organisation of Info Security",
      code: "A.6.1.3",
      description: "Appropriate contacts with relevant authorities shall be maintained.",
      label: "Contact with Authorities",
      scoring: 5,
      orderIndex: 6,
    },
    // A.9 Access Control
    {
      domain: "A.9 Access Control",
      category: "Access Control",
      code: "A.9.1.1",
      description: "An access control policy shall be established, documented and reviewed based on business and information security requirements.",
      label: "Access Control Policy",
      scoring: 5,
      orderIndex: 7,
    },
    {
      domain: "A.9 Access Control",
      category: "Access Control",
      code: "A.9.2.1",
      description: "A formal user registration and de-registration process shall be implemented to enable assignment of access rights.",
      label: "User Registration & De-registration",
      scoring: 5,
      orderIndex: 8,
    },
    {
      domain: "A.9 Access Control",
      category: "Access Control",
      code: "A.9.4.1",
      description: "Access to information and application system functions shall be restricted in accordance with the access control policy.",
      label: "Information Access Restriction",
      scoring: 5,
      orderIndex: 9,
    },
    // A.12 Operations Security
    {
      domain: "A.12 Operations Security",
      category: "Operations Security",
      code: "A.12.1.1",
      description: "Operating procedures shall be documented and made available to all users who need them.",
      label: "Documented Operating Procedures",
      scoring: 5,
      orderIndex: 10,
    },
    {
      domain: "A.12 Operations Security",
      category: "Operations Security",
      code: "A.12.3.1",
      description: "Back-up copies of information, software and system images shall be taken and tested regularly.",
      label: "Information Backup",
      scoring: 5,
      orderIndex: 11,
    },
    {
      domain: "A.12 Operations Security",
      category: "Operations Security",
      code: "A.12.6.1",
      description: "Information about technical vulnerabilities of information systems in use shall be obtained in a timely fashion.",
      label: "Vulnerability Management",
      scoring: 5,
      orderIndex: 12,
    },
  ];

  const isoItemRecords: Array<{ id: string; domain: string; category: string; scoring: number }> = [];
  for (const item of isoItems) {
    const existing = await prisma.templateItem.findFirst({
      where: { templateId: isoTemplate.id, code: item.code },
    });
    if (existing) {
      isoItemRecords.push(existing);
    } else {
      const created = await prisma.templateItem.create({
        data: { templateId: isoTemplate.id, ...item },
      });
      isoItemRecords.push(created);
    }
  }

  // ── Helper: create a completed assessment with responses & scores ─────────

  async function createCompletedAssessment(
    title: string,
    profileId: string,
    templateId: string,
    items: Array<{ id: string; domain: string; category: string; scoring: number }>
  ) {
    // Check for existing assessment to keep seed idempotent
    const existing = await prisma.assessment.findFirst({
      where: { title, profileId, templateId },
    });
    if (existing) return existing;

    const assessment = await prisma.assessment.create({
      data: {
        title,
        profileId,
        templateId,
        createdById: assessor.id,
        status: AssessmentStatus.COMPLETED,
        completedAt: new Date(),
      },
    });

    // Create responses
    const responses: Array<{ itemId: string; score: number }> = [];
    for (const item of items) {
      const score = randomScore(2, 5);
      await prisma.assessmentResponse.create({
        data: {
          assessmentId: assessment.id,
          templateItemId: item.id,
          score,
          comment: randomComment(),
          isAnswered: true,
        },
      });
      responses.push({ itemId: item.id, score });
    }

    // ── Compute domain and category scores ───────────────────────────────

    // Group items by domain
    const domainMap = new Map<string, Array<{ itemId: string; score: number; category: string; maxScore: number }>>();
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const resp = responses[i];
      if (!domainMap.has(item.domain)) domainMap.set(item.domain, []);
      domainMap.get(item.domain)!.push({
        itemId: item.id,
        score: resp.score,
        category: item.category,
        maxScore: item.scoring,
      });
    }

    let totalScore = 0;
    let totalMax = 0;

    for (const [domain, domainItems] of domainMap) {
      const domainScore = domainItems.reduce((s, i) => s + i.score, 0);
      const domainMax = domainItems.reduce((s, i) => s + i.maxScore, 0);
      const domainPct = domainMax > 0 ? (domainScore / domainMax) * 100 : 0;

      await prisma.domainScore.upsert({
        where: {
          assessmentId_domain: { assessmentId: assessment.id, domain },
        },
        update: {
          score: domainScore,
          maxScore: domainMax,
          percentage: Math.round(domainPct * 100) / 100,
          itemCount: domainItems.length,
          answeredCount: domainItems.length,
        },
        create: {
          assessmentId: assessment.id,
          domain,
          score: domainScore,
          maxScore: domainMax,
          percentage: Math.round(domainPct * 100) / 100,
          itemCount: domainItems.length,
          answeredCount: domainItems.length,
        },
      });

      totalScore += domainScore;
      totalMax += domainMax;

      // Group by category within domain
      const catMap = new Map<string, Array<{ score: number; maxScore: number }>>();
      for (const di of domainItems) {
        if (!catMap.has(di.category)) catMap.set(di.category, []);
        catMap.get(di.category)!.push({ score: di.score, maxScore: di.maxScore });
      }

      for (const [category, catItems] of catMap) {
        const catScore = catItems.reduce((s, i) => s + i.score, 0);
        const catMax = catItems.reduce((s, i) => s + i.maxScore, 0);
        const catPct = catMax > 0 ? (catScore / catMax) * 100 : 0;

        await prisma.categoryScore.upsert({
          where: {
            assessmentId_domain_category: {
              assessmentId: assessment.id,
              domain,
              category,
            },
          },
          update: {
            score: catScore,
            maxScore: catMax,
            percentage: Math.round(catPct * 100) / 100,
            itemCount: catItems.length,
            answeredCount: catItems.length,
          },
          create: {
            assessmentId: assessment.id,
            domain,
            category,
            score: catScore,
            maxScore: catMax,
            percentage: Math.round(catPct * 100) / 100,
            itemCount: catItems.length,
            answeredCount: catItems.length,
          },
        });
      }
    }

    // Overall score as percentage
    const overallScore = totalMax > 0 ? Math.round((totalScore / totalMax) * 10000) / 100 : 0;

    await prisma.assessment.update({
      where: { id: assessment.id },
      data: { overallScore },
    });

    return assessment;
  }

  // ── Assessments ──────────────────────────────────────────────────────────

  // 1. ACME Corp – NIST CSF
  await createCompletedAssessment(
    "ACME Corporation NIST CSF Assessment",
    acme.id,
    nistTemplate.id,
    nistItemRecords
  );

  // 2. GlobalTech – ISO 27001
  await createCompletedAssessment(
    "GlobalTech Industries ISO 27001 Assessment",
    globalTech.id,
    isoTemplate.id,
    isoItemRecords
  );

  // 3. ACME Corp – ISO 27001 (second assessment for historical comparison)
  await createCompletedAssessment(
    "ACME Corporation ISO 27001 Assessment",
    acme.id,
    isoTemplate.id,
    isoItemRecords
  );

  // 4. HealthFirst Medical – DRAFT (no responses)
  await prisma.assessment.upsert({
    where: {
      id: (
        await prisma.assessment.findFirst({
          where: {
            title: "HealthFirst Medical NIST CSF Assessment",
            profileId: healthFirst.id,
            templateId: nistTemplate.id,
            status: AssessmentStatus.DRAFT,
          },
        })
      )?.id ?? "healthfirst-draft-seed",
    },
    update: {},
    create: {
      id: "healthfirst-draft-seed",
      title: "HealthFirst Medical NIST CSF Assessment",
      profileId: healthFirst.id,
      templateId: nistTemplate.id,
      createdById: assessor.id,
      status: AssessmentStatus.DRAFT,
    },
  });

  // ── System Settings ──────────────────────────────────────────────────────

  const settings = [
    { key: "app_name", value: "CSMA" },
    { key: "max_file_size_mb", value: "10" },
    { key: "session_timeout_hours", value: "8" },
  ];

  for (const setting of settings) {
    await prisma.systemSetting.upsert({
      where: { key: setting.key },
      update: { value: setting.value },
      create: { key: setting.key, value: setting.value },
    });
  }

  console.log("Seed complete");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
