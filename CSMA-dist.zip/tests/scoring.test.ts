import { describe, it, expect } from "vitest";
import {
  calculateScores,
  getScoreLabel,
  getScoreColor,
  type ResponseInput,
  type TemplateItemInput,
} from "../src/lib/scoring";

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const items: TemplateItemInput[] = [
  { id: "item-1", domain: "Identify", category: "Asset Management", scoring: 5 },
  { id: "item-2", domain: "Identify", category: "Asset Management", scoring: 5 },
  { id: "item-3", domain: "Protect", category: "Access Control", scoring: 10 },
  { id: "item-4", domain: "Protect", category: "Access Control", scoring: 10 },
  { id: "item-5", domain: "Detect", category: "Monitoring", scoring: 3 },
];

// ─── calculateScores ──────────────────────────────────────────────────────────

describe("calculateScores", () => {
  it("calculates correct overall score with all items answered", () => {
    const responses: ResponseInput[] = [
      { templateItemId: "item-1", score: 4, isAnswered: true },
      { templateItemId: "item-2", score: 3, isAnswered: true },
      { templateItemId: "item-3", score: 8, isAnswered: true },
      { templateItemId: "item-4", score: 7, isAnswered: true },
      { templateItemId: "item-5", score: 2, isAnswered: true },
    ];

    const result = calculateScores(items, responses);

    // Total max: 5+5+10+10+3 = 33
    // Total actual: 4+3+8+7+2 = 24
    expect(result.overallScore).toBe(24);
    expect(result.overallPercentage).toBeCloseTo((24 / 33) * 100, 4);
    expect(result.totalItems).toBe(5);
    expect(result.answeredItems).toBe(5);
    expect(result.completionPercentage).toBe(100);
  });

  it("handles unanswered items as zero score", () => {
    const responses: ResponseInput[] = [
      { templateItemId: "item-1", score: 5, isAnswered: true },
      { templateItemId: "item-2", score: null, isAnswered: false },
      { templateItemId: "item-3", score: null, isAnswered: false },
      { templateItemId: "item-4", score: null, isAnswered: false },
      { templateItemId: "item-5", score: null, isAnswered: false },
    ];

    const result = calculateScores(items, responses);

    // Only item-1 answered with score 5
    expect(result.overallScore).toBe(5);
    expect(result.answeredItems).toBe(1);
    // Overall percentage: 5 / 33 * 100
    expect(result.overallPercentage).toBeCloseTo((5 / 33) * 100, 4);
  });

  it("calculates domain scores correctly", () => {
    const responses: ResponseInput[] = [
      { templateItemId: "item-1", score: 4, isAnswered: true },
      { templateItemId: "item-2", score: 4, isAnswered: true },
      { templateItemId: "item-3", score: 5, isAnswered: true },
      { templateItemId: "item-4", score: 5, isAnswered: true },
      { templateItemId: "item-5", score: 3, isAnswered: true },
    ];

    const result = calculateScores(items, responses);

    // Identify domain: items 1+2 => scored 8, max 10
    expect(result.domainScores["Identify"]).toBeDefined();
    expect(result.domainScores["Identify"].score).toBe(8);
    expect(result.domainScores["Identify"].maxScore).toBe(10);
    expect(result.domainScores["Identify"].percentage).toBeCloseTo(80, 4);
    expect(result.domainScores["Identify"].itemCount).toBe(2);
    expect(result.domainScores["Identify"].answeredCount).toBe(2);

    // Protect domain: items 3+4 => scored 10, max 20
    expect(result.domainScores["Protect"]).toBeDefined();
    expect(result.domainScores["Protect"].score).toBe(10);
    expect(result.domainScores["Protect"].maxScore).toBe(20);
    expect(result.domainScores["Protect"].percentage).toBeCloseTo(50, 4);

    // Detect domain: item 5 => scored 3, max 3
    expect(result.domainScores["Detect"]).toBeDefined();
    expect(result.domainScores["Detect"].score).toBe(3);
    expect(result.domainScores["Detect"].maxScore).toBe(3);
    expect(result.domainScores["Detect"].percentage).toBeCloseTo(100, 4);
  });

  it("calculates category scores correctly", () => {
    const responses: ResponseInput[] = [
      { templateItemId: "item-1", score: 5, isAnswered: true },
      { templateItemId: "item-2", score: 3, isAnswered: true },
      { templateItemId: "item-3", score: 10, isAnswered: true },
      { templateItemId: "item-4", score: 0, isAnswered: true },
      { templateItemId: "item-5", score: 1, isAnswered: true },
    ];

    const result = calculateScores(items, responses);

    // Asset Management: items 1+2 => 5+3=8, max 10
    expect(result.categoryScores["Identify"]["Asset Management"]).toBeDefined();
    expect(result.categoryScores["Identify"]["Asset Management"].score).toBe(8);
    expect(result.categoryScores["Identify"]["Asset Management"].maxScore).toBe(10);
    expect(result.categoryScores["Identify"]["Asset Management"].percentage).toBeCloseTo(80, 4);

    // Access Control: items 3+4 => 10+0=10, max 20
    expect(result.categoryScores["Protect"]["Access Control"]).toBeDefined();
    expect(result.categoryScores["Protect"]["Access Control"].score).toBe(10);
    expect(result.categoryScores["Protect"]["Access Control"].maxScore).toBe(20);
    expect(result.categoryScores["Protect"]["Access Control"].percentage).toBeCloseTo(50, 4);
  });

  it("handles empty items array", () => {
    const result = calculateScores([], []);

    expect(result.overallScore).toBe(0);
    expect(result.overallPercentage).toBe(0);
    expect(result.totalItems).toBe(0);
    expect(result.answeredItems).toBe(0);
    expect(result.completionPercentage).toBe(0);
    expect(Object.keys(result.domainScores)).toHaveLength(0);
    expect(Object.keys(result.categoryScores)).toHaveLength(0);
  });

  it("calculates completion percentage correctly", () => {
    const responses: ResponseInput[] = [
      { templateItemId: "item-1", score: 5, isAnswered: true },
      { templateItemId: "item-2", score: 4, isAnswered: true },
      { templateItemId: "item-3", score: null, isAnswered: false },
      { templateItemId: "item-4", score: null, isAnswered: false },
      { templateItemId: "item-5", score: null, isAnswered: false },
    ];

    const result = calculateScores(items, responses);

    // 2 of 5 answered = 40%
    expect(result.answeredItems).toBe(2);
    expect(result.totalItems).toBe(5);
    expect(result.completionPercentage).toBeCloseTo(40, 4);
  });

  it("handles all zeros scenario", () => {
    const responses: ResponseInput[] = items.map((item) => ({
      templateItemId: item.id,
      score: 0,
      isAnswered: true,
    }));

    const result = calculateScores(items, responses);

    expect(result.overallScore).toBe(0);
    expect(result.overallPercentage).toBe(0);
    expect(result.answeredItems).toBe(5);
    expect(result.completionPercentage).toBe(100);

    // Domain percentages should all be 0
    for (const domain of Object.keys(result.domainScores)) {
      expect(result.domainScores[domain].percentage).toBe(0);
    }
  });

  it("handles perfect score scenario", () => {
    const responses: ResponseInput[] = items.map((item) => ({
      templateItemId: item.id,
      score: item.scoring,
      isAnswered: true,
    }));

    const result = calculateScores(items, responses);

    // Max score: 5+5+10+10+3 = 33
    expect(result.overallScore).toBe(33);
    expect(result.overallPercentage).toBeCloseTo(100, 4);
    expect(result.answeredItems).toBe(5);
    expect(result.completionPercentage).toBe(100);

    // All domain percentages should be 100
    for (const domain of Object.keys(result.domainScores)) {
      expect(result.domainScores[domain].percentage).toBeCloseTo(100, 4);
    }
  });

  it("ignores responses for items not in the items list", () => {
    const responses: ResponseInput[] = [
      { templateItemId: "item-1", score: 5, isAnswered: true },
      { templateItemId: "item-unknown-xyz", score: 99, isAnswered: true }, // should be ignored
    ];

    const result = calculateScores(items, responses);

    // Only item-1 contributes; total max is still 33
    expect(result.overallScore).toBe(5);
    expect(result.answeredItems).toBe(1);
  });
});

// ─── getScoreLabel ────────────────────────────────────────────────────────────

describe("getScoreLabel", () => {
  it("returns Critical for 0-20", () => {
    expect(getScoreLabel(0)).toBe("Critical");
    expect(getScoreLabel(10)).toBe("Critical");
    expect(getScoreLabel(20)).toBe("Critical");
  });

  it("returns Low for 21-40", () => {
    expect(getScoreLabel(21)).toBe("Low");
    expect(getScoreLabel(30)).toBe("Low");
    expect(getScoreLabel(40)).toBe("Low");
  });

  it("returns Moderate for 41-60", () => {
    expect(getScoreLabel(41)).toBe("Moderate");
    expect(getScoreLabel(50)).toBe("Moderate");
    expect(getScoreLabel(60)).toBe("Moderate");
  });

  it("returns Good for 61-80", () => {
    expect(getScoreLabel(61)).toBe("Good");
    expect(getScoreLabel(70)).toBe("Good");
    expect(getScoreLabel(80)).toBe("Good");
  });

  it("returns Excellent for 81-100", () => {
    expect(getScoreLabel(81)).toBe("Excellent");
    expect(getScoreLabel(90)).toBe("Excellent");
    expect(getScoreLabel(100)).toBe("Excellent");
  });

  it("handles boundary values exactly", () => {
    // Boundary at 20/21
    expect(getScoreLabel(20)).toBe("Critical");
    expect(getScoreLabel(20.1)).toBe("Low");

    // Boundary at 40/41
    expect(getScoreLabel(40)).toBe("Low");
    expect(getScoreLabel(40.1)).toBe("Moderate");

    // Boundary at 60/61
    expect(getScoreLabel(60)).toBe("Moderate");
    expect(getScoreLabel(60.1)).toBe("Good");

    // Boundary at 80/81
    expect(getScoreLabel(80)).toBe("Good");
    expect(getScoreLabel(80.1)).toBe("Excellent");
  });
});

// ─── getScoreColor ────────────────────────────────────────────────────────────

describe("getScoreColor", () => {
  it("returns correct color classes for each tier", () => {
    // Critical (0-20)
    expect(getScoreColor(0)).toBe("red-500");
    expect(getScoreColor(15)).toBe("red-500");
    expect(getScoreColor(20)).toBe("red-500");

    // Low (21-40)
    expect(getScoreColor(21)).toBe("orange-500");
    expect(getScoreColor(35)).toBe("orange-500");
    expect(getScoreColor(40)).toBe("orange-500");

    // Moderate (41-60)
    expect(getScoreColor(41)).toBe("yellow-500");
    expect(getScoreColor(55)).toBe("yellow-500");
    expect(getScoreColor(60)).toBe("yellow-500");

    // Good (61-80)
    expect(getScoreColor(61)).toBe("green-500");
    expect(getScoreColor(70)).toBe("green-500");
    expect(getScoreColor(80)).toBe("green-500");

    // Excellent (81-100)
    expect(getScoreColor(81)).toBe("emerald-500");
    expect(getScoreColor(95)).toBe("emerald-500");
    expect(getScoreColor(100)).toBe("emerald-500");
  });

  it("returns different colors for Critical and Low tiers", () => {
    expect(getScoreColor(20)).not.toBe(getScoreColor(21));
  });

  it("returns different colors for Low and Moderate tiers", () => {
    expect(getScoreColor(40)).not.toBe(getScoreColor(41));
  });

  it("returns different colors for Good and Excellent tiers", () => {
    expect(getScoreColor(80)).not.toBe(getScoreColor(81));
  });
});
