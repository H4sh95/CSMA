import { describe, it, expect } from "vitest";
import {
  canModifyProfile,
  canManageTemplates,
  isAdmin,
  canCreateAssessment,
} from "../src/lib/permissions";
import { Role } from "@prisma/client";
import type { SessionUser } from "../src/types";

// ─── Mock user factory ────────────────────────────────────────────────────────

function makeUser(role: Role): SessionUser {
  return {
    id: `user-${role.toLowerCase()}`,
    email: `${role.toLowerCase()}@csma.test`,
    name: `Test ${role}`,
    role,
  };
}

const adminUser = makeUser(Role.ADMIN);
const assessorUser = makeUser(Role.ASSESSOR);
const customerUser = makeUser(Role.CUSTOMER);

// ─── isAdmin ──────────────────────────────────────────────────────────────────

describe("isAdmin", () => {
  it("returns true for ADMIN role", () => {
    expect(isAdmin(adminUser)).toBe(true);
  });

  it("returns false for ASSESSOR role", () => {
    expect(isAdmin(assessorUser)).toBe(false);
  });

  it("returns false for CUSTOMER role", () => {
    expect(isAdmin(customerUser)).toBe(false);
  });
});

// ─── canModifyProfile ─────────────────────────────────────────────────────────

describe("canModifyProfile", () => {
  it("returns true for ADMIN", () => {
    expect(canModifyProfile(adminUser)).toBe(true);
  });

  it("returns true for ASSESSOR", () => {
    expect(canModifyProfile(assessorUser)).toBe(true);
  });

  it("returns false for CUSTOMER", () => {
    expect(canModifyProfile(customerUser)).toBe(false);
  });
});

// ─── canManageTemplates ───────────────────────────────────────────────────────

describe("canManageTemplates", () => {
  it("returns true for ADMIN", () => {
    expect(canManageTemplates(adminUser)).toBe(true);
  });

  it("returns true for ASSESSOR", () => {
    expect(canManageTemplates(assessorUser)).toBe(true);
  });

  it("returns false for CUSTOMER", () => {
    expect(canManageTemplates(customerUser)).toBe(false);
  });
});

// ─── canCreateAssessment ──────────────────────────────────────────────────────

describe("canCreateAssessment", () => {
  it("returns true for ADMIN", () => {
    expect(canCreateAssessment(adminUser)).toBe(true);
  });

  it("returns true for ASSESSOR", () => {
    expect(canCreateAssessment(assessorUser)).toBe(true);
  });

  it("returns false for CUSTOMER", () => {
    expect(canCreateAssessment(customerUser)).toBe(false);
  });
});

// ─── Combined role capability matrix ─────────────────────────────────────────

describe("Role capability matrix", () => {
  it("ADMIN has all permissions", () => {
    expect(isAdmin(adminUser)).toBe(true);
    expect(canModifyProfile(adminUser)).toBe(true);
    expect(canManageTemplates(adminUser)).toBe(true);
    expect(canCreateAssessment(adminUser)).toBe(true);
  });

  it("ASSESSOR has operational permissions but is not admin", () => {
    expect(isAdmin(assessorUser)).toBe(false);
    expect(canModifyProfile(assessorUser)).toBe(true);
    expect(canManageTemplates(assessorUser)).toBe(true);
    expect(canCreateAssessment(assessorUser)).toBe(true);
  });

  it("CUSTOMER has no modification permissions", () => {
    expect(isAdmin(customerUser)).toBe(false);
    expect(canModifyProfile(customerUser)).toBe(false);
    expect(canManageTemplates(customerUser)).toBe(false);
    expect(canCreateAssessment(customerUser)).toBe(false);
  });

  it("ADMIN and ASSESSOR share the same operational permissions", () => {
    const operationalChecks = [canModifyProfile, canManageTemplates, canCreateAssessment];
    for (const check of operationalChecks) {
      expect(check(adminUser)).toBe(check(assessorUser));
    }
  });

  it("only ADMIN passes isAdmin check", () => {
    const allUsers = [adminUser, assessorUser, customerUser];
    const adminUsers = allUsers.filter((u) => isAdmin(u));
    expect(adminUsers).toHaveLength(1);
    expect(adminUsers[0].role).toBe(Role.ADMIN);
  });

  it("CUSTOMER is distinct from both ADMIN and ASSESSOR for all checks", () => {
    const checks = [canModifyProfile, canManageTemplates, canCreateAssessment, isAdmin];
    for (const check of checks) {
      // Both admin and assessor should differ from customer on these
      if (check === canModifyProfile || check === canManageTemplates || check === canCreateAssessment) {
        expect(check(adminUser)).not.toBe(check(customerUser));
        expect(check(assessorUser)).not.toBe(check(customerUser));
      }
    }
  });
});

// ─── Edge cases ───────────────────────────────────────────────────────────────

describe("Permission helpers with various user shapes", () => {
  it("works with minimal session user objects", () => {
    const minimalAdmin: SessionUser = { id: "a", email: "a@a.com", name: "A", role: Role.ADMIN };
    const minimalCustomer: SessionUser = { id: "b", email: "b@b.com", name: "B", role: Role.CUSTOMER };

    expect(isAdmin(minimalAdmin)).toBe(true);
    expect(isAdmin(minimalCustomer)).toBe(false);
  });

  it("does not mutate the user object", () => {
    const user = makeUser(Role.ASSESSOR);
    const originalRole = user.role;
    canModifyProfile(user);
    canManageTemplates(user);
    canCreateAssessment(user);
    expect(user.role).toBe(originalRole);
  });
});
