import { describe, it, expect } from "vitest";
import { parseXlsxTemplate } from "../src/lib/xlsx-parser";
import * as XLSX from "xlsx";

// ─── Helper ───────────────────────────────────────────────────────────────────

function makeXlsxBuffer(rows: unknown[][]): Buffer {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  return Buffer.from(XLSX.write(wb, { type: "buffer", bookType: "xlsx" }));
}

// Standard valid header row
const VALID_HEADERS = ["Domain", "Category", "Code", "Description", "Label", "Scoring"];

// A single complete valid data row
function makeValidRow(overrides: Partial<Record<string, unknown>> = {}): unknown[] {
  const defaults = {
    Domain: "Identify",
    Category: "Asset Management",
    Code: "ID.AM-1",
    Description: "Physical devices and systems within the organization are inventoried.",
    Label: "Asset Inventory",
    Scoring: 5,
  };
  const merged = { ...defaults, ...overrides };
  return VALID_HEADERS.map((h) => merged[h as keyof typeof merged]);
}

// ─── parseXlsxTemplate ────────────────────────────────────────────────────────

describe("parseXlsxTemplate", () => {
  it("parses valid XLSX with correct columns", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow(),
      makeValidRow({ Code: "ID.AM-2", Label: "Software Inventory", Description: "Software platforms inventoried." }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.rows).toHaveLength(2);

    const first = result.rows[0];
    expect(first.domain).toBe("Identify");
    expect(first.category).toBe("Asset Management");
    expect(first.code).toBe("ID.AM-1");
    expect(first.scoring).toBe(5);
    expect(first.orderIndex).toBe(0);

    const second = result.rows[1];
    expect(second.code).toBe("ID.AM-2");
    expect(second.orderIndex).toBe(1);
  });

  it("rejects XLSX missing required Domain column", () => {
    const headersWithoutDomain = ["Category", "Code", "Description", "Label", "Scoring"];
    const buffer = makeXlsxBuffer([
      headersWithoutDomain,
      ["Asset Management", "ID.AM-1", "Desc", "Label", 5],
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(result.errors.some((e) => e.toLowerCase().includes("domain"))).toBe(true);
    expect(result.rows).toHaveLength(0);
  });

  it("rejects XLSX missing required Category column", () => {
    const headersWithoutCategory = ["Domain", "Code", "Description", "Label", "Scoring"];
    const buffer = makeXlsxBuffer([
      headersWithoutCategory,
      ["Identify", "ID.AM-1", "Desc", "Label", 5],
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.toLowerCase().includes("category"))).toBe(true);
  });

  it("rejects rows with empty Code field", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow({ Code: "" }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(result.errors.some((e) => e.toLowerCase().includes("code"))).toBe(true);
    expect(result.rows).toHaveLength(0);
  });

  it("rejects rows with invalid scoring (non-numeric)", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow({ Scoring: "not-a-number" }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(result.errors.some((e) => e.toLowerCase().includes("scoring"))).toBe(true);
    expect(result.rows).toHaveLength(0);
  });

  it("rejects rows with zero scoring", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow({ Scoring: 0 }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.toLowerCase().includes("scoring"))).toBe(true);
  });

  it("rejects rows with negative scoring", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow({ Scoring: -5 }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.toLowerCase().includes("scoring"))).toBe(true);
  });

  it("skips entirely empty rows", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow(),
      ["", "", "", "", "", ""],  // empty row
      makeValidRow({ Code: "ID.AM-2", Label: "Second Item" }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(true);
    expect(result.rows).toHaveLength(2);
    expect(result.rows[0].code).toBe("ID.AM-1");
    expect(result.rows[1].code).toBe("ID.AM-2");
  });

  it("trims whitespace from values", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      [
        "  Identify  ",
        "  Asset Management  ",
        "  ID.AM-1  ",
        "  A description with spaces  ",
        "  Asset Inventory  ",
        5,
      ],
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(true);
    expect(result.rows).toHaveLength(1);
    expect(result.rows[0].domain).toBe("Identify");
    expect(result.rows[0].category).toBe("Asset Management");
    expect(result.rows[0].code).toBe("ID.AM-1");
    expect(result.rows[0].label).toBe("Asset Inventory");
  });

  it("returns correct orderIndex for each row", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow({ Code: "A" }),
      makeValidRow({ Code: "B" }),
      makeValidRow({ Code: "C" }),
      ["", "", "", "", "", ""],  // empty row - should be skipped
      makeValidRow({ Code: "D" }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(true);
    expect(result.rows).toHaveLength(4);
    expect(result.rows[0].orderIndex).toBe(0);
    expect(result.rows[1].orderIndex).toBe(1);
    expect(result.rows[2].orderIndex).toBe(2);
    expect(result.rows[3].orderIndex).toBe(3);
  });

  it("handles case-insensitive column headers", () => {
    const lowerHeaders = ["domain", "category", "code", "description", "label", "scoring"];
    const buffer = makeXlsxBuffer([
      lowerHeaders,
      makeValidRow(),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(true);
    expect(result.rows).toHaveLength(1);
    expect(result.rows[0].domain).toBe("Identify");
  });

  it("handles mixed-case column headers", () => {
    const mixedHeaders = ["DOMAIN", "CATEGORY", "CODE", "DESCRIPTION", "LABEL", "SCORING"];
    const buffer = makeXlsxBuffer([
      mixedHeaders,
      makeValidRow(),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(true);
    expect(result.rows).toHaveLength(1);
  });

  it("returns valid:false with error for empty workbook", () => {
    // Write an XLSX with header row only (no data rows)
    const buffer = makeXlsxBuffer([VALID_HEADERS]);
    const result = parseXlsxTemplate(buffer);

    // No data rows — should warn but still be valid (empty rows warning)
    // Per the implementation: rows.length === 0 && errors.length === 0 => warnings
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.rows).toHaveLength(0);
  });

  it("accumulates errors across multiple invalid rows and does not include those rows", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow(),                           // row 2: valid
      makeValidRow({ Code: "" }),               // row 3: invalid - missing code
      makeValidRow({ Scoring: "bad" }),         // row 4: invalid - bad scoring
      makeValidRow({ Code: "ID.AM-4" }),        // row 5: valid
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThanOrEqual(2);
    // Only the two valid rows should be in the result... actually per implementation
    // when hasRowError rows are skipped, so rows count = valid rows only:
    expect(result.rows.length).toBeLessThan(4);
  });

  it("accepts decimal scoring values", () => {
    const buffer = makeXlsxBuffer([
      VALID_HEADERS,
      makeValidRow({ Scoring: 2.5 }),
    ]);

    const result = parseXlsxTemplate(buffer);

    expect(result.valid).toBe(true);
    expect(result.rows[0].scoring).toBe(2.5);
  });

  it("returns an error for invalid XLSX buffer", () => {
    const invalidBuffer = Buffer.from("this is not a valid xlsx file at all !!!!!");
    const result = parseXlsxTemplate(invalidBuffer);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(result.rows).toHaveLength(0);
  });
});
