# CSMA — Cybersecurity Maturity Assessment Framework

A full-stack web application for conducting, tracking, and reporting on structured cybersecurity maturity assessments. Built with Next.js 15 App Router, TypeScript, Prisma ORM, PostgreSQL, and shadcn/ui.

---

## Features

- **Role-based access control** — Admin, Assessor, and Customer roles with fine-grained permissions
- **XLSX template upload** — Upload custom assessment templates in a structured spreadsheet format
- **Structured assessments** — Conduct assessments grouped by Domain > Category > Item with auto-save
- **Scoring engine** — Pure TypeScript scoring logic with domain/category breakdowns
- **Results & reporting** — Domain bar charts, historical trend lines, strengths/weaknesses analysis
- **PDF & XLSX export** — One-click export of completed assessment results
- **Audit logging** — Complete activity trail for all user actions
- **Customer profile management** — Manage customer organisations and link users to profiles
- **Admin panel** — User management, audit log viewer, system settings

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Browser (React 19)                        │
│  ┌──────────────┐  ┌─────────────────┐  ┌────────────────────┐  │
│  │  Dashboard   │  │  Assessments    │  │  Results / Charts  │  │
│  │  /dashboard  │  │  /assessments/* │  │  /results/*        │  │
│  └──────────────┘  └─────────────────┘  └────────────────────┘  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │   Admin Panel:  /admin/users  /admin/audit-logs          │   │
│  │                 /admin/settings                          │   │
│  └──────────────────────────────────────────────────────────┘   │
└───────────────────────────────┬─────────────────────────────────┘
                                │ fetch()
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Next.js 15 App Router (API)                    │
│  /api/assessments/*   /api/results/*   /api/profiles/*           │
│  /api/templates/*     /api/admin/*     /api/auth/*               │
│                                                                  │
│  Auth:  NextAuth v5 (JWT)     Middleware: route protection       │
│  Lib:   scoring.ts  xlsx-parser.ts  permissions.ts  audit.ts     │
└───────────────────────────────┬─────────────────────────────────┘
                                │ Prisma ORM
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                     PostgreSQL Database                          │
│  User  CustomerProfile  Template  Assessment  AuditLog           │
│  AssessmentResponse  DomainScore  CategoryScore  SystemSetting   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 15 (App Router, Server Components) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 3 + shadcn/ui |
| Auth | NextAuth v5 (Credentials, JWT) |
| ORM | Prisma 5 |
| Database | PostgreSQL 15+ |
| Charts | Recharts 2 |
| Forms | React Hook Form + Zod |
| PDF Export | jsPDF + jspdf-autotable |
| XLSX | xlsx (SheetJS) |
| Testing | Vitest |
| Containerisation | Docker + docker-compose |

---

## Database Schema Summary

| Model | Purpose |
|---|---|
| `User` | Platform users with role (ADMIN / ASSESSOR / CUSTOMER) |
| `CustomerProfile` | Organisations being assessed |
| `UserCustomerAccess` | Links CUSTOMER users to their accessible profiles |
| `AssessorAssignment` | Links ASSESSOR users to profiles they manage |
| `Template` | Assessment template metadata (uploaded from XLSX) |
| `TemplateItem` | Individual assessment items (Domain / Category / Code / Scoring) |
| `Assessment` | An instance of a template being applied to a profile |
| `AssessmentResponse` | Per-item responses (score, comment, evidence) |
| `DomainScore` | Aggregated domain-level scores for a completed assessment |
| `CategoryScore` | Aggregated category-level scores for a completed assessment |
| `AuditLog` | Full activity log (action, user, entity, IP) |
| `SystemSetting` | Key-value application configuration |

---

## Setup Instructions

### Prerequisites

- Node.js 20+
- Docker & Docker Compose (recommended) or PostgreSQL 15+

### 1. Clone & Install

```bash
git clone <repo-url>
cd CSMA
npm install
```

### 2. Configure Environment

Copy the example environment file and fill in the values:

```bash
cp .env.example .env
```

Required variables:

```env
# Database
DATABASE_URL="postgresql://csma:csma_password@localhost:5432/csma?schema=public"

# NextAuth
AUTH_SECRET="generate-a-secure-random-string-here"
NEXTAUTH_URL="http://localhost:3000"
```

Generate a secure `AUTH_SECRET`:

```bash
openssl rand -base64 32
```

### 3. Docker (Recommended)

Start the full stack (app + database) in one command:

```bash
docker-compose up -d
```

The application will be available at `http://localhost:3000`.

To seed the database with default data:

```bash
docker-compose exec app npm run db:seed
```

### 4. Manual Setup

If you prefer to run without Docker:

```bash
# 1. Ensure PostgreSQL is running and the DATABASE_URL is set

# 2. Generate Prisma client
npm run db:generate

# 3. Apply migrations
npm run db:migrate

# 4. Seed the database
npm run db:seed

# 5. Start the development server
npm run dev
```

The application will be available at `http://localhost:3000`.

---

## Default Credentials

After running `npm run db:seed`:

| Role | Email | Password |
|---|---|---|
| Admin | admin@csma.local | Admin123! |
| Assessor | assessor@csma.local | Assessor123! |
| Customer | customer@csma.local | Customer123! |

> **Security notice:** Change all default passwords before any non-local deployment.

---

## API Route Summary

### Assessments

| Method | Route | Description |
|---|---|---|
| GET | `/api/assessments` | List assessments (role-filtered, paginated) |
| POST | `/api/assessments` | Create new assessment |
| GET | `/api/assessments/:id` | Get assessment with full details |
| PATCH | `/api/assessments/:id` | Update assessment metadata |
| DELETE | `/api/assessments/:id` | Archive assessment (ADMIN only) |
| POST | `/api/assessments/:id/responses` | Batch save responses |
| POST | `/api/assessments/:id/submit` | Submit and finalise assessment |

### Results

| Method | Route | Description |
|---|---|---|
| GET | `/api/results` | List completed assessments (role-filtered) |
| GET | `/api/results/:id` | Get full result with history |
| GET | `/api/results/:id/export` | Export PDF or XLSX (`?format=pdf\|xlsx`) |

### Profiles

| Method | Route | Description |
|---|---|---|
| GET | `/api/profiles` | List profiles |
| POST | `/api/profiles` | Create profile |
| GET | `/api/profiles/:id` | Get profile |
| PUT | `/api/profiles/:id` | Update profile |
| GET | `/api/profiles/:id/assessors` | List assigned assessors |

### Templates

| Method | Route | Description |
|---|---|---|
| GET | `/api/templates` | List templates |
| POST | `/api/templates` | Upload new template (multipart XLSX) |
| GET | `/api/templates/:id` | Get template |
| PATCH | `/api/templates/:id` | Update status (activate/archive) |
| GET | `/api/templates/:id/preview` | Preview parsed items |

### Admin

| Method | Route | Description |
|---|---|---|
| GET | `/api/admin/users` | List users |
| POST | `/api/admin/users` | Create user |
| GET/PUT | `/api/admin/users/:id` | Get / update user |
| POST | `/api/admin/users/:id/reset-password` | Reset password |
| GET | `/api/admin/users/:id/customer-access` | List/manage customer profile access |
| GET | `/api/admin/audit-logs` | List audit log entries |
| GET/PUT | `/api/admin/settings` | Get / update system settings |

### Auth

| Method | Route | Description |
|---|---|---|
| POST | `/api/auth/[...nextauth]` | NextAuth credentials handler |
| GET | `/api/auth/me` | Current session user |
| GET | `/api/dashboard` | Role-aware dashboard statistics |

---

## Role Permissions

| Permission | ADMIN | ASSESSOR | CUSTOMER |
|---|:---:|:---:|:---:|
| Login | Yes | Yes | Yes |
| View own profile assessments | Yes | Yes | Yes |
| View all assessments | Yes | - | - |
| Create assessments | Yes | Yes | - |
| Submit assessments | Yes | Yes | - |
| View results | Yes | Yes | Yes* |
| Export results | Yes | Yes | Yes* |
| Manage profiles | Yes | Yes | - |
| Upload templates | Yes | Yes | - |
| Activate/archive templates | Yes | Yes | - |
| Manage users | Yes | - | - |
| View audit logs | Yes | - | - |
| Manage settings | Yes | - | - |

\* Customers can only view results for profiles they are linked to.

---

## Development Workflow

```bash
# Run development server with hot reload
npm run dev

# Type check (no emit)
npm run typecheck

# Lint
npm run lint

# Open Prisma Studio (DB browser)
npm run db:studio

# Reset database and re-seed (destructive)
npm run db:reset && npm run db:seed

# Generate sample XLSX template file
tsx scripts/create-sample-xlsx.ts
```

---

## Tests

Tests are written with Vitest and cover the pure library functions (no DB or network dependencies).

```bash
# Run all tests once
npm test

# Run in watch mode
npm run test:watch

# Run with coverage report
npm run test:coverage
```

Test files are located in `tests/`:

| File | Covers |
|---|---|
| `tests/scoring.test.ts` | `src/lib/scoring.ts` — score calculation, labels, colors |
| `tests/xlsx-parser.test.ts` | `src/lib/xlsx-parser.ts` — template parsing and validation |
| `tests/auth-roles.test.ts` | `src/lib/permissions.ts` — role-based permission helpers |

---

## Deployment Notes

### Environment

- Set `NODE_ENV=production`
- Generate a strong `AUTH_SECRET` (at least 32 random bytes)
- Set `NEXTAUTH_URL` to the public URL of the application

### Database

- Use `npm run db:migrate:prod` (not `db:push`) for production migrations
- Back up the database before running migrations

### File Uploads

- XLSX uploads are stored in the `uploads/` directory relative to the application root
- Ensure this directory is writable by the Node.js process
- For multi-instance deployments, mount a shared volume for `uploads/`

### Docker Production

```bash
# Build production image
docker build -t csma:latest .

# Run with environment variables
docker run -d \
  -p 3000:3000 \
  -e DATABASE_URL="..." \
  -e AUTH_SECRET="..." \
  -e NEXTAUTH_URL="https://your-domain.com" \
  -v csma-uploads:/app/uploads \
  csma:latest
```

### Reverse Proxy

Configure your reverse proxy (nginx / Caddy / etc.) to:
- Proxy requests to port 3000
- Set appropriate timeout values for long-running XLSX uploads (minimum 60s)
- Enable HTTPS with a valid TLS certificate
