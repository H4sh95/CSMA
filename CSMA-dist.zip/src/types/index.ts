// Re-export all Prisma enums
export {
  Role,
  ProfileStatus,
  TemplateStatus,
  AssessmentStatus,
  AuditAction,
} from "@prisma/client";

// Re-export Prisma model types
export type {
  User,
  CustomerProfile,
  Template,
  TemplateItem,
  Assessment,
  AssessmentResponse,
  DomainScore,
  CategoryScore,
  AuditLog,
  SystemSetting,
  UserCustomerAccess,
  AssessorAssignment,
  Session,
} from "@prisma/client";

import type {
  Role,
  Assessment,
  CustomerProfile,
  Template,
  TemplateItem,
  AssessmentResponse,
  DomainScore,
  CategoryScore,
  User,
} from "@prisma/client";

// ─── Session / Auth ──────────────────────────────────────────────────────────

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: Role;
};

// ─── API Responses ───────────────────────────────────────────────────────────

export type ApiResponse<T> = {
  data?: T;
  error?: string;
  message?: string;
};

export type PaginatedResponse<T> = {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

// ─── Template Parsing ────────────────────────────────────────────────────────

export type ParsedTemplateRow = {
  domain: string;
  category: string;
  code: string;
  description: string;
  label: string;
  scoring: number;
  orderIndex: number;
};

export type XlsxValidationResult = {
  valid: boolean;
  rows: ParsedTemplateRow[];
  errors: string[];
  warnings: string[];
};

// ─── Scoring ─────────────────────────────────────────────────────────────────

export type DomainScoreMap = Record<
  string,
  {
    score: number;
    maxScore: number;
    percentage: number;
    itemCount: number;
    answeredCount: number;
  }
>;

export type CategoryScoreMap = Record<
  string,
  Record<
    string,
    {
      score: number;
      maxScore: number;
      percentage: number;
      itemCount: number;
      answeredCount: number;
    }
  >
>;

export type ScoreResult = {
  overallScore: number;
  overallPercentage: number;
  domainScores: DomainScoreMap;
  categoryScores: CategoryScoreMap;
  totalItems: number;
  answeredItems: number;
  completionPercentage: number;
};

// ─── Dashboard ───────────────────────────────────────────────────────────────

export type DashboardStats = {
  totalAssessments: number;
  totalProfiles: number;
  totalTemplates: number;
  averageScore: number;
  completionBreakdown: {
    DRAFT: number;
    IN_PROGRESS: number;
    COMPLETED: number;
    ARCHIVED: number;
  };
  domainScores: Array<{
    domain: string;
    score: number;
    maxScore: number;
    percentage: number;
  }>;
  recentAssessments: Array<{
    id: string;
    title: string;
    profileName: string;
    status: string;
    overallScore: number | null;
    createdAt: Date;
    updatedAt: Date;
  }>;
  attentionItems: Array<{
    id: string;
    title: string;
    profileName: string;
    status: string;
    dueDate: Date | null;
    overallScore: number | null;
  }>;
};

// ─── Assessment with Relations ───────────────────────────────────────────────

export type AssessmentWithRelations = Assessment & {
  profile: CustomerProfile;
  template: Template & {
    items: TemplateItem[];
  };
  createdBy: Pick<User, "id" | "name" | "email">;
  responses: (AssessmentResponse & {
    templateItem: TemplateItem;
  })[];
  domainScores: DomainScore[];
  categoryScores: CategoryScore[];
};

// ─── Filters ─────────────────────────────────────────────────────────────────

export type FilterParams = {
  search?: string;
  status?: string;
  profileId?: string;
  templateId?: string;
  assessorId?: string;
  dateFrom?: string;
  dateTo?: string;
  scoreMin?: number;
  scoreMax?: number;
  page?: number;
  pageSize?: number;
};
