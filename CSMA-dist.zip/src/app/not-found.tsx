import Link from "next/link";
import { Shield } from "lucide-react";

export default function NotFoundPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-6 max-w-md text-center px-4">
        <div className="flex items-center justify-center w-20 h-20 rounded-full bg-muted">
          <Shield className="w-10 h-10 text-muted-foreground" />
        </div>
        <div className="space-y-2">
          <p className="text-7xl font-extrabold text-primary">404</p>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Page Not Found
          </h1>
          <p className="text-muted-foreground">
            The page you are looking for does not exist or may have been moved.
            Check the URL and try again.
          </p>
        </div>
        <Link
          href="/"
          className="inline-flex items-center justify-center rounded-md bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground shadow-sm transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Go Home
        </Link>
      </div>
    </div>
  );
}
