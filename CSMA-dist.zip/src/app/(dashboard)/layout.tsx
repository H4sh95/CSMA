"use client";

import * as React from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { cn } from "@/lib/utils";
import { usePathname } from "next/navigation";

// ---------------------------------------------------------------------------
// Route title mapping
// ---------------------------------------------------------------------------

const ROUTE_TITLES: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/profiles": "Profiles",
  "/templates": "Templates",
  "/assessments": "Assessments",
  "/results": "Results",
  "/admin": "Admin",
};

function getPageTitle(pathname: string): string {
  // Exact match first
  if (ROUTE_TITLES[pathname]) return ROUTE_TITLES[pathname];

  // Prefix match for nested routes
  const segments = pathname.split("/").filter(Boolean);
  if (segments.length > 0) {
    const topLevel = `/${segments[0]}`;
    if (ROUTE_TITLES[topLevel]) return ROUTE_TITLES[topLevel];
  }

  return "CSMA";
}

// ---------------------------------------------------------------------------
// Client shell
// ---------------------------------------------------------------------------

interface DashboardShellProps {
  children: React.ReactNode;
}

function DashboardShell({ children }: DashboardShellProps) {
  const pathname = usePathname();
  const [sidebarCollapsed, setSidebarCollapsed] = React.useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = React.useState(false);

  const pageTitle = getPageTitle(pathname);

  const handleToggleSidebar = () => {
    // On mobile, toggle open/close overlay
    // On desktop, toggle collapsed/expanded
    setMobileSidebarOpen((prev) => !prev);
  };

  const handleDesktopToggle = () => {
    setSidebarCollapsed((prev) => !prev);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Mobile sidebar overlay */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => setMobileSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Sidebar — desktop: always visible, mobile: slide in */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-50 md:relative md:z-auto md:flex md:flex-shrink-0",
          "transition-transform duration-300 ease-in-out",
          mobileSidebarOpen
            ? "translate-x-0"
            : "-translate-x-full md:translate-x-0"
        )}
      >
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={handleDesktopToggle}
        />
      </div>

      {/* Main content area */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <Header
          title={pageTitle}
          onToggleSidebar={handleToggleSidebar}
        />
        <main className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Server layout (default export required by Next.js)
// ---------------------------------------------------------------------------

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <DashboardShell>{children}</DashboardShell>;
}
