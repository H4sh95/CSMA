"use client";

import { useEffect, useState, useCallback } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import {
  Plus,
  Search,
  Edit2,
  Lock,
  UserCheck,
  UserX,
  Link2,
  ChevronLeft,
  ChevronRight,
  Shield,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useDebounce } from "@/hooks/use-debounce";
import { formatDate, formatDateTime } from "@/lib/utils";
import { Role } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

interface UserRecord {
  id: string;
  name: string;
  email: string;
  role: string;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
}

interface UserFormState {
  name: string;
  email: string;
  role: string;
  password: string;
  isActive: boolean;
}

interface ProfileAccess {
  id: string;
  profile: { id: string; name: string; identifier: string };
}

const PAGE_SIZE = 25;

// ─── Role badge ───────────────────────────────────────────────────────────────

function RoleBadge({ role }: { role: string }) {
  const variantMap: Record<string, string> = {
    ADMIN: "bg-red-100 text-red-800 border-red-200",
    ASSESSOR: "bg-slate-100 text-slate-700 border-slate-200",
    CUSTOMER: "bg-gray-100 text-gray-700 border-gray-200",
  };
  return (
    <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${variantMap[role] ?? "bg-muted"}`}>
      {role}
    </span>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function UserManagementPage() {
  const { data: session } = useSession();
  const { toast } = useToast();

  const role = (session?.user as { role?: string })?.role;
  const isAdmin = role === Role.ADMIN;

  // ── Filters ─────────────────────────────────────────────────────────────────
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const debouncedSearch = useDebounce(search, 350);

  // ── Data ─────────────────────────────────────────────────────────────────────
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  // ── Modals ────────────────────────────────────────────────────────────────────
  const [userModal, setUserModal] = useState<{ open: boolean; user: UserRecord | null }>({ open: false, user: null });
  const [formState, setFormState] = useState<UserFormState>({ name: "", email: "", role: Role.ASSESSOR, password: "", isActive: true });
  const [formErrors, setFormErrors] = useState<Partial<UserFormState>>({});
  const [savingUser, setSavingUser] = useState(false);

  const [resetModal, setResetModal] = useState<{ open: boolean; user: UserRecord | null; tempPassword: string | null }>({ open: false, user: null, tempPassword: null });
  const [resettingPassword, setResettingPassword] = useState(false);

  const [toggleModal, setToggleModal] = useState<{ open: boolean; user: UserRecord | null }>({ open: false, user: null });
  const [togglingStatus, setTogglingStatus] = useState(false);

  const [accessModal, setAccessModal] = useState<{ open: boolean; user: UserRecord | null; accesses: ProfileAccess[] }>({ open: false, user: null, accesses: [] });
  const [loadingAccess, setLoadingAccess] = useState(false);

  // ── Fetch users ───────────────────────────────────────────────────────────────
  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(PAGE_SIZE) });
      if (debouncedSearch) params.set("search", debouncedSearch);
      if (roleFilter !== "ALL") params.set("role", roleFilter);
      if (statusFilter === "ACTIVE") params.set("isActive", "true");
      if (statusFilter === "DISABLED") params.set("isActive", "false");

      const res = await fetch(`/api/admin/users?${params}`);
      if (!res.ok) throw new Error("Failed to load users");
      const json = await res.json();
      setUsers(json.data ?? []);
      setTotal(json.total ?? 0);
      setTotalPages(json.totalPages ?? 1);
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to load users", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [page, debouncedSearch, roleFilter, statusFilter, toast]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);
  useEffect(() => { setPage(1); }, [debouncedSearch, roleFilter, statusFilter]);

  // ── Open create/edit modal ─────────────────────────────────────────────────
  function openCreateModal() {
    setFormState({ name: "", email: "", role: Role.ASSESSOR, password: "", isActive: true });
    setFormErrors({});
    setUserModal({ open: true, user: null });
  }

  function openEditModal(user: UserRecord) {
    setFormState({ name: user.name, email: user.email, role: user.role, password: "", isActive: user.isActive });
    setFormErrors({});
    setUserModal({ open: true, user });
  }

  // ── Save user (create / update) ────────────────────────────────────────────
  async function handleSaveUser() {
    const errors: Partial<UserFormState> = {};
    if (!formState.name.trim()) errors.name = "Name is required";
    if (!formState.email.trim() || !formState.email.includes("@")) errors.email = "Valid email is required";
    if (!userModal.user && !formState.password) errors.password = "Password is required for new users";
    setFormErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setSavingUser(true);
    try {
      const isCreate = !userModal.user;
      const url = isCreate ? "/api/admin/users" : `/api/admin/users/${userModal.user!.id}`;
      const method = isCreate ? "POST" : "PUT";
      const body: Record<string, unknown> = {
        name: formState.name.trim(),
        email: formState.email.trim(),
        role: formState.role,
        isActive: formState.isActive,
      };
      if (isCreate) body.password = formState.password;

      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Save failed");

      toast({ title: isCreate ? "User created" : "User updated", variant: "success" });
      setUserModal({ open: false, user: null });
      fetchUsers();
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Save failed", variant: "destructive" });
    } finally {
      setSavingUser(false);
    }
  }

  // ── Reset password ─────────────────────────────────────────────────────────
  async function handleResetPassword() {
    if (!resetModal.user) return;
    setResettingPassword(true);
    try {
      const res = await fetch(`/api/admin/users/${resetModal.user.id}/reset-password`, { method: "POST" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Reset failed");
      setResetModal((prev) => ({ ...prev, tempPassword: json.data?.tempPassword ?? json.data?.temporaryPassword ?? "Check server logs" }));
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Reset failed", variant: "destructive" });
      setResetModal({ open: false, user: null, tempPassword: null });
    } finally {
      setResettingPassword(false);
    }
  }

  // ── Toggle active status ───────────────────────────────────────────────────
  async function handleToggleStatus() {
    if (!toggleModal.user) return;
    setTogglingStatus(true);
    try {
      const res = await fetch(`/api/admin/users/${toggleModal.user.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !toggleModal.user.isActive }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Update failed");
      toast({
        title: toggleModal.user.isActive ? "User disabled" : "User enabled",
        description: `${toggleModal.user.name} has been ${toggleModal.user.isActive ? "disabled" : "enabled"}.`,
        variant: "success",
      });
      setToggleModal({ open: false, user: null });
      fetchUsers();
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Update failed", variant: "destructive" });
    } finally {
      setTogglingStatus(false);
    }
  }

  // ── Load customer access ───────────────────────────────────────────────────
  async function openAccessModal(user: UserRecord) {
    setAccessModal({ open: true, user, accesses: [] });
    setLoadingAccess(true);
    try {
      const res = await fetch(`/api/admin/users/${user.id}/customer-access`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Failed to load access");
      setAccessModal((prev) => ({ ...prev, accesses: json.data ?? [] }));
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to load access", variant: "destructive" });
    } finally {
      setLoadingAccess(false);
    }
  }

  async function handleRemoveAccess(accessId: string, profileName: string) {
    if (!accessModal.user) return;
    try {
      const res = await fetch(`/api/admin/users/${accessModal.user.id}/customer-access?accessId=${accessId}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to remove access");
      setAccessModal((prev) => ({ ...prev, accesses: prev.accesses.filter((a) => a.id !== accessId) }));
      toast({ title: "Access removed", description: `Access to "${profileName}" removed.` });
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to remove", variant: "destructive" });
    }
  }

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-6">
        <Shield className="h-12 w-12 text-muted-foreground" />
        <h1 className="text-xl font-semibold">Administrator Access Required</h1>
        <Button asChild variant="outline">
          <Link href="/dashboard">Return to Dashboard</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">User Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage user accounts, roles, and profile access</p>
        </div>
        <Button onClick={openCreateModal}>
          <Plus className="h-4 w-4" />
          Create User
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or email..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger><SelectValue placeholder="All Roles" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Roles</SelectItem>
                <SelectItem value="ADMIN">Admin</SelectItem>
                <SelectItem value="ASSESSOR">Assessor</SelectItem>
                <SelectItem value="CUSTOMER">Customer</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Statuses</SelectItem>
                <SelectItem value="ACTIVE">Active</SelectItem>
                <SelectItem value="DISABLED">Disabled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="py-4 px-6 border-b">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            {loading ? "Loading..." : `${total} user${total !== 1 ? "s" : ""}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-0">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-14 border-b bg-muted/20 animate-pulse" />
              ))}
            </div>
          ) : users.length === 0 ? (
            <div className="py-16 text-center text-sm text-muted-foreground">No users found.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{user.email}</TableCell>
                    <TableCell><RoleBadge role={user.role} /></TableCell>
                    <TableCell>
                      <Badge variant={user.isActive ? "success" : "secondary"}>
                        {user.isActive ? "Active" : "Disabled"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {user.lastLoginAt ? formatDateTime(user.lastLoginAt) : "Never"}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {formatDate(user.createdAt)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openEditModal(user)} title="Edit user">
                          <Edit2 className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setResetModal({ open: true, user, tempPassword: null })}
                          title="Reset password"
                        >
                          <Lock className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className={user.isActive ? "text-destructive hover:text-destructive" : "text-emerald-600 hover:text-emerald-600"}
                          onClick={() => setToggleModal({ open: true, user })}
                          title={user.isActive ? "Disable user" : "Enable user"}
                        >
                          {user.isActive ? <UserX className="h-3.5 w-3.5" /> : <UserCheck className="h-3.5 w-3.5" />}
                        </Button>
                        {user.role === Role.CUSTOMER && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openAccessModal(user)}
                            title="Manage profile access"
                          >
                            <Link2 className="h-3.5 w-3.5" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>
              <ChevronLeft className="h-4 w-4" /> Previous
            </Button>
            <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* ── Create/Edit user dialog ────────────────────────────────────────── */}
      <Dialog open={userModal.open} onOpenChange={(open) => !open && setUserModal({ open: false, user: null })}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{userModal.user ? "Edit User" : "Create User"}</DialogTitle>
            <DialogDescription>
              {userModal.user ? `Update details for ${userModal.user.name}` : "Create a new user account"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="u-name">Name <span className="text-destructive">*</span></Label>
              <Input
                id="u-name"
                value={formState.name}
                onChange={(e) => setFormState((s) => ({ ...s, name: e.target.value }))}
                disabled={savingUser}
              />
              {formErrors.name && <p className="text-xs text-destructive">{formErrors.name}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="u-email">Email <span className="text-destructive">*</span></Label>
              <Input
                id="u-email"
                type="email"
                value={formState.email}
                onChange={(e) => setFormState((s) => ({ ...s, email: e.target.value }))}
                disabled={savingUser || !!userModal.user}
              />
              {formErrors.email && <p className="text-xs text-destructive">{formErrors.email}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="u-role">Role <span className="text-destructive">*</span></Label>
              <Select value={formState.role} onValueChange={(v) => setFormState((s) => ({ ...s, role: v }))} disabled={savingUser}>
                <SelectTrigger id="u-role"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={Role.ADMIN}>Admin</SelectItem>
                  <SelectItem value={Role.ASSESSOR}>Assessor</SelectItem>
                  <SelectItem value={Role.CUSTOMER}>Customer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {!userModal.user && (
              <div className="space-y-1.5">
                <Label htmlFor="u-password">Password <span className="text-destructive">*</span></Label>
                <Input
                  id="u-password"
                  type="password"
                  value={formState.password}
                  onChange={(e) => setFormState((s) => ({ ...s, password: e.target.value }))}
                  disabled={savingUser}
                  autoComplete="new-password"
                />
                {formErrors.password && <p className="text-xs text-destructive">{formErrors.password}</p>}
              </div>
            )}
            <div className="flex items-center gap-3">
              <input
                id="u-active"
                type="checkbox"
                checked={formState.isActive}
                onChange={(e) => setFormState((s) => ({ ...s, isActive: e.target.checked }))}
                disabled={savingUser}
                className="h-4 w-4 rounded border-input"
              />
              <Label htmlFor="u-active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUserModal({ open: false, user: null })} disabled={savingUser}>
              Cancel
            </Button>
            <Button onClick={handleSaveUser} disabled={savingUser}>
              {savingUser ? "Saving..." : userModal.user ? "Save Changes" : "Create User"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Reset password dialog ─────────────────────────────────────────── */}
      <AlertDialog open={resetModal.open && !resetModal.tempPassword} onOpenChange={(open) => !open && setResetModal({ open: false, user: null, tempPassword: null })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset Password</AlertDialogTitle>
            <AlertDialogDescription>
              Reset the password for <strong>{resetModal.user?.name}</strong>? A temporary password will be generated.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={resettingPassword}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleResetPassword} disabled={resettingPassword}>
              {resettingPassword ? "Resetting..." : "Reset Password"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Show temp password dialog */}
      <Dialog open={!!resetModal.tempPassword} onOpenChange={() => setResetModal({ open: false, user: null, tempPassword: null })}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Temporary Password</DialogTitle>
            <DialogDescription>
              Provide this temporary password to the user. It should be changed immediately.
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-lg border bg-muted px-4 py-3 font-mono text-sm text-center select-all">
            {resetModal.tempPassword}
          </div>
          <DialogFooter>
            <Button onClick={() => setResetModal({ open: false, user: null, tempPassword: null })}>
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Disable/Enable dialog ─────────────────────────────────────────── */}
      <AlertDialog open={toggleModal.open} onOpenChange={(open) => !open && setToggleModal({ open: false, user: null })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {toggleModal.user?.isActive ? "Disable User?" : "Enable User?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {toggleModal.user?.isActive
                ? `This will prevent ${toggleModal.user?.name} from logging in.`
                : `This will allow ${toggleModal.user?.name} to log in again.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={togglingStatus}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleToggleStatus}
              disabled={togglingStatus}
              className={toggleModal.user?.isActive ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : ""}
            >
              {togglingStatus ? "Updating..." : toggleModal.user?.isActive ? "Disable" : "Enable"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── Customer access modal ─────────────────────────────────────────── */}
      <Dialog open={accessModal.open} onOpenChange={(open) => !open && setAccessModal({ open: false, user: null, accesses: [] })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Profile Access — {accessModal.user?.name}</DialogTitle>
            <DialogDescription>Profiles this customer user can access</DialogDescription>
          </DialogHeader>
          {loadingAccess ? (
            <div className="space-y-2 py-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-10 bg-muted animate-pulse rounded" />
              ))}
            </div>
          ) : accessModal.accesses.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">No profiles linked to this user.</p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {accessModal.accesses.map((a) => (
                <div key={a.id} className="flex items-center justify-between rounded-lg border px-3 py-2">
                  <div>
                    <p className="text-sm font-medium">{a.profile.name}</p>
                    <p className="text-xs text-muted-foreground">{a.profile.identifier}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleRemoveAccess(a.id, a.profile.name)}
                  >
                    Remove
                  </Button>
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setAccessModal({ open: false, user: null, accesses: [] })}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
