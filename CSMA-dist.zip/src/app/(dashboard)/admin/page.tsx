"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Users, ClipboardList, FileSpreadsheet, Settings, Shield, Activity, Brain } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { formatDateTime } from "@/lib/utils";
import { Role } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

interface SummaryStats {
  totalUsers: number;
  activeUsers: number;
  totalAssessments: number;
  totalTemplates: number;
}

interface AuditLogEntry {
  id: string;
  action: string;
  entityType: string | null;
  entityId: string | null;
  createdAt: string;
  user: { id: string; name: string; email: string; role: string } | null;
}

interface PaginatedAuditLogs {
  data: AuditLogEntry[];
  total: number;
}

// ─── Action badge colors ──────────────────────────────────────────────────────

function actionBadgeClass(action: string): string {
  if (action === "LOGIN") return "bg-slate-100 text-slate-700 border-slate-200";
  if (action === "LOGOUT") return "bg-gray-100 text-gray-700 border-gray-200";
  if (action.includes("FAILED") || action.includes("DENIED")) return "bg-red-100 text-red-800 border-red-200";
  if (action.startsWith("USER_CREATED") || action.startsWith("PROFILE_CREATED") || action.startsWith("TEMPLATE_UPLOADED") || action.startsWith("ASSESSMENT_CREATED")) {
    return "bg-green-100 text-green-800 border-green-200";
  }
  if (action.includes("DELETE") || action.includes("ARCHIVED") || action.includes("DISABLED")) {
    return "bg-destructive/10 text-destructive border-destructive/20";
  }
  return "bg-muted text-muted-foreground border-muted";
}

function ActionBadge({ action }: { action: string }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${actionBadgeClass(action)}`}>
      {action.replace(/_/g, " ")}
    </span>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function AdminPage() {
  const { data: session } = useSession();
  const { toast } = useToast();

  const role = (session?.user as { role?: string })?.role;
  const isAdmin = role === Role.ADMIN;

  const [stats, setStats] = useState<SummaryStats | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin) return;

    async function fetchData() {
      setLoading(true);
      try {
        const [usersRes, auditRes] = await Promise.all([
          fetch("/api/admin/users?pageSize=1"),
          fetch("/api/admin/audit-logs?pageSize=10"),
        ]);

        if (!usersRes.ok || !auditRes.ok) throw new Error("Failed to load admin data");

        const usersJson = await usersRes.json();
        const auditJson: PaginatedAuditLogs = await auditRes.json();

        // Fetch active users count separately
        const activeUsersRes = await fetch("/api/admin/users?isActive=true&pageSize=1");
        const activeUsersJson = await activeUsersRes.json();

        // Fetch assessment count
        const assessmentsRes = await fetch("/api/assessments?pageSize=1");
        const assessmentsJson = await assessmentsRes.json();

        // Fetch templates count
        const templatesRes = await fetch("/api/templates?pageSize=1");
        const templatesJson = await templatesRes.json();

        setStats({
          totalUsers: usersJson.total ?? 0,
          activeUsers: activeUsersJson.total ?? 0,
          totalAssessments: assessmentsJson.total ?? 0,
          totalTemplates: templatesJson.total ?? 0,
        });

        setAuditLogs(auditJson.data ?? []);
      } catch (err) {
        toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to load admin data", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [isAdmin, toast]);

  // ── Unauthorized state ─────────────────────────────────────────────────────
  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-6">
        <Shield className="h-12 w-12 text-muted-foreground" />
        <h1 className="text-xl font-semibold">Administrator Access Required</h1>
        <p className="text-sm text-muted-foreground text-center max-w-sm">
          This area is restricted to administrators. If you believe this is an error, please contact your system administrator.
        </p>
        <Button asChild variant="outline">
          <Link href="/dashboard">Return to Dashboard</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Administration</h1>
        <p className="text-sm text-muted-foreground mt-1">System overview and management tools</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Users</p>
                <p className="text-3xl font-bold mt-1">
                  {loading ? <span className="block h-8 w-16 bg-muted animate-pulse rounded" /> : stats?.totalUsers ?? "—"}
                </p>
              </div>
              <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-slate-50">
                <Users className="h-5 w-5 text-slate-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Active Users</p>
                <p className="text-3xl font-bold mt-1">
                  {loading ? <span className="block h-8 w-16 bg-muted animate-pulse rounded" /> : stats?.activeUsers ?? "—"}
                </p>
              </div>
              <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-green-50">
                <Users className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Assessments</p>
                <p className="text-3xl font-bold mt-1">
                  {loading ? <span className="block h-8 w-16 bg-muted animate-pulse rounded" /> : stats?.totalAssessments ?? "—"}
                </p>
              </div>
              <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-purple-50">
                <ClipboardList className="h-5 w-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Templates</p>
                <p className="text-3xl font-bold mt-1">
                  {loading ? <span className="block h-8 w-16 bg-muted animate-pulse rounded" /> : stats?.totalTemplates ?? "—"}
                </p>
              </div>
              <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-orange-50">
                <FileSpreadsheet className="h-5 w-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:border-primary/40 transition-colors">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-slate-50">
                <Users className="h-4 w-4 text-slate-500" />
              </div>
              <h3 className="font-semibold">User Management</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Create and manage user accounts, roles, and profile access.
            </p>
            <Button asChild size="sm" variant="outline" className="w-full">
              <Link href="/admin/users">Manage Users</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:border-primary/40 transition-colors">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-amber-50">
                <Activity className="h-4 w-4 text-amber-600" />
              </div>
              <h3 className="font-semibold">Audit Logs</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Review system activity, login events, and data changes.
            </p>
            <Button asChild size="sm" variant="outline" className="w-full">
              <Link href="/admin/audit-logs">View Audit Logs</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:border-primary/40 transition-colors">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-gray-100">
                <Settings className="h-4 w-4 text-gray-600" />
              </div>
              <h3 className="font-semibold">Settings</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Configure application settings such as session timeout and file limits.
            </p>
            <Button asChild size="sm" variant="outline" className="w-full">
              <Link href="/admin/settings">Edit Settings</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:border-primary/40 transition-colors">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-primary/10">
                <Brain className="h-4 w-4 text-primary" />
              </div>
              <h3 className="font-semibold">AI Analysis</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Configure Azure OpenAI integration for automated assessment analysis.
            </p>
            <Button asChild size="sm" variant="outline" className="w-full">
              <Link href="/admin/ai-settings">Configure AI</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent audit log */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Recent Audit Activity</CardTitle>
          <Button asChild variant="ghost" size="sm">
            <Link href="/admin/audit-logs">View All</Link>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-0">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-12 border-b bg-muted/20 animate-pulse" />
              ))}
            </div>
          ) : auditLogs.length === 0 ? (
            <div className="py-10 text-center text-sm text-muted-foreground">
              No audit log entries yet.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Action</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Entity</TableHead>
                  <TableHead>Timestamp</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {auditLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <ActionBadge action={log.action} />
                    </TableCell>
                    <TableCell className="text-sm">
                      {log.user ? (
                        <div>
                          <p className="font-medium">{log.user.name}</p>
                          <p className="text-xs text-muted-foreground">{log.user.email}</p>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">System</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {log.entityType ? (
                        <span>
                          {log.entityType}
                          {log.entityId && (
                            <span className="ml-1 text-xs opacity-60">
                              #{log.entityId.slice(-6)}
                            </span>
                          )}
                        </span>
                      ) : (
                        "—"
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {formatDateTime(log.createdAt)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
