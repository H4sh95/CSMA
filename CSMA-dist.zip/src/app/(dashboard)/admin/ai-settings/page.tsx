"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import {
  Save, Loader2, Shield, Eye, EyeOff,
  CheckCircle2, XCircle, Brain, TestTube2, ChevronDown, ChevronUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Role } from "@prisma/client";

// ─── Types ─────────────────────────────────────────────────────────────────────

interface AiSettingsData {
  id: string;
  isEnabled: boolean;
  endpoint: string | null;
  deployment: string | null;
  model: string | null;
  apiKeyConfigured: boolean;
  systemPromptTemplate: string | null;
  recommendationStyle: "concise" | "detailed" | "executive";
  maxTokens: number;
  temperature: number;
  includeAssessorComments: boolean;
  includeHistorical: boolean;
  updatedAt: string;
}

interface FormState {
  isEnabled: boolean;
  endpoint: string;
  deployment: string;
  model: string;
  apiKey: string;
  systemPromptTemplate: string;
  recommendationStyle: "concise" | "detailed" | "executive";
  maxTokens: string;
  temperature: string;
  includeAssessorComments: boolean;
  includeHistorical: boolean;
}

const DEFAULT_FORM: FormState = {
  isEnabled: false,
  endpoint: "",
  deployment: "",
  model: "",
  apiKey: "",
  systemPromptTemplate: "",
  recommendationStyle: "detailed",
  maxTokens: "2000",
  temperature: "0.3",
  includeAssessorComments: true,
  includeHistorical: false,
};

// ─── Component ─────────────────────────────────────────────────────────────────

export default function AiSettingsPage() {
  const { data: session } = useSession();
  const { toast } = useToast();

  const role = (session?.user as { role?: string })?.role;
  const isAdmin = role === Role.ADMIN;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [showApiKey, setShowApiKey] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [apiKeyConfigured, setApiKeyConfigured] = useState(false);
  const [form, setForm] = useState<FormState>(DEFAULT_FORM);
  const [originalForm, setOriginalForm] = useState<FormState>(DEFAULT_FORM);

  useEffect(() => {
    if (!isAdmin) return;
    setLoading(true);
    fetch("/api/admin/ai-settings")
      .then((r) => r.json())
      .then((json) => {
        const s: AiSettingsData | null = json.data;
        if (s) {
          const loaded: FormState = {
            isEnabled: s.isEnabled,
            endpoint: s.endpoint ?? "",
            deployment: s.deployment ?? "",
            model: s.model ?? "",
            apiKey: "",   // never pre-filled for security
            systemPromptTemplate: s.systemPromptTemplate ?? "",
            recommendationStyle: s.recommendationStyle ?? "detailed",
            maxTokens: String(s.maxTokens ?? 2000),
            temperature: String(s.temperature ?? 0.3),
            includeAssessorComments: s.includeAssessorComments ?? true,
            includeHistorical: s.includeHistorical ?? false,
          };
          setForm(loaded);
          setOriginalForm(loaded);
          setApiKeyConfigured(s.apiKeyConfigured);
        }
      })
      .catch((err) => {
        toast({ title: "Error loading settings", description: err.message, variant: "destructive" });
      })
      .finally(() => setLoading(false));
  }, [isAdmin, toast]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setTestResult(null);
    try {
      const payload: Record<string, unknown> = {
        isEnabled: form.isEnabled,
        endpoint: form.endpoint.trim() || null,
        deployment: form.deployment.trim() || null,
        model: form.model.trim() || null,
        systemPromptTemplate: form.systemPromptTemplate.trim() || null,
        recommendationStyle: form.recommendationStyle,
        maxTokens: parseInt(form.maxTokens, 10) || 2000,
        temperature: parseFloat(form.temperature) || 0.3,
        includeAssessorComments: form.includeAssessorComments,
        includeHistorical: form.includeHistorical,
      };
      // Only include apiKey in payload if user provided one
      if (form.apiKey.trim()) {
        payload.apiKey = form.apiKey.trim();
      }

      const res = await fetch("/api/admin/ai-settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Save failed");

      const updated: AiSettingsData | null = json.data;
      if (updated) {
        const savedForm = { ...form, apiKey: "" };
        setForm(savedForm);
        setOriginalForm(savedForm);
        setApiKeyConfigured(updated.apiKeyConfigured);
      }
      toast({ title: "Settings saved", description: "AI analysis settings have been updated.", variant: "success" });
    } catch (err) {
      toast({ title: "Save failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function handleTest() {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch("/api/admin/ai-settings/test", { method: "POST" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Test failed");
      setTestResult(json.data);
    } catch (err) {
      setTestResult({ ok: false, message: err instanceof Error ? err.message : "Test failed" });
    } finally {
      setTesting(false);
    }
  }

  const isDirty =
    form.isEnabled !== originalForm.isEnabled ||
    form.endpoint !== originalForm.endpoint ||
    form.deployment !== originalForm.deployment ||
    form.model !== originalForm.model ||
    form.apiKey !== "" ||
    form.systemPromptTemplate !== originalForm.systemPromptTemplate ||
    form.recommendationStyle !== originalForm.recommendationStyle ||
    form.maxTokens !== originalForm.maxTokens ||
    form.temperature !== originalForm.temperature ||
    form.includeAssessorComments !== originalForm.includeAssessorComments ||
    form.includeHistorical !== originalForm.includeHistorical;

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-6">
        <Shield className="h-12 w-12 text-muted-foreground" />
        <h1 className="text-xl font-semibold">Administrator Access Required</h1>
        <Button asChild variant="outline"><Link href="/dashboard">Return to Dashboard</Link></Button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[40vh]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-primary/10">
          <Brain className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">AI Analysis Settings</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Configure Azure OpenAI integration for automated assessment analysis
          </p>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-5">

        {/* Enable / Disable */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-semibold">Enable AI Analysis</Label>
                <p className="text-sm text-muted-foreground">
                  When enabled, AI-generated analysis will be available for completed assessments.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant={form.isEnabled ? "success" : "secondary"}>
                  {form.isEnabled ? "Enabled" : "Disabled"}
                </Badge>
                <Switch
                  checked={form.isEnabled}
                  onCheckedChange={(v) => setForm((s) => ({ ...s, isEnabled: v }))}
                  disabled={saving}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Azure OpenAI Configuration */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Azure OpenAI Configuration</CardTitle>
            <CardDescription>
              Connection settings for your Azure OpenAI resource. These are stored encrypted.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Endpoint */}
            <div className="space-y-1.5">
              <Label htmlFor="endpoint">API Endpoint</Label>
              <Input
                id="endpoint"
                type="url"
                placeholder="https://your-resource.openai.azure.com/"
                value={form.endpoint}
                onChange={(e) => setForm((s) => ({ ...s, endpoint: e.target.value }))}
                disabled={saving}
              />
              <p className="text-xs text-muted-foreground">Your Azure OpenAI resource endpoint URL.</p>
            </div>

            {/* Deployment */}
            <div className="space-y-1.5">
              <Label htmlFor="deployment">Deployment Name</Label>
              <Input
                id="deployment"
                placeholder="gpt-4o"
                value={form.deployment}
                onChange={(e) => setForm((s) => ({ ...s, deployment: e.target.value }))}
                disabled={saving}
              />
              <p className="text-xs text-muted-foreground">The name of your Azure OpenAI deployment.</p>
            </div>

            {/* Model */}
            <div className="space-y-1.5">
              <Label htmlFor="model">Model Name <span className="text-muted-foreground font-normal">(optional)</span></Label>
              <Input
                id="model"
                placeholder="gpt-4o"
                value={form.model}
                onChange={(e) => setForm((s) => ({ ...s, model: e.target.value }))}
                disabled={saving}
              />
              <p className="text-xs text-muted-foreground">Informational — used for audit logs and display only.</p>
            </div>

            {/* API Key */}
            <div className="space-y-1.5">
              <Label htmlFor="apiKey">
                API Key
                {apiKeyConfigured && (
                  <Badge variant="outline" className="ml-2 text-xs font-normal text-emerald-700 border-emerald-200 bg-emerald-50">
                    ● Configured
                  </Badge>
                )}
              </Label>
              <div className="relative">
                <Input
                  id="apiKey"
                  type={showApiKey ? "text" : "password"}
                  placeholder={apiKeyConfigured ? "Leave blank to keep existing key" : "Enter your Azure OpenAI API key"}
                  value={form.apiKey}
                  onChange={(e) => setForm((s) => ({ ...s, apiKey: e.target.value }))}
                  disabled={saving}
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowApiKey((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  tabIndex={-1}
                >
                  {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <p className="text-xs text-muted-foreground">
                Stored encrypted (AES-256-GCM). Never exposed after saving.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Analysis Options */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Analysis Options</CardTitle>
            <CardDescription>Control what context is included in the AI analysis.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Include Assessor Comments</p>
                <p className="text-xs text-muted-foreground">Include per-control comments in the AI context.</p>
              </div>
              <Switch
                checked={form.includeAssessorComments}
                onCheckedChange={(v) => setForm((s) => ({ ...s, includeAssessorComments: v }))}
                disabled={saving}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Include Historical Comparisons</p>
                <p className="text-xs text-muted-foreground">Include previous assessment scores for trend context.</p>
              </div>
              <Switch
                checked={form.includeHistorical}
                onCheckedChange={(v) => setForm((s) => ({ ...s, includeHistorical: v }))}
                disabled={saving}
              />
            </div>
            <Separator />
            <div className="space-y-1.5">
              <Label>Recommendation Style</Label>
              <Select
                value={form.recommendationStyle}
                onValueChange={(v) => setForm((s) => ({ ...s, recommendationStyle: v as FormState["recommendationStyle"] }))}
                disabled={saving}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="executive">Executive — business-focused, minimal jargon</SelectItem>
                  <SelectItem value="detailed">Detailed — thorough with technical specifics</SelectItem>
                  <SelectItem value="concise">Concise — short, direct statements</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Advanced Settings (collapsible) */}
        <Card>
          <button
            type="button"
            className="w-full flex items-center justify-between px-5 py-4 text-left"
            onClick={() => setShowAdvanced((v) => !v)}
          >
            <div>
              <p className="text-sm font-semibold">Advanced Model Settings</p>
              <p className="text-xs text-muted-foreground">Max tokens, temperature, and custom system prompt.</p>
            </div>
            {showAdvanced
              ? <ChevronUp className="h-4 w-4 text-muted-foreground" />
              : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
          </button>
          {showAdvanced && (
            <CardContent className="space-y-4 pt-0">
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="maxTokens">Max Tokens</Label>
                  <Input
                    id="maxTokens"
                    type="number"
                    min={100}
                    max={8000}
                    step={100}
                    value={form.maxTokens}
                    onChange={(e) => setForm((s) => ({ ...s, maxTokens: e.target.value }))}
                    disabled={saving}
                  />
                  <p className="text-xs text-muted-foreground">100–8000. Default: 2000.</p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="temperature">Temperature</Label>
                  <Input
                    id="temperature"
                    type="number"
                    min={0}
                    max={1}
                    step={0.05}
                    value={form.temperature}
                    onChange={(e) => setForm((s) => ({ ...s, temperature: e.target.value }))}
                    disabled={saving}
                  />
                  <p className="text-xs text-muted-foreground">0–1. Default: 0.3.</p>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="systemPrompt">Custom System Prompt <span className="text-muted-foreground font-normal">(optional)</span></Label>
                <textarea
                  id="systemPrompt"
                  rows={6}
                  className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 resize-y font-mono"
                  placeholder="Leave blank to use the built-in cybersecurity advisor prompt..."
                  value={form.systemPromptTemplate}
                  onChange={(e) => setForm((s) => ({ ...s, systemPromptTemplate: e.target.value }))}
                  disabled={saving}
                />
                <p className="text-xs text-muted-foreground">
                  Overrides the default system prompt. Leave blank to use the built-in prompt.
                </p>
              </div>
            </CardContent>
          )}
        </Card>

        {/* Test Connection */}
        <Card>
          <CardContent className="p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold">Test Connection</p>
                <p className="text-xs text-muted-foreground">
                  Verify that the saved Azure OpenAI settings are working correctly.
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleTest}
                disabled={testing || saving || !apiKeyConfigured}
              >
                {testing ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Testing...</>
                ) : (
                  <><TestTube2 className="h-4 w-4" /> Test Connection</>
                )}
              </Button>
            </div>
            {testResult && (
              <div className={`flex items-start gap-2 rounded-md p-3 text-sm ${
                testResult.ok
                  ? "bg-emerald-50 border border-emerald-200 text-emerald-800"
                  : "bg-red-50 border border-red-200 text-red-800"
              }`}>
                {testResult.ok
                  ? <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
                  : <XCircle className="h-4 w-4 shrink-0 mt-0.5" />}
                <span>{testResult.message}</span>
              </div>
            )}
            {!apiKeyConfigured && (
              <p className="text-xs text-amber-600">Save an API key first to enable connection testing.</p>
            )}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-amber-600 font-medium">
            {isDirty ? "You have unsaved changes" : ""}
          </p>
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => { setForm({ ...originalForm, apiKey: "" }); setTestResult(null); }}
              disabled={!isDirty || saving}
            >
              Discard Changes
            </Button>
            <Button type="submit" disabled={saving || !isDirty}>
              {saving
                ? <><Loader2 className="h-4 w-4 animate-spin" /> Saving...</>
                : <><Save className="h-4 w-4" /> Save Settings</>}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
