"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Save, Loader2, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Role } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

interface SettingsFormState {
  appName: string;
  maxFileSizeMb: string;
  sessionTimeoutHours: string;
}

const DEFAULT_SETTINGS: SettingsFormState = {
  appName: "CSMA",
  maxFileSizeMb: "10",
  sessionTimeoutHours: "8",
};

// ─── Component ────────────────────────────────────────────────────────────────

export default function SettingsPage() {
  const { data: session } = useSession();
  const { toast } = useToast();

  const role = (session?.user as { role?: string })?.role;
  const isAdmin = role === Role.ADMIN;

  const [form, setForm] = useState<SettingsFormState>(DEFAULT_SETTINGS);
  const [originalForm, setOriginalForm] = useState<SettingsFormState>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Partial<SettingsFormState>>({});

  useEffect(() => {
    if (!isAdmin) return;
    setLoading(true);
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((json) => {
        const s = json.data?.settings ?? {};
        const loaded: SettingsFormState = {
          appName: s.appName ?? DEFAULT_SETTINGS.appName,
          maxFileSizeMb: s.maxFileSizeMb ?? DEFAULT_SETTINGS.maxFileSizeMb,
          sessionTimeoutHours: s.sessionTimeoutHours ?? DEFAULT_SETTINGS.sessionTimeoutHours,
        };
        setForm(loaded);
        setOriginalForm(loaded);
      })
      .catch((err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      })
      .finally(() => setLoading(false));
  }, [isAdmin, toast]);

  function validate(): boolean {
    const errs: Partial<SettingsFormState> = {};
    if (!form.appName.trim()) errs.appName = "App name is required";

    const fileSize = parseFloat(form.maxFileSizeMb);
    if (isNaN(fileSize) || fileSize <= 0 || fileSize > 500) {
      errs.maxFileSizeMb = "Must be a number between 1 and 500";
    }

    const timeout = parseInt(form.sessionTimeoutHours);
    if (isNaN(timeout) || timeout <= 0 || timeout > 720) {
      errs.sessionTimeoutHours = "Must be a number between 1 and 720";
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSave(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!validate()) return;

    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          settings: [
            { key: "appName", value: form.appName.trim() },
            { key: "maxFileSizeMb", value: form.maxFileSizeMb },
            { key: "sessionTimeoutHours", value: form.sessionTimeoutHours },
          ],
        }),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Save failed");

      setOriginalForm({ ...form });
      toast({ title: "Settings saved", description: "System settings have been updated successfully.", variant: "success" });
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Save failed", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  function handleReset() {
    setForm({ ...originalForm });
    setErrors({});
  }

  const isDirty =
    form.appName !== originalForm.appName ||
    form.maxFileSizeMb !== originalForm.maxFileSizeMb ||
    form.sessionTimeoutHours !== originalForm.sessionTimeoutHours;

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-6">
        <Shield className="h-12 w-12 text-muted-foreground" />
        <h1 className="text-xl font-semibold">Administrator Access Required</h1>
        <Button asChild variant="outline">
          <Link href="/dashboard">Return to Dashboard</Link>
        </Button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[40vh]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">System Settings</h1>
        <p className="text-sm text-muted-foreground mt-1">Configure global application settings</p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* General settings */}
        <Card>
          <CardHeader>
            <CardTitle>General</CardTitle>
            <CardDescription>Basic application configuration</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* App Name */}
            <div className="space-y-1.5">
              <Label htmlFor="appName">
                Application Name
              </Label>
              <Input
                id="appName"
                value={form.appName}
                onChange={(e) => {
                  setForm((s) => ({ ...s, appName: e.target.value }));
                  if (errors.appName) setErrors((s) => ({ ...s, appName: undefined }));
                }}
                disabled={saving}
                placeholder="CSMA"
              />
              <p className="text-xs text-muted-foreground">
                Displayed in the browser title and platform header.
              </p>
              {errors.appName && <p className="text-xs text-destructive">{errors.appName}</p>}
            </div>
          </CardContent>
        </Card>

        {/* Security settings */}
        <Card>
          <CardHeader>
            <CardTitle>Security</CardTitle>
            <CardDescription>Session and file upload limits</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Max File Size */}
            <div className="space-y-1.5">
              <Label htmlFor="maxFileSizeMb">
                Max File Size (MB)
              </Label>
              <div className="flex items-center gap-2">
                <Input
                  id="maxFileSizeMb"
                  type="number"
                  min={1}
                  max={500}
                  step={1}
                  value={form.maxFileSizeMb}
                  onChange={(e) => {
                    setForm((s) => ({ ...s, maxFileSizeMb: e.target.value }));
                    if (errors.maxFileSizeMb) setErrors((s) => ({ ...s, maxFileSizeMb: undefined }));
                  }}
                  disabled={saving}
                  className="w-32"
                />
                <span className="text-sm text-muted-foreground">MB</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Maximum allowed size for XLSX template uploads. Range: 1–500 MB.
              </p>
              {errors.maxFileSizeMb && <p className="text-xs text-destructive">{errors.maxFileSizeMb}</p>}
            </div>

            {/* Session Timeout */}
            <div className="space-y-1.5">
              <Label htmlFor="sessionTimeoutHours">
                Session Timeout (Hours)
              </Label>
              <div className="flex items-center gap-2">
                <Input
                  id="sessionTimeoutHours"
                  type="number"
                  min={1}
                  max={720}
                  step={1}
                  value={form.sessionTimeoutHours}
                  onChange={(e) => {
                    setForm((s) => ({ ...s, sessionTimeoutHours: e.target.value }));
                    if (errors.sessionTimeoutHours) setErrors((s) => ({ ...s, sessionTimeoutHours: undefined }));
                  }}
                  disabled={saving}
                  className="w-32"
                />
                <span className="text-sm text-muted-foreground">hours</span>
              </div>
              <p className="text-xs text-muted-foreground">
                How long a user session remains valid before requiring re-login. Range: 1–720 hours.
              </p>
              {errors.sessionTimeoutHours && <p className="text-xs text-destructive">{errors.sessionTimeoutHours}</p>}
            </div>
          </CardContent>
        </Card>

        {/* Action buttons */}
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            {isDirty && <span className="text-amber-600 font-medium">You have unsaved changes</span>}
          </div>
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={handleReset}
              disabled={!isDirty || saving}
            >
              Discard Changes
            </Button>
            <Button type="submit" disabled={saving || !isDirty}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Save Settings
                </>
              )}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
