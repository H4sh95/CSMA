"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Search, Info, ChevronLeft, ChevronRight, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useDebounce } from "@/hooks/use-debounce";
import { formatDateTime } from "@/lib/utils";
import { Role, AuditAction } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

interface AuditLogEntry {
  id: string;
  action: string;
  entityType: string | null;
  entityId: string | null;
  details: unknown;
  ipAddress: string | null;
  createdAt: string;
  user: { id: string; name: string; email: string; role: string } | null;
}

interface PaginatedAuditLogs {
  data: AuditLogEntry[];
  total: number;
  page: number;
  totalPages: number;
}

const PAGE_SIZE = 50;

const AUDIT_ACTIONS = Object.values(AuditAction);

const ENTITY_TYPES = ["User", "CustomerProfile", "Template", "Assessment", "SystemSetting"];

// ─── Action badge ─────────────────────────────────────────────────────────────

function actionBadgeClass(action: string): string {
  if (action === "LOGIN") return "bg-slate-100 text-slate-700 border-slate-200";
  if (action === "LOGOUT") return "bg-gray-100 text-gray-700 border-gray-200";
  if (action.includes("FAILED") || action.includes("DENIED")) return "bg-red-100 text-red-800 border-red-200";
  if (action.startsWith("USER_CREATED") || action.startsWith("PROFILE_CREATED") || action.startsWith("TEMPLATE_UPLOADED") || action.startsWith("ASSESSMENT_CREATED")) {
    return "bg-green-100 text-green-800 border-green-200";
  }
  if (action.includes("DELETE") || action.includes("ARCHIVED") || action.includes("DISABLED")) {
    return "bg-red-50 text-red-700 border-red-200";
  }
  if (action.includes("UPDATED") || action.includes("ENABLED")) {
    return "bg-amber-100 text-amber-800 border-amber-200";
  }
  return "bg-muted text-muted-foreground border-muted";
}

function ActionBadge({ action }: { action: string }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium whitespace-nowrap ${actionBadgeClass(action)}`}>
      {action.replace(/_/g, " ")}
    </span>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function AuditLogsPage() {
  const { data: session } = useSession();
  const { toast } = useToast();

  const role = (session?.user as { role?: string })?.role;
  const isAdmin = role === Role.ADMIN;

  // ── Filters ─────────────────────────────────────────────────────────────────
  const [search, setSearch] = useState("");
  const [actionFilter, setActionFilter] = useState("ALL");
  const [entityTypeFilter, setEntityTypeFilter] = useState("ALL");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);

  const debouncedSearch = useDebounce(search, 350);

  // ── Data ─────────────────────────────────────────────────────────────────────
  const [result, setResult] = useState<PaginatedAuditLogs | null>(null);
  const [loading, setLoading] = useState(true);

  // ── Detail dialog ─────────────────────────────────────────────────────────────
  const [detailEntry, setDetailEntry] = useState<AuditLogEntry | null>(null);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(PAGE_SIZE) });
      if (debouncedSearch) params.set("search", debouncedSearch);
      if (actionFilter !== "ALL") params.set("action", actionFilter);
      if (entityTypeFilter !== "ALL") params.set("entityType", entityTypeFilter);
      if (dateFrom) params.set("dateFrom", dateFrom);
      if (dateTo) params.set("dateTo", dateTo);

      const res = await fetch(`/api/admin/audit-logs?${params}`);
      if (!res.ok) throw new Error("Failed to load audit logs");
      const json = await res.json();
      setResult(json);
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to load audit logs", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [page, debouncedSearch, actionFilter, entityTypeFilter, dateFrom, dateTo, toast]);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);
  useEffect(() => { setPage(1); }, [debouncedSearch, actionFilter, entityTypeFilter, dateFrom, dateTo]);

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-6">
        <Shield className="h-12 w-12 text-muted-foreground" />
        <h1 className="text-xl font-semibold">Administrator Access Required</h1>
        <Button asChild variant="outline">
          <Link href="/dashboard">Return to Dashboard</Link>
        </Button>
      </div>
    );
  }

  const logs = result?.data ?? [];
  const total = result?.total ?? 0;
  const totalPages = result?.totalPages ?? 1;

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Audit Logs</h1>
        <p className="text-sm text-muted-foreground mt-1">Full activity trail for the platform</p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* User search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by user name or email..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Action filter */}
            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger><SelectValue placeholder="All Actions" /></SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectItem value="ALL">All Actions</SelectItem>
                {AUDIT_ACTIONS.map((a) => (
                  <SelectItem key={a} value={a}>{a.replace(/_/g, " ")}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Entity type filter */}
            <Select value={entityTypeFilter} onValueChange={setEntityTypeFilter}>
              <SelectTrigger><SelectValue placeholder="All Entity Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Entity Types</SelectItem>
                {ENTITY_TYPES.map((e) => (
                  <SelectItem key={e} value={e}>{e}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Date range */}
            <div className="flex items-center gap-2">
              <Input
                type="datetime-local"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="text-xs"
                title="From"
              />
              <span className="text-muted-foreground shrink-0">–</span>
              <Input
                type="datetime-local"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="text-xs"
                title="To"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="py-4 px-6 border-b">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            {loading ? "Loading..." : `${total.toLocaleString()} log entr${total !== 1 ? "ies" : "y"}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-0">
              {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="h-12 border-b bg-muted/20 animate-pulse" />
              ))}
            </div>
          ) : logs.length === 0 ? (
            <div className="py-16 text-center text-sm text-muted-foreground">No audit log entries found.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-40">Timestamp</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Entity Type</TableHead>
                  <TableHead className="w-28">Entity ID</TableHead>
                  <TableHead className="w-36">IP Address</TableHead>
                  <TableHead className="text-center w-16">Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="text-xs text-muted-foreground font-mono whitespace-nowrap">
                      {formatDateTime(log.createdAt)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {log.user ? (
                        <div>
                          <p className="font-medium text-xs">{log.user.name}</p>
                          <p className="text-xs text-muted-foreground">{log.user.email}</p>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground italic">System</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <ActionBadge action={log.action} />
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {log.entityType ?? "—"}
                    </TableCell>
                    <TableCell className="text-xs font-mono text-muted-foreground">
                      {log.entityId ? `…${log.entityId.slice(-8)}` : "—"}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground font-mono">
                      {log.ipAddress ?? "—"}
                    </TableCell>
                    <TableCell className="text-center">
                      {log.details !== null && log.details !== undefined ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0"
                          onClick={() => setDetailEntry(log)}
                          title="View details"
                        >
                          <Info className="h-3.5 w-3.5" />
                        </Button>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>
              <ChevronLeft className="h-4 w-4" /> Previous
            </Button>
            <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Detail dialog */}
      <Dialog open={!!detailEntry} onOpenChange={(open) => !open && setDetailEntry(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Audit Log Details</DialogTitle>
            <DialogDescription>
              {detailEntry?.action.replace(/_/g, " ")} &middot; {detailEntry && formatDateTime(detailEntry.createdAt)}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            {detailEntry?.user && (
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <span className="text-muted-foreground">User</span>
                <span className="font-medium">{detailEntry.user.name} ({detailEntry.user.email})</span>
                <span className="text-muted-foreground">Role</span>
                <span>{detailEntry.user.role}</span>
              </div>
            )}
            {detailEntry?.ipAddress && (
              <div className="grid grid-cols-2 gap-x-4">
                <span className="text-muted-foreground">IP Address</span>
                <span className="font-mono">{detailEntry.ipAddress}</span>
              </div>
            )}
            {detailEntry?.entityType && (
              <div className="grid grid-cols-2 gap-x-4">
                <span className="text-muted-foreground">Entity</span>
                <span>{detailEntry.entityType} {detailEntry.entityId && `(${detailEntry.entityId})`}</span>
              </div>
            )}
            {detailEntry?.details !== null && detailEntry?.details !== undefined && (
              <div>
                <p className="text-muted-foreground mb-1">Details</p>
                <pre className="rounded-lg bg-muted p-3 text-xs overflow-auto max-h-64 font-mono">
                  {JSON.stringify(detailEntry.details, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
