"use client";

import { useCallback, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ChevronLeft,
  Upload,
  FileSpreadsheet,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Zap,
  Save,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { TemplateStatus } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

type UploadStep = "form" | "preview";

type TemplateItem = {
  id: string;
  domain: string;
  category: string;
  code: string;
  description: string;
  label: string;
  scoring: number;
  orderIndex: number;
};

type PreviewDomain = {
  name: string;
  itemCount: number;
  categories: Array<{
    name: string;
    itemCount: number;
    maxScore: number;
    items: TemplateItem[];
  }>;
};

type PreviewData = {
  template: {
    id: string;
    name: string;
    version: string;
    description: string | null;
    status: TemplateStatus;
    rowCount: number;
  };
  domains: PreviewDomain[];
  summary: {
    domainCount: number;
    categoryCount: number;
    itemCount: number;
    maxScore: number;
  };
};

type UploadedTemplate = {
  id: string;
  name: string;
  version: string;
};

// ─── File drop zone ───────────────────────────────────────────────────────────

interface FileDropZoneProps {
  file: File | null;
  onFileSelect: (file: File | null) => void;
  disabled?: boolean;
}

function FileDropZone({ file, onFileSelect, disabled }: FileDropZoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setDragOver(false);
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile) {
        if (!droppedFile.name.endsWith(".xlsx")) {
          return;
        }
        onFileSelect(droppedFile);
      }
    },
    [onFileSelect]
  );

  function formatBytes(bytes: number) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  return (
    <div>
      <div
        className={`
          relative border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
          ${dragOver ? "border-primary bg-primary/5" : "border-muted-foreground/30 hover:border-primary/50 hover:bg-muted/20"}
          ${disabled ? "opacity-50 cursor-not-allowed" : ""}
        `}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={disabled ? undefined : handleDrop}
        onClick={() => !disabled && inputRef.current?.click()}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          className="sr-only"
          disabled={disabled}
          onChange={(e) => {
            const f = e.target.files?.[0] ?? null;
            if (f) onFileSelect(f);
          }}
        />

        {file ? (
          <div className="flex flex-col items-center gap-2">
            <FileSpreadsheet className="h-10 w-10 text-green-600" />
            <div>
              <p className="font-medium text-foreground">{file.name}</p>
              <p className="text-sm text-muted-foreground">{formatBytes(file.size)}</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <Upload className="h-10 w-10 text-muted-foreground" />
            <div>
              <p className="font-medium text-foreground">Drop your .xlsx file here</p>
              <p className="text-sm text-muted-foreground">or click to browse</p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Only .xlsx files are accepted</p>
          </div>
        )}
      </div>

      {file && (
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="mt-2 text-muted-foreground"
          onClick={() => onFileSelect(null)}
          disabled={disabled}
        >
          <X className="h-4 w-4" />
          Remove file
        </Button>
      )}
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function UploadTemplatePage() {
  const router = useRouter();
  const { toast } = useToast();

  const [step, setStep] = useState<UploadStep>("form");
  const [name, setName] = useState("");
  const [version, setVersion] = useState("1.0");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [validationWarnings, setValidationWarnings] = useState<string[]>([]);
  const [uploadedTemplate, setUploadedTemplate] = useState<UploadedTemplate | null>(null);
  const [preview, setPreview] = useState<PreviewData | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [activating, setActivating] = useState(false);
  const [expandedDomains, setExpandedDomains] = useState<Record<string, boolean>>({});

  function toggleDomain(name: string) {
    setExpandedDomains((prev) => ({ ...prev, [name]: !prev[name] }));
  }

  async function handleUpload() {
    if (!file) {
      toast({ title: "Please select a file", variant: "destructive" });
      return;
    }
    if (!name.trim()) {
      toast({ title: "Template name is required", variant: "destructive" });
      return;
    }

    setUploading(true);
    setValidationErrors([]);
    setValidationWarnings([]);

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("name", name.trim());
      formData.append("version", version.trim() || "1.0");
      if (description.trim()) formData.append("description", description.trim());

      const res = await fetch("/api/templates", {
        method: "POST",
        body: formData,
      });

      const json = await res.json();

      if (!res.ok) {
        if (res.status === 422) {
          setValidationErrors(json.details ?? [json.error ?? "Validation failed"]);
          if (json.warnings?.length) setValidationWarnings(json.warnings);
        } else {
          throw new Error(json.error ?? "Upload failed");
        }
        return;
      }

      // Success — template saved as DRAFT
      const template: UploadedTemplate = {
        id: json.data.id,
        name: json.data.name,
        version: json.data.version,
      };

      if (json.warnings?.length) setValidationWarnings(json.warnings);

      setUploadedTemplate(template);

      // Fetch preview
      setPreviewLoading(true);
      const previewRes = await fetch(`/api/templates/${template.id}/preview`);
      if (previewRes.ok) {
        const previewJson = await previewRes.json();
        setPreview(previewJson.data);
        // Expand all domains by default
        const expanded: Record<string, boolean> = {};
        previewJson.data.domains.forEach((d: PreviewDomain) => {
          expanded[d.name] = true;
        });
        setExpandedDomains(expanded);
      }
      setPreviewLoading(false);

      setStep("preview");
    } catch (err) {
      toast({
        title: "Upload failed",
        description: err instanceof Error ? err.message : "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  }

  async function handleActivate() {
    if (!uploadedTemplate) return;
    setActivating(true);
    try {
      const res = await fetch(`/api/templates/${uploadedTemplate.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: TemplateStatus.ACTIVE }),
      });
      if (!res.ok) {
        const json = await res.json();
        throw new Error(json.error ?? "Activation failed");
      }
      toast({ title: "Template activated successfully", variant: "success" });
      router.push("/templates");
    } catch (err) {
      toast({
        title: "Activation failed",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    } finally {
      setActivating(false);
    }
  }

  async function handleCancelAndDelete() {
    if (uploadedTemplate) {
      // Attempt to delete the draft (best-effort)
      try {
        await fetch(`/api/templates/${uploadedTemplate.id}`, { method: "DELETE" });
      } catch {
        // ignore
      }
    }
    router.push("/templates");
  }

  // ── Step indicator ─────────────────────────────────────────────────────────

  function StepIndicator() {
    return (
      <div className="flex items-center gap-2 text-sm">
        <div
          className={`flex items-center gap-1.5 ${step === "form" ? "text-primary font-semibold" : "text-muted-foreground"}`}
        >
          <div
            className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold border ${
              step === "form" ? "border-primary text-primary" : "border-muted-foreground/50 bg-muted"
            }`}
          >
            {step === "preview" ? <CheckCircle2 className="h-3.5 w-3.5 text-green-600" /> : "1"}
          </div>
          Upload & Validate
        </div>
        <div className="h-px w-8 bg-border" />
        <div
          className={`flex items-center gap-1.5 ${step === "preview" ? "text-primary font-semibold" : "text-muted-foreground"}`}
        >
          <div
            className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold border ${
              step === "preview" ? "border-primary text-primary" : "border-muted-foreground/50"
            }`}
          >
            2
          </div>
          Preview & Confirm
        </div>
      </div>
    );
  }

  // ── Step 1: Form ───────────────────────────────────────────────────────────

  if (step === "form") {
    return (
      <div className="space-y-6 p-6 max-w-2xl">
        <Button variant="ghost" size="sm" asChild className="-ml-2">
          <Link href="/templates">
            <ChevronLeft className="h-4 w-4" />
            Back to templates
          </Link>
        </Button>

        <div>
          <h1 className="text-2xl font-bold text-foreground">Upload Assessment Template</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Upload an XLSX file to create a new assessment template
          </p>
        </div>

        <StepIndicator />

        <Card>
          <CardHeader>
            <CardTitle>Template details</CardTitle>
            <CardDescription>
              Provide information about this template, then select your XLSX file
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Name */}
            <div className="space-y-1.5">
              <Label htmlFor="name">
                Template Name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="name"
                placeholder="e.g. NIST CSF Assessment 2024"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={uploading}
              />
            </div>

            {/* Version */}
            <div className="space-y-1.5">
              <Label htmlFor="version">Version</Label>
              <Input
                id="version"
                placeholder="1.0"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                disabled={uploading}
                className="max-w-xs"
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Brief description of this template and its intended use…"
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                disabled={uploading}
              />
            </div>

            {/* File drop zone */}
            <div className="space-y-1.5">
              <Label>XLSX File <span className="text-destructive">*</span></Label>
              <FileDropZone
                file={file}
                onFileSelect={setFile}
                disabled={uploading}
              />
            </div>

            {/* Validation errors */}
            {validationErrors.length > 0 && (
              <div className="rounded-md border border-destructive/30 bg-destructive/5 p-4">
                <div className="flex items-start gap-2 text-destructive mb-2">
                  <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                  <p className="text-sm font-semibold">Validation errors</p>
                </div>
                <ul className="space-y-1 pl-6">
                  {validationErrors.map((err, i) => (
                    <li key={i} className="text-sm text-destructive list-disc">
                      {err}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Warnings */}
            {validationWarnings.length > 0 && (
              <div className="rounded-md border border-amber-300/50 bg-amber-50 p-4">
                <div className="flex items-start gap-2 text-amber-700 mb-2">
                  <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                  <p className="text-sm font-semibold">Warnings</p>
                </div>
                <ul className="space-y-1 pl-6">
                  {validationWarnings.map((w, i) => (
                    <li key={i} className="text-sm text-amber-700 list-disc">
                      {w}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t">
              <Button variant="outline" asChild disabled={uploading}>
                <Link href="/templates">Cancel</Link>
              </Button>
              <Button onClick={handleUpload} disabled={uploading || !file || !name.trim()}>
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Uploading & Validating…
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    Upload & Validate
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Step 2: Preview ────────────────────────────────────────────────────────

  return (
    <div className="space-y-6 p-6 max-w-5xl">
      <Button
        variant="ghost"
        size="sm"
        className="-ml-2"
        onClick={handleCancelAndDelete}
      >
        <ChevronLeft className="h-4 w-4" />
        Back (discard draft)
      </Button>

      <div>
        <h1 className="text-2xl font-bold text-foreground">Preview Template</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Review the parsed template items before confirming
        </p>
      </div>

      <StepIndicator />

      {/* Warnings carry-over */}
      {validationWarnings.length > 0 && (
        <div className="rounded-md border border-amber-300/50 bg-amber-50 p-4">
          <div className="flex items-start gap-2 text-amber-700 mb-2">
            <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
            <p className="text-sm font-semibold">Warnings from upload</p>
          </div>
          <ul className="space-y-1 pl-6">
            {validationWarnings.map((w, i) => (
              <li key={i} className="text-sm text-amber-700 list-disc">
                {w}
              </li>
            ))}
          </ul>
        </div>
      )}

      {previewLoading ? (
        <Card>
          <CardContent className="p-6 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-8 bg-muted animate-pulse rounded" />
            ))}
          </CardContent>
        </Card>
      ) : preview ? (
        <>
          {/* Summary row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "Total Items", value: preview.summary.itemCount },
              { label: "Domains", value: preview.summary.domainCount },
              { label: "Categories", value: preview.summary.categoryCount },
              { label: "Max Score", value: preview.summary.maxScore },
            ].map(({ label, value }) => (
              <Card key={label}>
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-bold">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Domain accordion */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Template Items</CardTitle>
              <CardDescription>
                {preview.template.name} — v{preview.template.version}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {preview.domains.map((domain) => (
                <div key={domain.name} className="border-b last:border-0">
                  {/* Domain header */}
                  <button
                    type="button"
                    onClick={() => toggleDomain(domain.name)}
                    className="w-full flex items-center justify-between px-6 py-4 hover:bg-muted/30 transition-colors text-left"
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-semibold text-foreground">{domain.name}</span>
                      <Badge variant="secondary">{domain.itemCount} items</Badge>
                    </div>
                    <span className="text-muted-foreground text-sm">
                      {expandedDomains[domain.name] ? "▲" : "▼"}
                    </span>
                  </button>

                  {/* Categories */}
                  {expandedDomains[domain.name] && (
                    <div className="border-t">
                      {domain.categories.map((category) => (
                        <div key={category.name} className="border-b last:border-0">
                          {/* Category sub-header */}
                          <div className="flex items-center gap-3 px-8 py-2.5 bg-muted/20">
                            <span className="text-sm font-medium">{category.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {category.itemCount} items · max {category.maxScore} pts
                            </Badge>
                          </div>

                          {/* Items table */}
                          <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="border-b bg-muted/10">
                                  <th className="px-8 py-2 text-left font-medium text-muted-foreground w-24">Code</th>
                                  <th className="px-4 py-2 text-left font-medium text-muted-foreground">Description</th>
                                  <th className="px-4 py-2 text-left font-medium text-muted-foreground">Label</th>
                                  <th className="px-4 py-2 text-right font-medium text-muted-foreground">Score</th>
                                </tr>
                              </thead>
                              <tbody>
                                {category.items.map((item) => (
                                  <tr key={item.id} className="border-b last:border-0 hover:bg-muted/10">
                                    <td className="px-8 py-2">
                                      <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">
                                        {item.code}
                                      </code>
                                    </td>
                                    <td className="px-4 py-2 text-muted-foreground">{item.description}</td>
                                    <td className="px-4 py-2 font-medium">{item.label}</td>
                                    <td className="px-4 py-2 text-right">{item.scoring}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex items-center justify-between border rounded-lg p-4 bg-muted/20">
            <div>
              <p className="text-sm font-medium">Ready to proceed?</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Activate now to make the template available for assessments, or save as draft first.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => router.push("/templates")}>
                <Save className="h-4 w-4" />
                Keep as Draft
              </Button>
              <Button onClick={handleActivate} disabled={activating}>
                {activating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Activating…
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4" />
                    Activate Template
                  </>
                )}
              </Button>
            </div>
          </div>
        </>
      ) : (
        <Card>
          <CardContent className="p-6 text-center text-muted-foreground text-sm">
            Preview data could not be loaded. The template has been saved as a draft.
            <div className="mt-4">
              <Button asChild variant="outline">
                <Link href="/templates">View Templates</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
