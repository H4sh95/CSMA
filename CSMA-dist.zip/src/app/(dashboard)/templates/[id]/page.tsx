"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import {
  ChevronLeft,
  Zap,
  Archive,
  Trash2,
  CalendarDays,
  User,
  Hash,
  Layers,
  Tag,
  FileSpreadsheet,
  AlertCircle,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Role, TemplateStatus } from "@prisma/client";
import { formatDate } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

type TemplateItem = {
  id: string;
  domain: string;
  category: string;
  code: string;
  description: string;
  label: string;
  scoring: number;
  orderIndex: number;
};

type CategoryData = {
  name: string;
  itemCount: number;
  maxScore: number;
  items: TemplateItem[];
};

type DomainData = {
  name: string;
  itemCount: number;
  categories: CategoryData[];
};

type PreviewData = {
  template: {
    id: string;
    name: string;
    version: string;
    description: string | null;
    status: TemplateStatus;
    rowCount: number;
    createdAt: string;
    updatedAt: string;
    uploadedBy: { id: string; name: string; email: string } | null;
  };
  domains: DomainData[];
  summary: {
    domainCount: number;
    categoryCount: number;
    itemCount: number;
    maxScore: number;
  };
};

type ConfirmAction = "activate" | "archive" | "delete" | null;

// ─── Status badge ─────────────────────────────────────────────────────────────

function TemplateStatusBadge({ status }: { status: TemplateStatus }) {
  const map: Record<TemplateStatus, { label: string; variant: "secondary" | "success" | "outline" }> = {
    DRAFT: { label: "Draft", variant: "secondary" },
    ACTIVE: { label: "Active", variant: "success" },
    ARCHIVED: { label: "Archived", variant: "outline" },
  };
  const { label, variant } = map[status];
  return <Badge variant={variant}>{label}</Badge>;
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function TemplateDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { data: session } = useSession();
  const { toast } = useToast();

  const userRole = (session?.user as { role?: string })?.role;
  const canWrite = userRole === Role.ADMIN || userRole === Role.ASSESSOR;
  const isAdmin = userRole === Role.ADMIN;

  const [preview, setPreview] = useState<PreviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<ConfirmAction>(null);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    async function fetchPreview() {
      try {
        const res = await fetch(`/api/templates/${params.id}/preview`);
        if (!res.ok) {
          if (res.status === 404) {
            router.push("/templates");
            return;
          }
          const json = await res.json();
          throw new Error(json.error ?? "Failed to load template");
        }
        const json = await res.json();
        setPreview(json.data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load template");
      } finally {
        setLoading(false);
      }
    }
    fetchPreview();
  }, [params.id, router]);

  async function handleAction() {
    if (!confirmAction || !preview) return;
    setActionLoading(true);

    try {
      if (confirmAction === "delete") {
        const res = await fetch(`/api/templates/${params.id}`, { method: "DELETE" });
        if (!res.ok) {
          const json = await res.json();
          throw new Error(json.error ?? "Delete failed");
        }
        toast({ title: "Template deleted", variant: "success" });
        router.push("/templates");
        return;
      }

      const newStatus =
        confirmAction === "activate" ? TemplateStatus.ACTIVE : TemplateStatus.ARCHIVED;

      const res = await fetch(`/api/templates/${params.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!res.ok) {
        const json = await res.json();
        throw new Error(json.error ?? "Status update failed");
      }

      const json = await res.json();
      // Update the preview with the new status
      setPreview((prev) =>
        prev ? { ...prev, template: { ...prev.template, status: json.data.status } } : prev
      );

      toast({
        title: confirmAction === "activate" ? "Template activated" : "Template archived",
        variant: "success",
      });
      setConfirmAction(null);
    } catch (err) {
      toast({
        title: "Action failed",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    } finally {
      setActionLoading(false);
    }
  }

  const confirmConfig: Record<
    "activate" | "archive" | "delete",
    { title: string; description: string; actionLabel: string; actionClass?: string }
  > = {
    activate: {
      title: "Activate template?",
      description:
        "This template will become available for use in new assessments.",
      actionLabel: "Activate",
    },
    archive: {
      title: "Archive template?",
      description:
        "Archiving this template prevents it from being used in new assessments. Existing assessments are unaffected.",
      actionLabel: "Archive",
      actionClass: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    },
    delete: {
      title: "Permanently delete template?",
      description:
        "This will delete the template and all its items permanently. This cannot be undone. Only templates with no associated assessments can be deleted.",
      actionLabel: "Delete",
      actionClass: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    },
  };

  // ── Loading ───────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <div className="h-6 w-36 bg-muted animate-pulse rounded" />
        <div className="flex items-center justify-between">
          <div className="h-8 w-64 bg-muted animate-pulse rounded" />
          <div className="flex gap-2">
            <div className="h-9 w-24 bg-muted animate-pulse rounded" />
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-3 h-[480px] bg-muted animate-pulse rounded-lg" />
          <div className="h-64 bg-muted animate-pulse rounded-lg" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="rounded-md bg-destructive/10 border border-destructive/20 p-4 flex items-start gap-2 text-destructive">
          <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      </div>
    );
  }

  if (!preview) return null;

  const { template, domains, summary } = preview;
  const isDraft = template.status === TemplateStatus.DRAFT;
  const isActive = template.status === TemplateStatus.ACTIVE;

  return (
    <div className="space-y-6 p-6">
      {/* Back */}
      <Button variant="ghost" size="sm" asChild className="-ml-2">
        <Link href="/templates">
          <ChevronLeft className="h-4 w-4" />
          Back to templates
        </Link>
      </Button>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold text-foreground">{template.name}</h1>
            <code className="text-sm bg-muted px-2 py-0.5 rounded font-mono">
              v{template.version}
            </code>
            <TemplateStatusBadge status={template.status} />
          </div>
          {template.description && (
            <p className="text-sm text-muted-foreground mt-1">{template.description}</p>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 shrink-0">
          {canWrite && isDraft && (
            <Button size="sm" onClick={() => setConfirmAction("activate")}>
              <Zap className="h-4 w-4" />
              Activate
            </Button>
          )}
          {canWrite && isActive && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setConfirmAction("archive")}
            >
              <Archive className="h-4 w-4" />
              Archive
            </Button>
          )}
          {isAdmin && isDraft && (
            <Button
              variant="outline"
              size="sm"
              className="text-destructive border-destructive/30 hover:bg-destructive/10"
              onClick={() => setConfirmAction("delete")}
            >
              <Trash2 className="h-4 w-4" />
              Delete
            </Button>
          )}
        </div>
      </div>

      {/* Metadata row */}
      <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
        {template.uploadedBy && (
          <div className="flex items-center gap-1.5">
            <User className="h-3.5 w-3.5" />
            <span>{template.uploadedBy.name}</span>
          </div>
        )}
        <div className="flex items-center gap-1.5">
          <CalendarDays className="h-3.5 w-3.5" />
          <span>Uploaded {formatDate(template.createdAt)}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Hash className="h-3.5 w-3.5" />
          <span>{template.rowCount} rows</span>
        </div>
      </div>

      {/* Main layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* ── Accordion (3/4 width) ───────────────────────────────────────── */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Template Items</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {domains.length === 0 ? (
                <div className="px-6 py-12 text-center text-sm text-muted-foreground">
                  <FileSpreadsheet className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p>No items in this template.</p>
                </div>
              ) : (
                <Accordion type="multiple" defaultValue={domains.map((d) => d.name)}>
                  {domains.map((domain) => (
                    <AccordionItem key={domain.name} value={domain.name}>
                      <AccordionTrigger className="px-6 hover:no-underline">
                        <div className="flex items-center gap-3 text-left">
                          <span className="font-semibold">{domain.name}</span>
                          <Badge variant="secondary">{domain.itemCount} items</Badge>
                          <Badge variant="outline">
                            {domain.categories.length} categories
                          </Badge>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-0 pb-0">
                        {domain.categories.map((category) => (
                          <div key={category.name} className="border-t">
                            {/* Category header */}
                            <div className="flex items-center gap-3 px-8 py-2.5 bg-muted/20">
                              <Layers className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                              <span className="text-sm font-medium">{category.name}</span>
                              <Badge variant="outline" className="text-xs">
                                {category.itemCount} items · max {category.maxScore} pts
                              </Badge>
                            </div>

                            {/* Items table */}
                            <div className="overflow-x-auto">
                              <table className="w-full text-sm">
                                <thead>
                                  <tr className="border-b bg-muted/10">
                                    <th className="px-8 py-2 text-left font-medium text-muted-foreground w-28">
                                      Code
                                    </th>
                                    <th className="px-4 py-2 text-left font-medium text-muted-foreground">
                                      Description
                                    </th>
                                    <th className="px-4 py-2 text-left font-medium text-muted-foreground">
                                      Label
                                    </th>
                                    <th className="px-4 py-2 text-right font-medium text-muted-foreground w-20">
                                      Max Score
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {category.items.map((item) => (
                                    <tr
                                      key={item.id}
                                      className="border-b last:border-0 hover:bg-muted/10 transition-colors"
                                    >
                                      <td className="px-8 py-2.5">
                                        <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">
                                          {item.code}
                                        </code>
                                      </td>
                                      <td className="px-4 py-2.5 text-muted-foreground">
                                        {item.description}
                                      </td>
                                      <td className="px-4 py-2.5 font-medium">{item.label}</td>
                                      <td className="px-4 py-2.5 text-right">
                                        {item.scoring}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        ))}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ── Sidebar stats (1/4 width) ───────────────────────────────────── */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Hash className="h-4 w-4" />
                  <span className="text-sm">Total Items</span>
                </div>
                <span className="text-sm font-semibold">{summary.itemCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Layers className="h-4 w-4" />
                  <span className="text-sm">Domains</span>
                </div>
                <span className="text-sm font-semibold">{summary.domainCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Tag className="h-4 w-4" />
                  <span className="text-sm">Categories</span>
                </div>
                <span className="text-sm font-semibold">{summary.categoryCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Hash className="h-4 w-4" />
                  <span className="text-sm">Max Score</span>
                </div>
                <span className="text-sm font-semibold">{summary.maxScore}</span>
              </div>

              {summary.itemCount > 0 && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Hash className="h-4 w-4" />
                    <span className="text-sm">Avg Score/Item</span>
                  </div>
                  <span className="text-sm font-semibold">
                    {(summary.maxScore / summary.itemCount).toFixed(1)}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Domain breakdown in sidebar */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Domain Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {domains.map((domain) => (
                <div key={domain.name}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="font-medium truncate" title={domain.name}>
                      {domain.name.length > 20 ? domain.name.slice(0, 18) + "…" : domain.name}
                    </span>
                    <span className="text-muted-foreground shrink-0 ml-1">
                      {domain.itemCount}
                    </span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full"
                      style={{
                        width: `${summary.itemCount > 0 ? (domain.itemCount / summary.itemCount) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Confirmation dialog */}
      <AlertDialog
        open={!!confirmAction}
        onOpenChange={(open) => !open && setConfirmAction(null)}
      >
        {confirmAction && (
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {confirmConfig[confirmAction].title}
              </AlertDialogTitle>
              <AlertDialogDescription>
                <span className="block mb-2">
                  Template: <strong>{template.name}</strong> (v{template.version})
                </span>
                {confirmConfig[confirmAction].description}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={actionLoading}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleAction}
                disabled={actionLoading}
                className={confirmConfig[confirmAction].actionClass}
              >
                {actionLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Please wait…
                  </>
                ) : (
                  confirmConfig[confirmAction].actionLabel
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        )}
      </AlertDialog>
    </div>
  );
}
