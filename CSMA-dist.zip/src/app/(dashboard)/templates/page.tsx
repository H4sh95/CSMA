"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import {
  Plus,
  Eye,
  Zap,
  Archive,
  Trash2,
  FileSpreadsheet,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Role, TemplateStatus } from "@prisma/client";
import { formatDate } from "@/lib/utils";
import type { Template } from "@/types";

type TemplateWithMeta = Template & {
  uploadedBy: { id: string; name: string; email: string } | null;
  _count: { items: number; assessments: number };
};

type PaginatedTemplates = {
  data: TemplateWithMeta[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

type ConfirmAction =
  | { type: "activate"; template: TemplateWithMeta }
  | { type: "archive"; template: TemplateWithMeta }
  | { type: "delete"; template: TemplateWithMeta }
  | null;

function TemplateStatusBadge({ status }: { status: TemplateStatus }) {
  const map: Record<TemplateStatus, { label: string; variant: "secondary" | "success" | "outline" }> = {
    DRAFT: { label: "Draft", variant: "secondary" },
    ACTIVE: { label: "Active", variant: "success" },
    ARCHIVED: { label: "Archived", variant: "outline" },
  };
  const { label, variant } = map[status];
  return <Badge variant={variant}>{label}</Badge>;
}

export default function TemplatesPage() {
  const { data: session } = useSession();
  const { toast } = useToast();

  const userRole = (session?.user as { role?: string })?.role;
  const canWrite = userRole === Role.ADMIN || userRole === Role.ASSESSOR;
  const isAdmin = userRole === Role.ADMIN;

  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [data, setData] = useState<PaginatedTemplates | null>(null);
  const [loading, setLoading] = useState(true);
  const [confirmAction, setConfirmAction] = useState<ConfirmAction>(null);
  const [actionLoading, setActionLoading] = useState(false);

  const fetchTemplates = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("page", String(page));
      params.set("pageSize", "20");
      if (statusFilter && statusFilter !== "all") params.set("status", statusFilter);

      const res = await fetch(`/api/templates?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to load templates");
      const json = await res.json();
      setData(json);
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to load templates",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [page, statusFilter, toast]);

  useEffect(() => {
    fetchTemplates();
  }, [fetchTemplates]);

  useEffect(() => {
    setPage(1);
  }, [statusFilter]);

  async function handleConfirmAction() {
    if (!confirmAction) return;
    setActionLoading(true);

    const { type, template } = confirmAction;

    try {
      if (type === "delete") {
        const res = await fetch(`/api/templates/${template.id}`, { method: "DELETE" });
        if (!res.ok) {
          const json = await res.json();
          throw new Error(json.error ?? "Delete failed");
        }
        toast({ title: "Template deleted", variant: "success" });
      } else {
        const newStatus =
          type === "activate" ? TemplateStatus.ACTIVE : TemplateStatus.ARCHIVED;
        const res = await fetch(`/api/templates/${template.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: newStatus }),
        });
        if (!res.ok) {
          const json = await res.json();
          throw new Error(json.error ?? "Status update failed");
        }
        toast({
          title: type === "activate" ? "Template activated" : "Template archived",
          variant: "success",
        });
      }

      setConfirmAction(null);
      fetchTemplates();
    } catch (err) {
      toast({
        title: "Action failed",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    } finally {
      setActionLoading(false);
    }
  }

  const confirmConfig = {
    activate: {
      title: "Activate template?",
      description:
        "Activating this template will make it available for use in new assessments. You can archive it later.",
      actionLabel: "Activate",
      actionClass: "",
    },
    archive: {
      title: "Archive template?",
      description:
        "Archiving this template will prevent it from being used in new assessments. Existing assessments are unaffected.",
      actionLabel: "Archive",
      actionClass: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    },
    delete: {
      title: "Delete template?",
      description:
        "This will permanently delete the template and all its items. This cannot be undone. Templates with associated assessments cannot be deleted.",
      actionLabel: "Delete",
      actionClass: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    },
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Assessment Templates</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage XLSX-based assessment templates
          </p>
        </div>
        {canWrite && (
          <Button asChild>
            <Link href="/templates/upload">
              <Plus className="h-4 w-4" />
              Upload Template
            </Link>
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="DRAFT">Draft</SelectItem>
            <SelectItem value="ACTIVE">Active</SelectItem>
            <SelectItem value="ARCHIVED">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        {loading ? (
          <CardContent className="p-6 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-12 bg-muted animate-pulse rounded" />
            ))}
          </CardContent>
        ) : !data || data.data.length === 0 ? (
          <CardContent className="py-20 text-center">
            <FileSpreadsheet className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-base font-semibold mb-1">No templates found</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {statusFilter !== "all"
                ? "Try changing the status filter."
                : "Upload your first assessment template to get started."}
            </p>
            {canWrite && statusFilter === "all" && (
              <Button asChild size="sm">
                <Link href="/templates/upload">
                  <Plus className="h-4 w-4" />
                  Upload Template
                </Link>
              </Button>
            )}
          </CardContent>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Version</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-center">Items</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Uploaded By</TableHead>
                  <TableHead>Upload Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.data.map((template) => (
                  <TableRow key={template.id}>
                    <TableCell className="font-medium">{template.name}</TableCell>
                    <TableCell>
                      <code className="text-xs bg-muted px-1.5 py-0.5 rounded">
                        v{template.version}
                      </code>
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <span className="text-sm text-muted-foreground line-clamp-2">
                        {template.description || "—"}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">{template._count.items}</TableCell>
                    <TableCell>
                      <TemplateStatusBadge status={template.status} />
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {template.uploadedBy?.name ?? "—"}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {formatDate(template.createdAt)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/templates/${template.id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">View</span>
                          </Link>
                        </Button>

                        {canWrite && template.status === TemplateStatus.DRAFT && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              setConfirmAction({ type: "activate", template })
                            }
                          >
                            <Zap className="h-4 w-4" />
                            <span className="sr-only">Activate</span>
                          </Button>
                        )}

                        {canWrite && template.status === TemplateStatus.ACTIVE && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              setConfirmAction({ type: "archive", template })
                            }
                          >
                            <Archive className="h-4 w-4" />
                            <span className="sr-only">Archive</span>
                          </Button>
                        )}

                        {isAdmin && template.status === TemplateStatus.DRAFT && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive hover:text-destructive"
                            onClick={() =>
                              setConfirmAction({ type: "delete", template })
                            }
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {/* Pagination */}
            {data.totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t">
                <p className="text-sm text-muted-foreground">
                  Showing {(page - 1) * 20 + 1}–{Math.min(page * 20, data.total)} of{" "}
                  {data.total}
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Button>
                  <span className="text-sm">
                    {page} / {data.totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.min(data.totalPages, p + 1))}
                    disabled={page === data.totalPages}
                  >
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </Card>

      {/* Confirmation dialog */}
      <AlertDialog
        open={!!confirmAction}
        onOpenChange={(open) => !open && setConfirmAction(null)}
      >
        {confirmAction && (
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {confirmConfig[confirmAction.type].title}
              </AlertDialogTitle>
              <AlertDialogDescription>
                <span className="block mb-2">
                  Template: <strong>{confirmAction.template.name}</strong> (v
                  {confirmAction.template.version})
                </span>
                {confirmConfig[confirmAction.type].description}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={actionLoading}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleConfirmAction}
                disabled={actionLoading}
                className={confirmConfig[confirmAction.type].actionClass}
              >
                {actionLoading
                  ? "Please wait…"
                  : confirmConfig[confirmAction.type].actionLabel}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        )}
      </AlertDialog>
    </div>
  );
}
