"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import {
  ClipboardList,
  Users,
  FileSpreadsheet,
  TrendingUp,
  AlertTriangle,
  Clock,
  ThumbsDown,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDate, formatScore } from "@/lib/utils";
import { Role } from "@prisma/client";
import type { DashboardStats } from "@/types";

type AttentionItem = DashboardStats["attentionItems"][number] & { reason?: string };

// ─── Skeleton helpers ────────────────────────────────────────────────────────

function SkeletonCard() {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <div className="h-4 w-32 bg-muted animate-pulse rounded" />
          <div className="h-8 w-8 bg-muted animate-pulse rounded" />
        </div>
        <div className="h-8 w-20 bg-muted animate-pulse rounded mb-1" />
        <div className="h-3 w-24 bg-muted animate-pulse rounded" />
      </CardContent>
    </Card>
  );
}

function SkeletonChart() {
  return (
    <Card>
      <CardHeader>
        <div className="h-5 w-48 bg-muted animate-pulse rounded" />
      </CardHeader>
      <CardContent>
        <div className="h-64 bg-muted animate-pulse rounded" />
      </CardContent>
    </Card>
  );
}

function SkeletonTable() {
  return (
    <Card>
      <CardHeader>
        <div className="h-5 w-40 bg-muted animate-pulse rounded" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-10 bg-muted animate-pulse rounded" />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Status badge helper ─────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; variant: "default" | "secondary" | "outline" | "success" | "warning" | "destructive" }> = {
    DRAFT: { label: "Draft", variant: "secondary" },
    IN_PROGRESS: { label: "In Progress", variant: "warning" },
    COMPLETED: { label: "Completed", variant: "success" },
    ARCHIVED: { label: "Archived", variant: "outline" },
  };
  const { label, variant } = map[status] ?? { label: status, variant: "default" };
  return <Badge variant={variant}>{label}</Badge>;
}

// ─── Attention reason icon ────────────────────────────────────────────────────

function AttentionIcon({ status, score }: { status: string; score: number | null }) {
  if (status === "COMPLETED" && score !== null && score < 40) {
    return <ThumbsDown className="h-4 w-4 text-destructive shrink-0" />;
  }
  if (status === "IN_PROGRESS") {
    return <Clock className="h-4 w-4 text-amber-500 shrink-0" />;
  }
  return <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" />;
}

// ─── Stat card ────────────────────────────────────────────────────────────────

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBg: string;
  subtitle?: string;
}

function StatCard({ title, value, icon, iconBg, subtitle }: StatCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-3xl font-bold text-foreground mt-1">{value}</p>
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
            )}
          </div>
          <div className={`flex items-center justify-center h-12 w-12 rounded-lg ${iconBg}`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Status breakdown chart data ─────────────────────────────────────────────

const STATUS_COLORS: Record<string, string> = {
  DRAFT: "#94a3b8",
  IN_PROGRESS: "#f59e0b",
  COMPLETED: "#10b981",
  ARCHIVED: "#6b7280",
};

// ─── Main dashboard component ─────────────────────────────────────────────────

export default function DashboardPage() {
  const { data: session } = useSession();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const isCustomer = session?.user && (session.user as { role?: string }).role === Role.CUSTOMER;
  const pageTitle = isCustomer ? "Your Assessment Summary" : "Platform Overview";

  useEffect(() => {
    async function fetchDashboard() {
      try {
        setLoading(true);
        const res = await fetch("/api/dashboard");
        if (!res.ok) throw new Error("Failed to load dashboard data");
        const json = await res.json();
        setStats(json.data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred");
      } finally {
        setLoading(false);
      }
    }
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <div className="h-8 w-64 bg-muted animate-pulse rounded" />
        {/* Stats row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
        {/* Charts row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <SkeletonChart />
          <SkeletonChart />
        </div>
        {/* Bottom row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <SkeletonTable />
          </div>
          <SkeletonTable />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="rounded-md bg-destructive/10 border border-destructive/20 p-4 text-destructive text-sm">
          {error}
        </div>
      </div>
    );
  }

  if (!stats) return null;

  // Prepare status breakdown chart data
  const statusChartData = [
    { name: "Draft", count: stats.completionBreakdown.DRAFT, fill: STATUS_COLORS.DRAFT },
    { name: "In Progress", count: stats.completionBreakdown.IN_PROGRESS, fill: STATUS_COLORS.IN_PROGRESS },
    { name: "Completed", count: stats.completionBreakdown.COMPLETED, fill: STATUS_COLORS.COMPLETED },
    { name: "Archived", count: stats.completionBreakdown.ARCHIVED, fill: STATUS_COLORS.ARCHIVED },
  ];

  // Prepare domain scores chart data
  const domainChartData = stats.domainScores.map((d) => ({
    name: d.domain.length > 16 ? d.domain.slice(0, 14) + "…" : d.domain,
    fullName: d.domain,
    percentage: Math.round(d.percentage),
  }));

  return (
    <div className="space-y-6 p-6">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">{pageTitle}</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {isCustomer
            ? "Overview of your cybersecurity maturity assessments"
            : "Real-time metrics across all profiles and assessments"}
        </p>
      </div>

      {/* ── Row 1: Stats ─────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Assessments"
          value={stats.totalAssessments}
          icon={<ClipboardList className="h-6 w-6 text-slate-500" />}
          iconBg="bg-slate-50"
          subtitle={`${stats.completionBreakdown.COMPLETED} completed`}
        />
        <StatCard
          title="Total Profiles"
          value={stats.totalProfiles}
          icon={<Users className="h-6 w-6 text-purple-600" />}
          iconBg="bg-purple-50"
        />
        {!isCustomer && (
          <StatCard
            title="Total Templates"
            value={stats.totalTemplates}
            icon={<FileSpreadsheet className="h-6 w-6 text-green-600" />}
            iconBg="bg-green-50"
          />
        )}
        {isCustomer && (
          <StatCard
            title="In Progress"
            value={stats.completionBreakdown.IN_PROGRESS}
            icon={<Clock className="h-6 w-6 text-amber-600" />}
            iconBg="bg-amber-50"
          />
        )}
        <StatCard
          title="Average Score"
          value={formatScore(stats.averageScore)}
          icon={<TrendingUp className="h-6 w-6 text-orange-600" />}
          iconBg="bg-orange-50"
          subtitle="Completed assessments"
        />
      </div>

      {/* ── Row 2: Charts ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Assessment Status Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">
              Assessment Status Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={statusChartData} margin={{ top: 4, right: 16, left: 0, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                <Tooltip
                  formatter={(value: number) => [value, "Assessments"]}
                />
                <Bar dataKey="count" name="Assessments" radius={[4, 4, 0, 0]}>
                  {statusChartData.map((entry, index) => (
                    <Cell key={index} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Domain Scores */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">
              Domain Scores (Average %)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {domainChartData.length === 0 ? (
              <div className="flex items-center justify-center h-[240px] text-sm text-muted-foreground">
                No domain score data available yet
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={240}>
                <BarChart
                  data={domainChartData}
                  margin={{ top: 4, right: 16, left: 0, bottom: 32 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 11 }}
                    angle={-30}
                    textAnchor="end"
                    interval={0}
                  />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} unit="%" />
                  <Tooltip
                    formatter={(value: number) => [`${value}%`, "Avg Score"]}
                    labelFormatter={(label) => {
                      const item = domainChartData.find((d) => d.name === label);
                      return item?.fullName ?? label;
                    }}
                  />
                  <Bar
                    dataKey="percentage"
                    name="Avg Score"
                    fill="#94a3b8"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Row 3: Recent Assessments + Requires Attention ───────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Recent Assessments (2/3) */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base font-semibold">Recent Assessments</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {stats.recentAssessments.length === 0 ? (
              <div className="px-6 py-10 text-center text-sm text-muted-foreground">
                No assessments found. Start by creating a new assessment.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/40">
                      <th className="h-10 px-4 text-left font-medium text-muted-foreground">Title</th>
                      <th className="h-10 px-4 text-left font-medium text-muted-foreground">Profile</th>
                      <th className="h-10 px-4 text-left font-medium text-muted-foreground">Status</th>
                      <th className="h-10 px-4 text-right font-medium text-muted-foreground">Score</th>
                      <th className="h-10 px-4 text-right font-medium text-muted-foreground">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.recentAssessments.map((assessment) => (
                      <tr
                        key={assessment.id}
                        className="border-b last:border-0 hover:bg-muted/30 transition-colors"
                      >
                        <td className="px-4 py-3 font-medium">
                          <Link
                            href={
                              assessment.status === "COMPLETED"
                                ? `/results/${assessment.id}`
                                : `/assessments/${assessment.id}`
                            }
                            className="hover:underline text-foreground"
                          >
                            {assessment.title}
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{assessment.profileName}</td>
                        <td className="px-4 py-3">
                          <StatusBadge status={assessment.status} />
                        </td>
                        <td className="px-4 py-3 text-right">
                          {assessment.overallScore !== null
                            ? formatScore(assessment.overallScore)
                            : "—"}
                        </td>
                        <td className="px-4 py-3 text-right text-muted-foreground">
                          {formatDate(assessment.createdAt)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Requires Attention (1/3) */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Requires Attention</CardTitle>
          </CardHeader>
          <CardContent>
            {(stats.attentionItems as AttentionItem[]).length === 0 ? (
              <div className="py-8 text-center text-sm text-muted-foreground">
                No items require attention right now.
              </div>
            ) : (
              <div className="space-y-3">
                {(stats.attentionItems as AttentionItem[]).slice(0, 6).map((item) => (
                  <div key={item.id} className="flex gap-2 p-3 rounded-md border bg-muted/20">
                    <AttentionIcon status={item.status} score={item.overallScore} />
                    <div className="min-w-0 flex-1">
                      <Link
                        href={
                          item.status === "COMPLETED"
                            ? `/results/${item.id}`
                            : `/assessments/${item.id}`
                        }
                        className="text-sm font-medium hover:underline line-clamp-1"
                      >
                        {item.title}
                      </Link>
                      <p className="text-xs text-muted-foreground mt-0.5">{item.profileName}</p>
                      {item.reason && (
                        <p className="text-xs text-amber-600 mt-0.5">{item.reason}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
