"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  Search,
  BarChart2,
  FileDown,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useDebounce } from "@/hooks/use-debounce";
import { formatDate, formatScore } from "@/lib/utils";
import { getScoreColor, getScoreLabel } from "@/lib/scoring";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Profile {
  id: string;
  name: string;
  identifier: string;
}

interface Template {
  id: string;
  name: string;
  version: string;
}

interface ResultItem {
  id: string;
  title: string;
  overallScore: number | null;
  completedAt: string | null;
  status: string;
  profile: Profile;
  template: Template;
  createdBy: { id: string; name: string; email: string };
  domainScores: Array<{ domain: string; percentage: number }>;
}

interface PaginatedResponse {
  data: ResultItem[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// ─── Score badge ──────────────────────────────────────────────────────────────

function ScoreBadge({ score }: { score: number | null }) {
  if (score === null) return <span className="text-muted-foreground">—</span>;
  const color = getScoreColor(score);
  const label = getScoreLabel(score);
  const colorMap: Record<string, string> = {
    "red-500": "bg-red-100 text-red-800 border-red-200",
    "orange-500": "bg-orange-100 text-orange-800 border-orange-200",
    "yellow-500": "bg-yellow-100 text-yellow-800 border-yellow-200",
    "green-500": "bg-green-100 text-green-800 border-green-200",
    "emerald-500": "bg-emerald-100 text-emerald-800 border-emerald-200",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold ${colorMap[color] ?? "bg-muted text-foreground"}`}>
      {formatScore(score)}
      <span className="text-opacity-80">· {label}</span>
    </span>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────

const PAGE_SIZE = 20;

export default function ResultsPage() {
  const { toast } = useToast();

  // ── Filters ─────────────────────────────────────────────────────────────────
  const [search, setSearch] = useState("");
  const [profileFilter, setProfileFilter] = useState("ALL");
  const [templateFilter, setTemplateFilter] = useState("ALL");
  const [assessorFilter, setAssessorFilter] = useState("ALL");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [scoreMin, setScoreMin] = useState("");
  const [scoreMax, setScoreMax] = useState("");
  const [page, setPage] = useState(1);

  const debouncedSearch = useDebounce(search, 350);

  // ── Reference data ───────────────────────────────────────────────────────
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [assessors, setAssessors] = useState<{ id: string; name: string }[]>([]);

  // ── Result data ──────────────────────────────────────────────────────────
  const [result, setResult] = useState<PaginatedResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [exportingId, setExportingId] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/profiles?pageSize=200")
      .then((r) => r.json())
      .then((json) => setProfiles(json.data ?? []))
      .catch(() => {/* ignore */});

    fetch("/api/templates?pageSize=200")
      .then((r) => r.json())
      .then((json) => setTemplates(json.data ?? []))
      .catch(() => {/* ignore */});

    fetch("/api/admin/users?role=ASSESSOR&pageSize=200")
      .then((r) => r.json())
      .then((json) => setAssessors(json.data ?? []))
      .catch(() => {/* ignore */});
  }, []);

  const fetchResults = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(PAGE_SIZE) });
      if (debouncedSearch) params.set("search", debouncedSearch);
      if (profileFilter !== "ALL") params.set("profileId", profileFilter);
      if (templateFilter !== "ALL") params.set("templateId", templateFilter);
      if (assessorFilter !== "ALL") params.set("assessorId", assessorFilter);
      if (dateFrom) params.set("dateFrom", dateFrom);
      if (dateTo) params.set("dateTo", dateTo);
      if (scoreMin) params.set("scoreMin", scoreMin);
      if (scoreMax) params.set("scoreMax", scoreMax);

      const res = await fetch(`/api/results?${params}`);
      if (!res.ok) throw new Error("Failed to load results");
      const json = await res.json();
      setResult(json);
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to load results", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [page, debouncedSearch, profileFilter, templateFilter, assessorFilter, dateFrom, dateTo, scoreMin, scoreMax, toast]);

  useEffect(() => {
    fetchResults();
  }, [fetchResults]);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, profileFilter, templateFilter, assessorFilter, dateFrom, dateTo, scoreMin, scoreMax]);

  async function handleExport(id: string, format: "pdf" | "xlsx") {
    setExportingId(`${id}-${format}`);
    try {
      const res = await fetch(`/api/results/${id}/export?format=${format}`);
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `assessment-${id}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast({ title: "Export failed", description: err instanceof Error ? err.message : "Could not export file", variant: "destructive" });
    } finally {
      setExportingId(null);
    }
  }

  const results = result?.data ?? [];
  const totalPages = result?.totalPages ?? 1;
  const total = result?.total ?? 0;

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Assessment Results</h1>
        <p className="text-sm text-muted-foreground mt-1">Completed assessments with full score breakdowns</p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Search */}
            <div className="relative sm:col-span-2 lg:col-span-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search assessments..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Profile */}
            <Select value={profileFilter} onValueChange={setProfileFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Profiles" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Profiles</SelectItem>
                {profiles.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Template */}
            <Select value={templateFilter} onValueChange={setTemplateFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Templates" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Templates</SelectItem>
                {templates.map((t) => (
                  <SelectItem key={t.id} value={t.id}>{t.name} v{t.version}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Assessor */}
            <Select value={assessorFilter} onValueChange={setAssessorFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Assessors" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Assessors</SelectItem>
                {assessors.map((a) => (
                  <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Date range */}
            <div className="flex items-center gap-2">
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="text-sm" title="Completed from" />
              <span className="text-muted-foreground shrink-0">–</span>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="text-sm" title="Completed to" />
            </div>

            {/* Score range */}
            <div className="flex items-center gap-2">
              <Input
                type="number"
                placeholder="Min %"
                min={0}
                max={100}
                value={scoreMin}
                onChange={(e) => setScoreMin(e.target.value)}
                className="text-sm"
              />
              <span className="text-muted-foreground shrink-0">–</span>
              <Input
                type="number"
                placeholder="Max %"
                min={0}
                max={100}
                value={scoreMax}
                onChange={(e) => setScoreMax(e.target.value)}
                className="text-sm"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="py-4 px-6 border-b">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            {loading ? "Loading..." : `${total} result${total !== 1 ? "s" : ""} found`}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-0">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-14 border-b bg-muted/20 animate-pulse" />
              ))}
            </div>
          ) : results.length === 0 ? (
            <div className="py-16 text-center text-sm text-muted-foreground">
              No completed assessments found matching your filters.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Profile</TableHead>
                  <TableHead>Template</TableHead>
                  <TableHead>Overall Score</TableHead>
                  <TableHead className="text-center">Domains</TableHead>
                  <TableHead>Completed</TableHead>
                  <TableHead>Assessor</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium max-w-[200px] truncate">
                      <Link
                        href={`/results/${r.id}`}
                        className="hover:underline text-foreground"
                      >
                        {r.title}
                      </Link>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {r.profile.name}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {r.template.name}
                      <span className="ml-1 text-xs text-muted-foreground/60">v{r.template.version}</span>
                    </TableCell>
                    <TableCell>
                      <ScoreBadge score={r.overallScore} />
                    </TableCell>
                    <TableCell className="text-center text-sm text-muted-foreground">
                      {r.domainScores.length}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {r.completedAt ? formatDate(r.completedAt) : "—"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {r.createdBy.name}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" asChild title="View details">
                          <Link href={`/results/${r.id}`}>
                            <BarChart2 className="h-4 w-4" />
                            <span className="hidden sm:inline ml-1">View</span>
                          </Link>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          title="Export PDF"
                          onClick={() => handleExport(r.id, "pdf")}
                          disabled={exportingId === `${r.id}-pdf`}
                        >
                          <FileDown className="h-4 w-4" />
                          <span className="hidden sm:inline ml-1">PDF</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          title="Export XLSX"
                          onClick={() => handleExport(r.id, "xlsx")}
                          disabled={exportingId === `${r.id}-xlsx`}
                        >
                          <FileDown className="h-4 w-4" />
                          <span className="hidden sm:inline ml-1">XLSX</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>
              <ChevronLeft className="h-4 w-4" />
              Previous
            </Button>
            <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
