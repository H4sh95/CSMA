"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, FileDown, ChevronDown, ChevronRight, Loader2, AlertTriangle, Brain, RefreshCw, Sparkles } from "lucide-react";
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatScore, cn } from "@/lib/utils";
import { getScoreLabel, getScoreColor } from "@/lib/scoring";
import type { AssessmentWithRelations } from "@/types";

// ─── Extended type with history ───────────────────────────────────────────────

interface AiAnalysisData {
  id: string;
  versionNumber: number;
  generatedByName: string | null;
  generationMode: string;
  modelUsed: string | null;
  deploymentUsed: string | null;
  currentState: string;
  immediateActions: string[];
  mediumTermActions: string[];
  longTermActions: string[];
  deduplicationApplied: boolean;
  tokenCount: number | null;
  createdAt: string;
}

interface HistoryItem {
  id: string;
  title: string;
  overallScore: number | null;
  completedAt: string | null;
  createdAt: string;
  template: { id: string; name: string; version: string };
  domainScores: Array<{ domain: string; percentage: number }>;
}

type ResultData = AssessmentWithRelations & { history: HistoryItem[] };

// ─── Helpers ──────────────────────────────────────────────────────────────────

function scoreColorClass(pct: number) {
  const c = getScoreColor(pct);
  const map: Record<string, string> = {
    "red-500": "#ef4444",
    "orange-500": "#f97316",
    "yellow-500": "#eab308",
    "green-500": "#22c55e",
    "emerald-500": "#10b981",
  };
  return map[c] ?? "#6b7280";
}

function ScoreBadgeInline({ score }: { score: number }) {
  const label = getScoreLabel(score);
  const colorMap: Record<string, string> = {
    Critical: "bg-red-100 text-red-800 border-red-200",
    Low: "bg-orange-100 text-orange-800 border-orange-200",
    Moderate: "bg-yellow-100 text-yellow-800 border-yellow-200",
    Good: "bg-green-100 text-green-800 border-green-200",
    Excellent: "bg-emerald-100 text-emerald-800 border-emerald-200",
  };
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${colorMap[label] ?? "bg-muted"}`}>
      {label}
    </span>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ResultDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const router = useRouter();
  const { toast } = useToast();

  const [data, setData] = useState<ResultData | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedDomains, setExpandedDomains] = useState<Set<string>>(new Set());
  const [exportingFormat, setExportingFormat] = useState<"pdf" | "xlsx" | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<AiAnalysisData | null>(null);
  const [aiEnabled, setAiEnabled] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);

  useEffect(() => {
    if (!id) return;
    fetch(`/api/results/${id}`)
      .then((r) => r.json())
      .then((json) => {
        if (json.error) throw new Error(json.error);
        setData(json.data);
      })
      .catch((err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
        router.push("/results");
      })
      .finally(() => setLoading(false));
  }, [id, router, toast]);

  useEffect(() => {
    if (!id) return;
    setAiLoading(true);
    fetch(`/api/results/${id}/ai-analysis`)
      .then((r) => r.json())
      .then((json) => {
        setAiAnalysis(json.data ?? null);
        setAiEnabled(json.aiEnabled ?? false);
      })
      .catch(() => {/* silent — AI is non-critical */})
      .finally(() => setAiLoading(false));
  }, [id]);

  async function handleExport(format: "pdf" | "xlsx") {
    setExportingFormat(format);
    try {
      const res = await fetch(`/api/results/${id}/export?format=${format}`);
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `assessment-${id}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast({ title: "Export failed", description: err instanceof Error ? err.message : "Could not export", variant: "destructive" });
    } finally {
      setExportingFormat(null);
    }
  }

  async function handleGenerateAi() {
    setAiGenerating(true);
    try {
      const res = await fetch(`/api/results/${id}/ai-analysis`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: aiAnalysis ? "regenerated" : "manual" }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Generation failed");
      // Re-fetch the analysis
      const refetch = await fetch(`/api/results/${id}/ai-analysis`);
      const refetchJson = await refetch.json();
      setAiAnalysis(refetchJson.data ?? null);
      setAiEnabled(refetchJson.aiEnabled ?? false);
      toast({ title: "AI Analysis generated", description: "The analysis has been successfully generated.", variant: "success" });
    } catch (err) {
      toast({ title: "AI Analysis failed", description: err instanceof Error ? err.message : "Could not generate analysis", variant: "destructive" });
    } finally {
      setAiGenerating(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data) return null;

  const score = data.overallScore ?? 0;
  // `responses` only contains stubs for included (non-excluded) items
  const totalItems = data.responses.length;
  const answeredItems = data.responses.filter((r) => r.isAnswered).length;
  const completionPct = totalItems > 0 ? (answeredItems / totalItems) * 100 : 0;
  const excludedDomains: string[] = (data as typeof data & { excludedDomains?: string[] }).excludedDomains ?? [];

  // ── Domain chart data ──────────────────────────────────────────────────────
  const domainChartData = data.domainScores.map((ds) => ({
    domain: ds.domain.length > 18 ? ds.domain.slice(0, 16) + "…" : ds.domain,
    fullDomain: ds.domain,
    percentage: Math.round(ds.percentage),
    fill: scoreColorClass(ds.percentage),
  }));

  // ── Category data per domain ───────────────────────────────────────────────
  const categoryByDomain = new Map<string, typeof data.categoryScores>();
  for (const cs of data.categoryScores) {
    if (!categoryByDomain.has(cs.domain)) categoryByDomain.set(cs.domain, []);
    categoryByDomain.get(cs.domain)!.push(cs);
  }

  // ── Strengths & weaknesses ─────────────────────────────────────────────────
  const sortedDomains = [...data.domainScores].sort((a, b) => b.percentage - a.percentage);
  const strengths = sortedDomains.slice(0, 3);
  const weaknesses = [...sortedDomains].reverse().slice(0, 3);

  // ── Historical chart data ──────────────────────────────────────────────────
  const hasHistory = data.history.length > 0;
  const historyChartData = [
    ...data.history.map((h) => ({
      date: formatDate(h.completedAt ?? h.createdAt),
      score: h.overallScore ?? 0,
      title: h.title,
    })).reverse(),
    {
      date: formatDate(data.completedAt ?? data.createdAt),
      score: data.overallScore ?? 0,
      title: data.title,
    },
  ];

  // ── Grouped responses for accordion ───────────────────────────────────────
  const domainMap = new Map<string, Map<string, typeof data.responses>>();
  for (const r of data.responses) {
    const domain = r.templateItem.domain;
    const category = r.templateItem.category;
    if (!domainMap.has(domain)) domainMap.set(domain, new Map());
    const catMap = domainMap.get(domain)!;
    if (!catMap.has(category)) catMap.set(category, []);
    catMap.get(category)!.push(r);
  }

  return (
    <div className="space-y-6 p-6 max-w-6xl mx-auto">
      {/* Back */}
      <Button variant="ghost" size="sm" asChild>
        <Link href="/results">
          <ArrowLeft className="h-4 w-4" />
          Back to Results
        </Link>
      </Button>

      {/* ── Section 1: Header ────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold">{data.title}</h1>
            <Badge variant="success">Completed</Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            {data.profile.name} &middot; {data.template.name} v{data.template.version}
          </p>
          <p className="text-xs text-muted-foreground">
            Assessed by {data.createdBy.name}
            {data.completedAt && ` · Completed ${formatDate(data.completedAt)}`}
          </p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport("pdf")}
            disabled={!!exportingFormat}
          >
            {exportingFormat === "pdf" ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileDown className="h-4 w-4" />}
            PDF
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport("xlsx")}
            disabled={!!exportingFormat}
          >
            {exportingFormat === "xlsx" ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileDown className="h-4 w-4" />}
            XLSX
          </Button>
        </div>
      </div>

      {/* ── Excluded-domain notice ───────────────────────────────────────────── */}
      {excludedDomains.length > 0 && (
        <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-amber-800">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold">
              Partial assessment — {excludedDomains.length} domain{excludedDomains.length !== 1 ? "s" : ""} excluded
            </p>
            <p className="mt-0.5 text-amber-700">
              The overall score and domain breakdown reflect only the included domains.
              The following domain{excludedDomains.length !== 1 ? "s were" : " was"} not assessed:{" "}
              <strong>{excludedDomains.join(", ")}</strong>
            </p>
          </div>
        </div>
      )}

      {/* ── Section 2: Executive Summary ─────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle>Executive Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {/* Overall score */}
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="relative w-28 h-28">
                <svg className="w-28 h-28 -rotate-90" viewBox="0 0 120 120">
                  <circle cx="60" cy="60" r="50" fill="none" stroke="#e5e7eb" strokeWidth="10" />
                  <circle
                    cx="60"
                    cy="60"
                    r="50"
                    fill="none"
                    stroke={scoreColorClass(score)}
                    strokeWidth="10"
                    strokeDasharray={`${(score / 100) * 314} 314`}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold">{score.toFixed(1)}%</span>
                </div>
              </div>
              <ScoreBadgeInline score={score} />
              <p className="text-xs text-muted-foreground text-center">Overall Maturity Score</p>
            </div>

            {/* Completion stats */}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Completion</span>
                  <span className="font-semibold">{Math.round(completionPct)}%</span>
                </div>
                <Progress value={completionPct} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">{answeredItems} / {totalItems} items answered</p>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Score</span>
                  <span className="font-semibold">{formatScore(score)}</span>
                </div>
                <Progress value={score} className="h-2" />
              </div>
            </div>

            {/* Quick stats */}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border p-3 text-center">
                <p className="text-2xl font-bold">{data.domainScores.length}</p>
                <p className="text-xs text-muted-foreground">Domains</p>
              </div>
              <div className="rounded-lg border p-3 text-center">
                <p className="text-2xl font-bold">{data.categoryScores.length}</p>
                <p className="text-xs text-muted-foreground">Categories</p>
              </div>
              <div className="rounded-lg border p-3 text-center">
                <p className="text-2xl font-bold">{answeredItems}</p>
                <p className="text-xs text-muted-foreground">Answered</p>
              </div>
              <div className="rounded-lg border p-3 text-center">
                <p className="text-2xl font-bold">{totalItems - answeredItems}</p>
                <p className="text-xs text-muted-foreground">Unanswered</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── Section 3: Domain Scores Bar Chart ───────────────────────────────── */}
      {domainChartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Domain Scores</CardTitle>
            <CardDescription>Score percentage per domain (0–100%)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={Math.max(200, domainChartData.length * 40)}>
              <BarChart
                data={domainChartData}
                layout="vertical"
                margin={{ top: 0, right: 40, left: 8, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} unit="%" tick={{ fontSize: 12 }} />
                <YAxis type="category" dataKey="domain" width={140} tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(value: number) => [`${value}%`, "Score"]}
                  labelFormatter={(label) => {
                    const item = domainChartData.find((d) => d.domain === label);
                    return item?.fullDomain ?? label;
                  }}
                />
                <Bar dataKey="percentage" name="Score %" radius={[0, 4, 4, 0]}>
                  {domainChartData.map((entry, index) => (
                    <Cell key={index} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* ── Section 4: Category Breakdown ────────────────────────────────────── */}
      {categoryByDomain.size > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Category Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={data.domainScores[0]?.domain ?? ""}>
              <TabsList className="flex flex-wrap h-auto gap-1 mb-4">
                {data.domainScores.map((ds) => (
                  <TabsTrigger key={ds.domain} value={ds.domain} className="text-xs">
                    {ds.domain}
                  </TabsTrigger>
                ))}
              </TabsList>
              {data.domainScores.map((ds) => {
                const categories = categoryByDomain.get(ds.domain) ?? [];
                return (
                  <TabsContent key={ds.domain} value={ds.domain}>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Category</TableHead>
                          <TableHead className="text-right">Score</TableHead>
                          <TableHead className="text-right">Max</TableHead>
                          <TableHead className="text-right">Percentage</TableHead>
                          <TableHead className="text-right">Items</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {categories.map((cs) => (
                          <TableRow key={cs.id}>
                            <TableCell className="font-medium">{cs.category}</TableCell>
                            <TableCell className="text-right">{cs.score.toFixed(1)}</TableCell>
                            <TableCell className="text-right">{cs.maxScore.toFixed(1)}</TableCell>
                            <TableCell className="text-right">
                              <span className="font-semibold" style={{ color: scoreColorClass(cs.percentage) }}>
                                {cs.percentage.toFixed(1)}%
                              </span>
                            </TableCell>
                            <TableCell className="text-right text-muted-foreground">
                              {cs.answeredCount}/{cs.itemCount}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TabsContent>
                );
              })}
            </Tabs>
          </CardContent>
        </Card>
      )}

      {/* ── Section 5: Strengths & Weaknesses ────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-emerald-700">Strengths</CardTitle>
            <CardDescription>Top performing domains</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {strengths.map((ds, i) => (
              <div key={ds.domain} className="flex items-center gap-3">
                <span className="text-xs font-bold text-muted-foreground w-4">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="truncate">{ds.domain}</span>
                    <span className="font-semibold text-emerald-700 ml-2 shrink-0">{ds.percentage.toFixed(1)}%</span>
                  </div>
                  <Progress value={ds.percentage} className="h-1.5" />
                </div>
              </div>
            ))}
            {strengths.length === 0 && (
              <p className="text-sm text-muted-foreground">No domain data available.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base text-destructive">Areas for Improvement</CardTitle>
            <CardDescription>Lowest scoring domains</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {weaknesses.map((ds, i) => (
              <div key={ds.domain} className="flex items-center gap-3">
                <span className="text-xs font-bold text-muted-foreground w-4">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="truncate">{ds.domain}</span>
                    <span className="font-semibold text-destructive ml-2 shrink-0">{ds.percentage.toFixed(1)}%</span>
                  </div>
                  <Progress value={ds.percentage} className="h-1.5 [&>div]:bg-destructive" />
                </div>
              </div>
            ))}
            {weaknesses.length === 0 && (
              <p className="text-sm text-muted-foreground">No domain data available.</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Section 6: Historical Comparison ─────────────────────────────────── */}
      {hasHistory && (
        <Card>
          <CardHeader>
            <CardTitle>Historical Comparison</CardTitle>
            <CardDescription>Overall score trend for {data.profile.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={historyChartData} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} unit="%" />
                <Tooltip
                  formatter={(value: number) => [`${value.toFixed(1)}%`, "Score"]}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="score"
                  name="Overall Score"
                  stroke="#94a3b8"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* ── Section 6b: AI Analysis ──────────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-primary" />
              <CardTitle>AI Analysis</CardTitle>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">AI-generated</span>
            </div>
            {(data as ResultData & { _userRole?: string }) && (
              <div className="flex items-center gap-2">
                {aiGenerating ? (
                  <Button size="sm" variant="outline" disabled>
                    <Loader2 className="h-4 w-4 animate-spin" /> Generating...
                  </Button>
                ) : aiEnabled ? (
                  <Button size="sm" variant="outline" onClick={handleGenerateAi} disabled={aiLoading}>
                    {aiAnalysis ? (
                      <><RefreshCw className="h-4 w-4" /> Regenerate</>
                    ) : (
                      <><Sparkles className="h-4 w-4" /> Generate Analysis</>
                    )}
                  </Button>
                ) : null}
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {aiLoading ? (
            <div className="flex items-center gap-2 py-8 justify-center text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              <span className="text-sm">Loading AI analysis...</span>
            </div>
          ) : !aiEnabled && !aiAnalysis ? (
            <div className="flex flex-col items-center gap-2 py-8 text-center">
              <Brain className="h-8 w-8 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">AI analysis is not enabled.</p>
              <p className="text-xs text-muted-foreground">Contact your administrator to configure Azure OpenAI integration.</p>
            </div>
          ) : !aiAnalysis ? (
            <div className="flex flex-col items-center gap-2 py-8 text-center">
              <Sparkles className="h-8 w-8 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">No AI analysis has been generated yet.</p>
              {aiEnabled && (
                <p className="text-xs text-muted-foreground">Click &quot;Generate Analysis&quot; to create one.</p>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              {/* Meta */}
              <div className="flex flex-wrap gap-3 text-xs text-muted-foreground border-b pb-4">
                <span>Generated: {new Date(aiAnalysis.createdAt).toLocaleString()}</span>
                {aiAnalysis.generatedByName && <span>By: {aiAnalysis.generatedByName}</span>}
                {aiAnalysis.modelUsed && <span>Model: {aiAnalysis.modelUsed}</span>}
                {aiAnalysis.deploymentUsed && <span>Deployment: {aiAnalysis.deploymentUsed}</span>}
                <span className="capitalize">Mode: {aiAnalysis.generationMode}</span>
                {aiAnalysis.tokenCount && <span>Tokens: {aiAnalysis.tokenCount.toLocaleString()}</span>}
                <span>Version: {aiAnalysis.versionNumber}</span>
              </div>

              {/* Current State */}
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-primary inline-block" />
                  Current Security Posture
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                  {aiAnalysis.currentState}
                </p>
              </div>

              {/* Immediate Actions */}
              {aiAnalysis.immediateActions.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-destructive mb-2 flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-destructive inline-block" />
                    Immediate Actions
                  </h3>
                  <ul className="space-y-2">
                    {aiAnalysis.immediateActions.map((action, i) => (
                      <li key={i} className="flex gap-2 text-sm">
                        <span className="shrink-0 font-semibold text-destructive">{i + 1}.</span>
                        <span className="text-muted-foreground">{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Medium Term Actions */}
              {aiAnalysis.mediumTermActions.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-amber-700 mb-2 flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-amber-500 inline-block" />
                    Medium Term Actions
                  </h3>
                  <ul className="space-y-2">
                    {aiAnalysis.mediumTermActions.map((action, i) => (
                      <li key={i} className="flex gap-2 text-sm">
                        <span className="shrink-0 font-semibold text-amber-700">{i + 1}.</span>
                        <span className="text-muted-foreground">{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Long Term Actions */}
              {aiAnalysis.longTermActions.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-emerald-700 mb-2 flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 inline-block" />
                    Long Term Actions
                  </h3>
                  <ul className="space-y-2">
                    {aiAnalysis.longTermActions.map((action, i) => (
                      <li key={i} className="flex gap-2 text-sm">
                        <span className="shrink-0 font-semibold text-emerald-700">{i + 1}.</span>
                        <span className="text-muted-foreground">{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Section 7: Detailed Responses ────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Responses</CardTitle>
          <CardDescription>All responses grouped by domain and category</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {Array.from(domainMap.entries()).map(([domain, catMap]) => {
            const isExpanded = expandedDomains.has(domain);
            return (
              <div key={domain} className="border rounded-lg overflow-hidden">
                <button
                  className="w-full flex items-center gap-2 px-4 py-3 bg-muted/30 hover:bg-muted/50 transition-colors text-left"
                  onClick={() =>
                    setExpandedDomains((prev) => {
                      const next = new Set(prev);
                      if (next.has(domain)) next.delete(domain);
                      else next.add(domain);
                      return next;
                    })
                  }
                >
                  {isExpanded ? (
                    <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  )}
                  <span className="font-semibold text-sm">{domain}</span>
                </button>

                {isExpanded && (
                  <div className="divide-y">
                    {Array.from(catMap.entries()).map(([category, catResponses]) => (
                      <div key={category}>
                        <p className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide bg-muted/10">
                          {category}
                        </p>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="pl-4 w-24">Code</TableHead>
                              <TableHead>Label / Description</TableHead>
                              <TableHead className="text-right w-24">Score</TableHead>
                              <TableHead className="w-48">Comment</TableHead>
                              <TableHead className="w-48">Evidence</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {catResponses.map((r) => (
                              <TableRow key={r.id}>
                                <TableCell className="pl-4">
                                  <code className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded">
                                    {r.templateItem.code}
                                  </code>
                                </TableCell>
                                <TableCell>
                                  <p className="text-sm font-medium">{r.templateItem.label}</p>
                                  {r.templateItem.description && (
                                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                                      {r.templateItem.description}
                                    </p>
                                  )}
                                </TableCell>
                                <TableCell className="text-right text-sm font-semibold">
                                  {r.score !== null ? (
                                    <span style={{ color: scoreColorClass((r.score / r.templateItem.scoring) * 100) }}>
                                      {r.score} / {r.templateItem.scoring}
                                    </span>
                                  ) : (
                                    <span className="text-muted-foreground">—</span>
                                  )}
                                </TableCell>
                                <TableCell className="text-xs text-muted-foreground max-w-[180px]">
                                  <p className="truncate">{r.comment || "—"}</p>
                                </TableCell>
                                <TableCell className="text-xs text-muted-foreground max-w-[180px]">
                                  <p className="truncate">{r.evidenceNote || "—"}</p>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
