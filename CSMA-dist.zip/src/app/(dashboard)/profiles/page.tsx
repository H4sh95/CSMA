"use client";

import { Suspense, useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import {
  Plus,
  Search,
  Eye,
  Pencil,
  Archive,
  ChevronLeft,
  ChevronRight,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useDebounce } from "@/hooks/use-debounce";
import { Role, ProfileStatus } from "@prisma/client";
import type { CustomerProfile } from "@/types";
import { formatDate } from "@/lib/utils";

type ProfileWithCount = CustomerProfile & {
  _count: { assessments: number };
};

type PaginatedProfiles = {
  data: ProfileWithCount[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

function ProfileStatusBadge({ status }: { status: ProfileStatus }) {
  const map: Record<ProfileStatus, { label: string; variant: "success" | "secondary" | "outline" | "default" }> = {
    ACTIVE: { label: "Active", variant: "success" },
    INACTIVE: { label: "Inactive", variant: "secondary" },
    ARCHIVED: { label: "Archived", variant: "outline" },
  };
  const { label, variant } = map[status] ?? { label: status, variant: "default" };
  return <Badge variant={variant}>{label}</Badge>;
}

function ProfilesContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { data: session } = useSession();
  const { toast } = useToast();

  const userRole = (session?.user as { role?: string })?.role;
  const canWrite = userRole === Role.ADMIN || userRole === Role.ASSESSOR;
  const canArchive = userRole === Role.ADMIN;

  const [searchInput, setSearchInput] = useState(searchParams.get("search") ?? "");
  const [statusFilter, setStatusFilter] = useState(searchParams.get("status") ?? "all");
  const [page, setPage] = useState(Number(searchParams.get("page") ?? "1"));
  const [data, setData] = useState<PaginatedProfiles | null>(null);
  const [loading, setLoading] = useState(true);
  const [archiveTarget, setArchiveTarget] = useState<ProfileWithCount | null>(null);
  const [archiving, setArchiving] = useState(false);

  const debouncedSearch = useDebounce(searchInput, 300);

  const fetchProfiles = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("page", String(page));
      params.set("pageSize", "20");
      if (debouncedSearch) params.set("search", debouncedSearch);
      if (statusFilter && statusFilter !== "all") params.set("status", statusFilter);

      const res = await fetch(`/api/profiles?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to load profiles");
      const json = await res.json();
      setData(json);
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to load profiles",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [page, debouncedSearch, statusFilter, toast]);

  useEffect(() => {
    fetchProfiles();
  }, [fetchProfiles]);

  // Sync URL params
  useEffect(() => {
    const params = new URLSearchParams();
    if (debouncedSearch) params.set("search", debouncedSearch);
    if (statusFilter && statusFilter !== "all") params.set("status", statusFilter);
    if (page > 1) params.set("page", String(page));
    const query = params.toString();
    router.replace(`/profiles${query ? `?${query}` : ""}`, { scroll: false });
  }, [debouncedSearch, statusFilter, page, router]);

  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, statusFilter]);

  async function handleArchive() {
    if (!archiveTarget) return;
    setArchiving(true);
    try {
      const res = await fetch(`/api/profiles/${archiveTarget.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: ProfileStatus.ARCHIVED }),
      });
      if (!res.ok) {
        const json = await res.json();
        throw new Error(json.error ?? "Archive failed");
      }
      toast({ title: "Profile archived", variant: "success" });
      setArchiveTarget(null);
      fetchProfiles();
    } catch (err) {
      toast({
        title: "Archive failed",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    } finally {
      setArchiving(false);
    }
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Customer Profiles</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage and view customer organisation profiles
          </p>
        </div>
        {canWrite && (
          <Button asChild>
            <Link href="/profiles/new">
              <Plus className="h-4 w-4" />
              New Profile
            </Link>
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search profiles..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="ACTIVE">Active</SelectItem>
            <SelectItem value="INACTIVE">Inactive</SelectItem>
            <SelectItem value="ARCHIVED">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        {loading ? (
          <CardContent className="p-6 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-12 bg-muted animate-pulse rounded" />
            ))}
          </CardContent>
        ) : !data || data.data.length === 0 ? (
          <CardContent className="py-20 text-center">
            <Users className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-base font-semibold text-foreground mb-1">No profiles found</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {debouncedSearch || (statusFilter && statusFilter !== "all")
                ? "Try adjusting your search or filter."
                : "Get started by creating your first customer profile."}
            </p>
            {canWrite && !debouncedSearch && (statusFilter === "all" || !statusFilter) && (
              <Button asChild size="sm">
                <Link href="/profiles/new">
                  <Plus className="h-4 w-4" />
                  Create your first profile
                </Link>
              </Button>
            )}
          </CardContent>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Identifier</TableHead>
                  <TableHead>Industry</TableHead>
                  <TableHead>Region / Country</TableHead>
                  <TableHead>Contact Email</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-center">Assessments</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.data.map((profile) => (
                  <TableRow key={profile.id}>
                    <TableCell className="font-medium">{profile.name}</TableCell>
                    <TableCell>
                      <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{profile.identifier}</code>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{profile.industry ?? "—"}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {[profile.region, profile.country].filter(Boolean).join(" / ") || "—"}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{profile.primaryEmail ?? "—"}</TableCell>
                    <TableCell>
                      <ProfileStatusBadge status={profile.status} />
                    </TableCell>
                    <TableCell className="text-center">{profile._count.assessments}</TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/profiles/${profile.id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">View</span>
                          </Link>
                        </Button>
                        {canWrite && (
                          <Button variant="ghost" size="sm" asChild>
                            <Link href={`/profiles/${profile.id}/edit`}>
                              <Pencil className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Link>
                          </Button>
                        )}
                        {canArchive && profile.status !== ProfileStatus.ARCHIVED && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setArchiveTarget(profile)}
                          >
                            <Archive className="h-4 w-4" />
                            <span className="sr-only">Archive</span>
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {/* Pagination */}
            {data.totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t">
                <p className="text-sm text-muted-foreground">
                  Showing {(page - 1) * 20 + 1}–{Math.min(page * 20, data.total)} of {data.total}
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Button>
                  <span className="text-sm">
                    {page} / {data.totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.min(data.totalPages, p + 1))}
                    disabled={page === data.totalPages}
                  >
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </Card>

      {/* Archive confirmation dialog */}
      <AlertDialog open={!!archiveTarget} onOpenChange={(open) => !open && setArchiveTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Archive profile?</AlertDialogTitle>
            <AlertDialogDescription>
              This will archive <strong>{archiveTarget?.name}</strong>. Archived profiles remain
              readable but no new assessments can be created against them. You can reactivate them
              later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={archiving}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleArchive}
              disabled={archiving}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {archiving ? "Archiving…" : "Archive"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}


export default function ProfilesPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>}>
      <ProfilesContent />
    </Suspense>
  );
}
