"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ProfileForm, type ProfileFormValues } from "@/components/profiles/profile-form";
import { useToast } from "@/hooks/use-toast";

export default function NewProfilePage() {
  const router = useRouter();
  const { toast } = useToast();

  async function handleSubmit(data: ProfileFormValues) {
    const res = await fetch("/api/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const json = await res.json();

    if (!res.ok) {
      toast({
        title: "Failed to create profile",
        description: json.error ?? "An unexpected error occurred",
        variant: "destructive",
      });
      // Re-throw so the form's isSubmitting clears correctly
      throw new Error(json.error ?? "Create failed");
    }

    toast({
      title: "Profile created",
      description: `${json.data.name} has been created successfully.`,
      variant: "success",
    });

    router.push(`/profiles/${json.data.id}`);
  }

  return (
    <div className="space-y-6 p-6 max-w-3xl">
      {/* Breadcrumb / back */}
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild className="-ml-2">
          <Link href="/profiles">
            <ChevronLeft className="h-4 w-4" />
            Back to profiles
          </Link>
        </Button>
      </div>

      {/* Page title */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">New Customer Profile</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Create a new customer organisation profile for use in assessments
        </p>
      </div>

      {/* Form card */}
      <Card>
        <CardHeader>
          <CardTitle>Profile details</CardTitle>
          <CardDescription>
            Fields marked with <span className="text-destructive">*</span> are required
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ProfileForm onSubmit={handleSubmit} />
        </CardContent>
      </Card>
    </div>
  );
}
