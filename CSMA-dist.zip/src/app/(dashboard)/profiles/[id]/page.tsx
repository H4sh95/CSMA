"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import {
  ChevronLeft,
  Pencil,
  Archive,
  Building2,
  Globe,
  Mail,
  User,
  FileText,
  ClipboardList,
  Users,
  CalendarDays,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Role, ProfileStatus } from "@prisma/client";
import { formatDate, formatScore } from "@/lib/utils";
import type { CustomerProfile } from "@/types";

type Assessor = { id: string; name: string; email: string };

type ProfileDetail = CustomerProfile & {
  _count: { assessments: number };
  assessorAssignments: Array<{ assessor: Assessor }>;
  createdBy: Assessor | null;
};

type AssessmentRow = {
  id: string;
  title: string;
  status: string;
  overallScore: number | null;
  createdAt: string;
  updatedAt: string;
};

type CustomerUser = {
  id: string;
  name: string;
  email: string;
};

function ProfileStatusBadge({ status }: { status: ProfileStatus }) {
  const map: Record<ProfileStatus, { label: string; variant: "success" | "secondary" | "outline" }> = {
    ACTIVE: { label: "Active", variant: "success" },
    INACTIVE: { label: "Inactive", variant: "secondary" },
    ARCHIVED: { label: "Archived", variant: "outline" },
  };
  const { label, variant } = map[status];
  return <Badge variant={variant}>{label}</Badge>;
}

function AssessmentStatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; variant: "default" | "secondary" | "outline" | "success" | "warning" }> = {
    DRAFT: { label: "Draft", variant: "secondary" },
    IN_PROGRESS: { label: "In Progress", variant: "warning" },
    COMPLETED: { label: "Completed", variant: "success" },
    ARCHIVED: { label: "Archived", variant: "outline" },
  };
  const { label, variant } = map[status] ?? { label: status, variant: "default" };
  return <Badge variant={variant}>{label}</Badge>;
}

function DetailRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | null | undefined }) {
  return (
    <div className="flex items-start gap-3 py-2.5">
      <div className="mt-0.5 text-muted-foreground shrink-0">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium text-foreground truncate">{value || "—"}</p>
      </div>
    </div>
  );
}

export default function ProfileDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { data: session } = useSession();
  const { toast } = useToast();

  const userRole = (session?.user as { role?: string })?.role;
  const canWrite = userRole === Role.ADMIN || userRole === Role.ASSESSOR;
  const canArchive = userRole === Role.ADMIN;
  const isAdmin = userRole === Role.ADMIN;

  const [profile, setProfile] = useState<ProfileDetail | null>(null);
  const [assessments, setAssessments] = useState<AssessmentRow[]>([]);
  const [customerUsers, setCustomerUsers] = useState<CustomerUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [assessmentsLoading, setAssessmentsLoading] = useState(false);
  const [usersLoading, setUsersLoading] = useState(false);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [archiving, setArchiving] = useState(false);
  const [activeTab, setActiveTab] = useState("assessments");

  useEffect(() => {
    async function fetchProfile() {
      try {
        const res = await fetch(`/api/profiles/${params.id}`);
        if (!res.ok) {
          if (res.status === 404) {
            router.push("/profiles");
            return;
          }
          throw new Error("Failed to load profile");
        }
        const json = await res.json();
        setProfile(json.data);
      } catch (err) {
        toast({
          title: "Error",
          description: err instanceof Error ? err.message : "Failed to load profile",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    }
    fetchProfile();
  }, [params.id, router, toast]);

  // Fetch assessments for this profile
  useEffect(() => {
    async function fetchAssessments() {
      setAssessmentsLoading(true);
      try {
        const res = await fetch(`/api/assessments?profileId=${params.id}&pageSize=50`);
        if (res.ok) {
          const json = await res.json();
          setAssessments(json.data ?? []);
        }
      } catch {
        // non-fatal
      } finally {
        setAssessmentsLoading(false);
      }
    }
    fetchAssessments();
  }, [params.id]);

  // Fetch customer users (admin only, on tab switch)
  useEffect(() => {
    if (activeTab !== "access" || !isAdmin) return;
    async function fetchUsers() {
      setUsersLoading(true);
      try {
        const res = await fetch(`/api/admin/users?role=CUSTOMER&profileId=${params.id}&pageSize=100`);
        if (res.ok) {
          const json = await res.json();
          setCustomerUsers(json.data ?? []);
        }
      } catch {
        // non-fatal
      } finally {
        setUsersLoading(false);
      }
    }
    fetchUsers();
  }, [activeTab, isAdmin, params.id]);

  async function handleArchive() {
    if (!profile) return;
    setArchiving(true);
    try {
      const res = await fetch(`/api/profiles/${profile.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: ProfileStatus.ARCHIVED }),
      });
      if (!res.ok) {
        const json = await res.json();
        throw new Error(json.error ?? "Archive failed");
      }
      const json = await res.json();
      setProfile(json.data);
      setArchiveOpen(false);
      toast({ title: "Profile archived", variant: "success" });
    } catch (err) {
      toast({
        title: "Archive failed",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    } finally {
      setArchiving(false);
    }
  }

  // Derive stats
  const completedAssessments = assessments.filter((a) => a.status === "COMPLETED");
  const lastAssessmentDate =
    assessments.length > 0 ? assessments[0].createdAt : null;
  const avgScore =
    completedAssessments.length > 0
      ? completedAssessments.reduce((sum, a) => sum + (a.overallScore ?? 0), 0) /
        completedAssessments.length
      : null;

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <div className="h-6 w-40 bg-muted animate-pulse rounded" />
        <div className="flex items-center justify-between">
          <div className="h-8 w-64 bg-muted animate-pulse rounded" />
          <div className="flex gap-2">
            <div className="h-10 w-24 bg-muted animate-pulse rounded" />
            <div className="h-10 w-24 bg-muted animate-pulse rounded" />
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="h-64 bg-muted animate-pulse rounded-lg" />
          <div className="h-64 bg-muted animate-pulse rounded-lg" />
        </div>
      </div>
    );
  }

  if (!profile) return null;

  return (
    <div className="space-y-6 p-6">
      {/* Back button */}
      <Button variant="ghost" size="sm" asChild className="-ml-2">
        <Link href="/profiles">
          <ChevronLeft className="h-4 w-4" />
          Back to profiles
        </Link>
      </Button>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-bold text-foreground">{profile.name}</h1>
              <ProfileStatusBadge status={profile.status} />
            </div>
            <p className="text-sm text-muted-foreground mt-0.5">
              <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{profile.identifier}</code>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {canWrite && (
            <Button variant="outline" size="sm" asChild>
              <Link href={`/profiles/${profile.id}/edit`}>
                <Pencil className="h-4 w-4" />
                Edit
              </Link>
            </Button>
          )}
          {canArchive && profile.status !== ProfileStatus.ARCHIVED && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setArchiveOpen(true)}
              className="text-destructive border-destructive/30 hover:bg-destructive/10"
            >
              <Archive className="h-4 w-4" />
              Archive
            </Button>
          )}
        </div>
      </div>

      {/* Two-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Profile details */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Profile Details</CardTitle>
            </CardHeader>
            <CardContent className="divide-y">
              <DetailRow
                icon={<Building2 className="h-4 w-4" />}
                label="Industry"
                value={profile.industry}
              />
              <DetailRow
                icon={<Globe className="h-4 w-4" />}
                label="Region"
                value={profile.region}
              />
              <DetailRow
                icon={<Globe className="h-4 w-4" />}
                label="Country"
                value={profile.country}
              />
              <DetailRow
                icon={<User className="h-4 w-4" />}
                label="Primary Contact"
                value={profile.primaryContact}
              />
              <DetailRow
                icon={<Mail className="h-4 w-4" />}
                label="Contact Email"
                value={profile.primaryEmail}
              />
              {profile.notes && (
                <>
                  <Separator />
                  <div className="py-2.5 flex items-start gap-3">
                    <FileText className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Notes</p>
                      <p className="text-sm whitespace-pre-wrap">{profile.notes}</p>
                    </div>
                  </div>
                </>
              )}
              <DetailRow
                icon={<CalendarDays className="h-4 w-4" />}
                label="Created"
                value={formatDate(profile.createdAt)}
              />
              {profile.createdBy && (
                <DetailRow
                  icon={<User className="h-4 w-4" />}
                  label="Created by"
                  value={`${profile.createdBy.name} (${profile.createdBy.email})`}
                />
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: Assessors + quick stats */}
        <div className="space-y-4">
          {/* Assigned Assessors */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Assigned Assessors</CardTitle>
            </CardHeader>
            <CardContent>
              {profile.assessorAssignments.length === 0 ? (
                <p className="text-sm text-muted-foreground">No assessors assigned yet.</p>
              ) : (
                <ul className="space-y-2">
                  {profile.assessorAssignments.map(({ assessor }) => (
                    <li key={assessor.id} className="flex items-center gap-2">
                      <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary">
                        {assessor.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{assessor.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{assessor.email}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>

          {/* Quick stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <ClipboardList className="h-4 w-4" />
                  <span className="text-sm">Total Assessments</span>
                </div>
                <span className="text-sm font-semibold">{profile._count.assessments}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <CalendarDays className="h-4 w-4" />
                  <span className="text-sm">Last Assessment</span>
                </div>
                <span className="text-sm font-semibold">
                  {lastAssessmentDate ? formatDate(lastAssessmentDate) : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-sm">Average Score</span>
                </div>
                <span className="text-sm font-semibold">{formatScore(avgScore)}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ── Tabs ─────────────────────────────────────────────────────────── */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="assessments">
            <ClipboardList className="h-4 w-4 mr-1.5" />
            Assessments ({assessments.length})
          </TabsTrigger>
          {isAdmin && (
            <TabsTrigger value="access">
              <Users className="h-4 w-4 mr-1.5" />
              Access
            </TabsTrigger>
          )}
        </TabsList>

        {/* Assessments tab */}
        <TabsContent value="assessments">
          <Card>
            <CardContent className="p-0">
              {assessmentsLoading ? (
                <div className="p-6 space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-10 bg-muted animate-pulse rounded" />
                  ))}
                </div>
              ) : assessments.length === 0 ? (
                <div className="py-16 text-center text-sm text-muted-foreground">
                  <ClipboardList className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p>No assessments for this profile yet.</p>
                  {canWrite && (
                    <Button asChild size="sm" className="mt-3">
                      <Link href={`/assessments/new?profileId=${profile.id}`}>
                        Create assessment
                      </Link>
                    </Button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/40">
                        <th className="h-10 px-4 text-left font-medium text-muted-foreground">Title</th>
                        <th className="h-10 px-4 text-left font-medium text-muted-foreground">Status</th>
                        <th className="h-10 px-4 text-right font-medium text-muted-foreground">Score</th>
                        <th className="h-10 px-4 text-right font-medium text-muted-foreground">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {assessments.map((a) => (
                        <tr key={a.id} className="border-b last:border-0 hover:bg-muted/30">
                          <td className="px-4 py-3 font-medium">
                            <Link
                              href={a.status === "COMPLETED" ? `/results/${a.id}` : `/assessments/${a.id}`}
                              className="hover:underline"
                            >
                              {a.title}
                            </Link>
                          </td>
                          <td className="px-4 py-3">
                            <AssessmentStatusBadge status={a.status} />
                          </td>
                          <td className="px-4 py-3 text-right">
                            {a.overallScore !== null ? formatScore(a.overallScore) : "—"}
                          </td>
                          <td className="px-4 py-3 text-right text-muted-foreground">
                            {formatDate(a.createdAt)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Access tab (admin only) */}
        {isAdmin && (
          <TabsContent value="access">
            <Card>
              <CardContent className="p-6">
                {usersLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="h-10 bg-muted animate-pulse rounded" />
                    ))}
                  </div>
                ) : customerUsers.length === 0 ? (
                  <div className="py-8 text-center text-sm text-muted-foreground">
                    <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
                    <p>No customer users linked to this profile.</p>
                  </div>
                ) : (
                  <ul className="divide-y">
                    {customerUsers.map((u) => (
                      <li key={u.id} className="py-3 flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center text-sm font-semibold">
                          {u.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{u.name}</p>
                          <p className="text-xs text-muted-foreground">{u.email}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>

      {/* Archive dialog */}
      <AlertDialog open={archiveOpen} onOpenChange={setArchiveOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Archive this profile?</AlertDialogTitle>
            <AlertDialogDescription>
              Archiving <strong>{profile.name}</strong> will prevent new assessments from being
              created against it. Existing data is preserved. You can reactivate it later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={archiving}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleArchive}
              disabled={archiving}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {archiving ? "Archiving…" : "Archive"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
