"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ProfileForm, type ProfileFormValues } from "@/components/profiles/profile-form";
import { useToast } from "@/hooks/use-toast";
import { ProfileStatus } from "@prisma/client";
import type { CustomerProfile } from "@/types";

function profileToFormValues(p: CustomerProfile): Partial<ProfileFormValues> {
  return {
    name: p.name,
    identifier: p.identifier,
    industry: p.industry ?? "",
    region: p.region ?? "",
    country: p.country ?? "",
    primaryContact: p.primaryContact ?? "",
    primaryEmail: p.primaryEmail ?? "",
    notes: p.notes ?? "",
    status: p.status,
  };
}

export default function EditProfilePage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { toast } = useToast();

  const [profile, setProfile] = useState<CustomerProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProfile() {
      try {
        const res = await fetch(`/api/profiles/${params.id}`);
        if (!res.ok) {
          if (res.status === 404) {
            router.push("/profiles");
            return;
          }
          throw new Error("Failed to load profile");
        }
        const json = await res.json();
        setProfile(json.data);
      } catch (err) {
        toast({
          title: "Error",
          description: err instanceof Error ? err.message : "Failed to load profile",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    }
    fetchProfile();
  }, [params.id, router, toast]);

  async function handleSubmit(data: ProfileFormValues) {
    const res = await fetch(`/api/profiles/${params.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const json = await res.json();

    if (!res.ok) {
      toast({
        title: "Failed to update profile",
        description: json.error ?? "An unexpected error occurred",
        variant: "destructive",
      });
      throw new Error(json.error ?? "Update failed");
    }

    toast({
      title: "Profile updated",
      description: `${json.data.name} has been updated successfully.`,
      variant: "success",
    });

    router.push(`/profiles/${params.id}`);
  }

  if (loading) {
    return (
      <div className="space-y-6 p-6 max-w-3xl">
        <div className="h-6 w-36 bg-muted animate-pulse rounded" />
        <div className="h-8 w-64 bg-muted animate-pulse rounded" />
        <div className="h-[480px] bg-muted animate-pulse rounded-lg" />
      </div>
    );
  }

  if (!profile) return null;

  return (
    <div className="space-y-6 p-6 max-w-3xl">
      {/* Back */}
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild className="-ml-2">
          <Link href={`/profiles/${params.id}`}>
            <ChevronLeft className="h-4 w-4" />
            Back to profile
          </Link>
        </Button>
      </div>

      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Edit Profile</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Update details for <span className="font-medium">{profile.name}</span>
        </p>
      </div>

      {/* Form card */}
      <Card>
        <CardHeader>
          <CardTitle>Profile details</CardTitle>
          <CardDescription>
            Fields marked with <span className="text-destructive">*</span> are required
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ProfileForm
            defaultValues={profileToFormValues(profile)}
            onSubmit={handleSubmit}
          />
        </CardContent>
      </Card>
    </div>
  );
}
