"use client";

import { useEffect, useReducer, useRef, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { Save, Send, CheckCircle2, Circle, ChevronDown, ChevronRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { AlertTriangle } from "lucide-react";
import type { AssessmentWithRelations } from "@/types";

// ─── Response state types ─────────────────────────────────────────────────────

interface ResponseEntry {
  score: number | null;
  comment: string;
  evidenceNote: string;
  isAnswered: boolean;
}

type ResponseMap = Map<string, ResponseEntry>;

type ResponseAction =
  | { type: "INIT"; map: ResponseMap }
  | { type: "SET_SCORE"; itemId: string; score: number | null }
  | { type: "SET_COMMENT"; itemId: string; comment: string }
  | { type: "SET_EVIDENCE"; itemId: string; evidenceNote: string };

function responseReducer(state: ResponseMap, action: ResponseAction): ResponseMap {
  const next = new Map(state);
  switch (action.type) {
    case "INIT":
      return action.map;
    case "SET_SCORE": {
      const current = next.get(action.itemId) ?? { score: null, comment: "", evidenceNote: "", isAnswered: false };
      next.set(action.itemId, {
        ...current,
        score: action.score,
        isAnswered: action.score !== null,
      });
      return next;
    }
    case "SET_COMMENT": {
      const current = next.get(action.itemId) ?? { score: null, comment: "", evidenceNote: "", isAnswered: false };
      next.set(action.itemId, { ...current, comment: action.comment });
      return next;
    }
    case "SET_EVIDENCE": {
      const current = next.get(action.itemId) ?? { score: null, comment: "", evidenceNote: "", isAnswered: false };
      next.set(action.itemId, { ...current, evidenceNote: action.evidenceNote });
      return next;
    }
    default:
      return state;
  }
}

// ─── Auto-save status ─────────────────────────────────────────────────────────

type SaveStatus = "idle" | "unsaved" | "saving" | "saved";

// ─── Domain/category tree structure ──────────────────────────────────────────

interface CategoryGroup {
  category: string;
  items: AssessmentWithRelations["template"]["items"];
}

interface DomainGroup {
  domain: string;
  categories: CategoryGroup[];
}

function buildTree(items: AssessmentWithRelations["template"]["items"]): DomainGroup[] {
  const domainMap = new Map<string, Map<string, AssessmentWithRelations["template"]["items"]>>();
  for (const item of items) {
    if (!domainMap.has(item.domain)) domainMap.set(item.domain, new Map());
    const catMap = domainMap.get(item.domain)!;
    if (!catMap.has(item.category)) catMap.set(item.category, []);
    catMap.get(item.category)!.push(item);
  }

  const tree: DomainGroup[] = [];
  for (const [domain, catMap] of domainMap.entries()) {
    const categories: CategoryGroup[] = [];
    for (const [category, catItems] of catMap.entries()) {
      categories.push({ category, items: catItems });
    }
    tree.push({ domain, categories });
  }
  return tree;
}

// ─── Score radio component ────────────────────────────────────────────────────

function ScoreInput({
  maxScoring,
  value,
  onChange,
  disabled,
}: {
  maxScoring: number;
  value: number | null;
  onChange: (v: number | null) => void;
  disabled?: boolean;
}) {
  const useButtons = Number.isInteger(maxScoring) && maxScoring <= 5;

  if (useButtons) {
    const options = Array.from({ length: maxScoring + 1 }, (_, i) => i);
    return (
      // role="radiogroup" gives screen-readers the correct semantics without
      // a hidden <input type="radio"> that causes the browser to scroll to
      // position (0, 0) of the scroll container when focused via its label.
      <div className="flex flex-wrap gap-2" role="radiogroup">
        {options.map((opt) => (
          <button
            key={opt}
            type="button"
            role="radio"
            aria-checked={value === opt}
            onClick={() => !disabled && onChange(opt)}
            disabled={disabled}
            className={cn(
              "flex items-center justify-center w-9 h-9 rounded-full border text-sm font-medium cursor-pointer transition-colors select-none",
              value === opt
                ? "bg-primary text-primary-foreground border-primary"
                : "border-input bg-background hover:bg-muted",
              disabled && "opacity-50 cursor-not-allowed"
            )}
          >
            {opt}
          </button>
        ))}
        {value !== null && (
          <button
            type="button"
            onClick={() => !disabled && onChange(null)}
            disabled={disabled}
            className="text-xs text-muted-foreground underline ml-1 self-center"
          >
            Clear
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <input
        type="number"
        min={0}
        max={maxScoring}
        step={maxScoring <= 1 ? 0.1 : 1}
        value={value ?? ""}
        onChange={(e) => {
          const v = e.target.value;
          if (v === "") { onChange(null); return; }
          const num = parseFloat(v);
          if (!isNaN(num) && num >= 0 && num <= maxScoring) onChange(num);
        }}
        disabled={disabled}
        placeholder="0"
        className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:opacity-50"
      />
      <span className="text-sm text-muted-foreground">/ {maxScoring}</span>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ConductAssessmentPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const router = useRouter();
  const { toast } = useToast();

  const [assessment, setAssessment] = useState<AssessmentWithRelations | null>(null);
  const [loading, setLoading] = useState(true);
  const [responses, dispatch] = useReducer(responseReducer, new Map<string, ResponseEntry>());
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [expandedDomains, setExpandedDomains] = useState<Set<string>>(new Set());

  // Track which items have changed since last save
  const pendingChanges = useRef<Set<string>>(new Set());
  const autoSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const domainRefs = useRef<Map<string, HTMLElement>>(new Map());

  // ── Fetch assessment ────────────────────────────────────────────────────────
  useEffect(() => {
    if (!id) return;
    fetch(`/api/assessments/${id}`)
      .then((r) => r.json())
      .then((json) => {
        if (json.error) throw new Error(json.error);
        const a: AssessmentWithRelations = json.data;

        if (a.status === "COMPLETED" || a.status === "ARCHIVED") {
          toast({ title: "Assessment closed", description: "This assessment can no longer be edited.", variant: "destructive" });
          router.push(a.status === "COMPLETED" ? `/results/${id}` : `/assessments/${id}`);
          return;
        }

        setAssessment(a);

        // Build initial response map from fetched data
        const initMap = new Map<string, ResponseEntry>();
        for (const r of a.responses) {
          initMap.set(r.templateItemId, {
            score: r.score ?? null,
            comment: r.comment ?? "",
            evidenceNote: r.evidenceNote ?? "",
            isAnswered: r.isAnswered,
          });
        }
        dispatch({ type: "INIT", map: initMap });

        // Expand all domains initially
        const domains = new Set(a.template.items.map((i) => i.domain));
        setExpandedDomains(domains);
      })
      .catch((err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
        router.push("/assessments");
      })
      .finally(() => setLoading(false));
  }, [id, router, toast]);

  // ── Save responses ──────────────────────────────────────────────────────────
  const saveResponses = useCallback(
    async (itemIds: string[]) => {
      if (!assessment || itemIds.length === 0) return;
      setSaveStatus("saving");
      try {
        const payload = itemIds.map((itemId) => {
          const r = responses.get(itemId) ?? { score: null, comment: "", evidenceNote: "", isAnswered: false };
          return {
            templateItemId: itemId,
            score: r.score,
            comment: r.comment || null,
            evidenceNote: r.evidenceNote || null,
            isAnswered: r.isAnswered,
          };
        });

        const res = await fetch(`/api/assessments/${id}/responses`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ responses: payload }),
        });

        if (!res.ok) {
          const json = await res.json();
          throw new Error(json.error ?? "Save failed");
        }

        pendingChanges.current.clear();
        setSaveStatus("saved");

        // Reset to idle after 3s
        setTimeout(() => setSaveStatus((s) => (s === "saved" ? "idle" : s)), 3000);
      } catch (err) {
        setSaveStatus("unsaved");
        toast({ title: "Auto-save failed", description: err instanceof Error ? err.message : "Could not save responses", variant: "destructive" });
      }
    },
    [assessment, id, responses, toast]
  );

  // ── Debounced auto-save ─────────────────────────────────────────────────────
  function scheduleAutoSave(itemId: string) {
    pendingChanges.current.add(itemId);
    setSaveStatus("unsaved");

    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    autoSaveTimer.current = setTimeout(() => {
      const ids = Array.from(pendingChanges.current);
      saveResponses(ids);
    }, 3000);
  }

  function handleManualSave() {
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    const ids = Array.from(pendingChanges.current);
    if (ids.length === 0) {
      toast({ title: "No unsaved changes", description: "All responses are already saved." });
      return;
    }
    saveResponses(ids);
  }

  // ── Submit assessment ───────────────────────────────────────────────────────
  async function handleSubmit() {
    setSubmitting(true);
    try {
      // Save any pending changes first
      if (pendingChanges.current.size > 0) {
        await saveResponses(Array.from(pendingChanges.current));
      }

      const res = await fetch(`/api/assessments/${id}/submit`, { method: "POST" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Submit failed");

      toast({ title: "Assessment submitted", description: "Your assessment has been completed.", variant: "success" });
      router.push(`/results/${id}`);
    } catch (err) {
      toast({ title: "Submit failed", description: err instanceof Error ? err.message : "Could not submit assessment", variant: "destructive" });
      setSubmitting(false);
    }
  }

  if (loading || !assessment) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Excluded domains are stored on the assessment; filter template items accordingly
  const excludedDomains: string[] = (assessment as AssessmentWithRelations & { excludedDomains: string[] }).excludedDomains ?? [];
  const activeItems = excludedDomains.length > 0
    ? assessment.template.items.filter((i) => !excludedDomains.includes(i.domain))
    : assessment.template.items;

  const totalItems = activeItems.length;
  const answeredCount = Array.from(responses.values()).filter((r) => r.isAnswered).length;
  const completionPct = totalItems > 0 ? (answeredCount / totalItems) * 100 : 0;
  const unansweredCount = totalItems - answeredCount;
  const tree = buildTree(activeItems);

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-background">
      {/* ── Fixed top bar ───────────────────────────────────────────────────── */}
      <header className="flex items-center gap-4 border-b bg-background/95 backdrop-blur px-4 py-3 shrink-0 z-20">
        <div className="flex-1 min-w-0">
          <h1 className="text-sm font-semibold truncate">{assessment.title}</h1>
          <p className="text-xs text-muted-foreground truncate">{assessment.profile.name}</p>
        </div>

        {/* Completion progress */}
        <div className="hidden sm:flex items-center gap-2 shrink-0">
          <Progress value={completionPct} className="w-28 h-1.5" />
          <span className="text-xs text-muted-foreground font-medium whitespace-nowrap">
            {answeredCount}/{totalItems} ({Math.round(completionPct)}%)
          </span>
        </div>

        {/* Save status */}
        <div className="shrink-0">
          {saveStatus === "saving" && (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Loader2 className="h-3 w-3 animate-spin" /> Saving...
            </span>
          )}
          {saveStatus === "saved" && (
            <span className="text-xs text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" /> Saved
            </span>
          )}
          {saveStatus === "unsaved" && (
            <span className="text-xs text-amber-600">Unsaved changes</span>
          )}
        </div>

        <Button variant="outline" size="sm" onClick={handleManualSave} disabled={submitting}>
          <Save className="h-4 w-4" />
          <span className="hidden sm:inline ml-1">Save</span>
        </Button>

        <Button size="sm" onClick={() => setShowSubmitDialog(true)} disabled={submitting}>
          <Send className="h-4 w-4" />
          <span className="hidden sm:inline ml-1">Submit</span>
        </Button>
      </header>

      {/* ── Main layout ─────────────────────────────────────────────────────── */}
      <div className="flex flex-1 overflow-hidden">
        {/* ── Left sidebar: navigation tree ─────────────────────────────────── */}
        <aside className="hidden lg:flex flex-col w-64 border-r bg-muted/20 shrink-0 overflow-y-auto">
          <div className="p-4 border-b">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Navigation</p>
          </div>
          <nav className="flex-1 p-2 space-y-0.5">
            {tree.map(({ domain, categories }) => {
              const domainItems = categories.flatMap((c) => c.items);
              const domainAnswered = domainItems.filter((item) => responses.get(item.id)?.isAnswered).length;
              const domainPct = domainItems.length > 0 ? Math.round((domainAnswered / domainItems.length) * 100) : 0;
              const isExpanded = expandedDomains.has(domain);

              return (
                <div key={domain}>
                  <button
                    className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-left hover:bg-muted/50 transition-colors"
                    onClick={() => {
                      setExpandedDomains((prev) => {
                        const next = new Set(prev);
                        if (next.has(domain)) next.delete(domain);
                        else next.add(domain);
                        return next;
                      });
                      // Scroll to domain section
                      const el = domainRefs.current.get(domain);
                      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
                    }}
                  >
                    {isExpanded ? (
                      <ChevronDown className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    ) : (
                      <ChevronRight className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    )}
                    <span className="text-xs font-medium truncate flex-1">{domain}</span>
                    <span className={cn("text-xs font-semibold shrink-0", domainPct === 100 ? "text-emerald-600" : "text-muted-foreground")}>
                      {domainPct}%
                    </span>
                  </button>

                  {isExpanded && (
                    <div className="ml-4 mt-0.5 space-y-0.5">
                      {categories.map(({ category, items: catItems }) => {
                        const catAnswered = catItems.filter((item) => responses.get(item.id)?.isAnswered).length;
                        return (
                          <button
                            key={category}
                            className="w-full flex items-center gap-1.5 px-2 py-1 rounded text-left hover:bg-muted/50 transition-colors"
                            onClick={() => {
                              const el = domainRefs.current.get(`${domain}__${category}`);
                              if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
                            }}
                          >
                            <span className="text-xs text-muted-foreground truncate flex-1">{category}</span>
                            <span className="text-xs text-muted-foreground shrink-0">
                              {catAnswered}/{catItems.length}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </aside>

        {/* ── Main content area ───────────────────────────────────────────────── */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6">
          {/* Excluded-domain notice */}
          {excludedDomains.length > 0 && (
            <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-amber-800">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold">
                  {excludedDomains.length} domain{excludedDomains.length !== 1 ? "s" : ""} excluded from this assessment
                </p>
                <p className="mt-0.5 text-amber-700">
                  The following domain{excludedDomains.length !== 1 ? "s are" : " is"} not assessed and{" "}
                  {excludedDomains.length !== 1 ? "do" : "does"} not count towards the score:{" "}
                  <strong>{excludedDomains.join(", ")}</strong>
                </p>
              </div>
            </div>
          )}

          {tree.map(({ domain, categories }) => (
            <section
              key={domain}
              ref={(el) => { if (el) domainRefs.current.set(domain, el); }}
              className="space-y-4"
            >
              {/* Domain header */}
              <div className="flex items-center gap-3 pb-2 border-b">
                <h2 className="text-lg font-semibold">{domain}</h2>
                <Badge variant="outline" className="text-xs">
                  {categories.reduce((acc, c) => acc + c.items.length, 0)} items
                </Badge>
              </div>

              {/* Categories */}
              {categories.map(({ category, items: catItems }) => (
                <div
                  key={category}
                  ref={(el) => { if (el) domainRefs.current.set(`${domain}__${category}`, el); }}
                  className="space-y-3"
                >
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide pl-1">
                    {category}
                  </h3>

                  {/* Items */}
                  {catItems.map((item) => {
                    const resp = responses.get(item.id) ?? { score: null, comment: "", evidenceNote: "", isAnswered: false };

                    return (
                      <div
                        key={item.id}
                        className={cn(
                          "rounded-lg border bg-card p-4 space-y-3 transition-colors",
                          resp.isAnswered ? "border-emerald-200 bg-emerald-50/30" : "border-border"
                        )}
                      >
                        {/* Item header */}
                        <div className="flex items-start gap-3">
                          <div className="shrink-0 mt-0.5">
                            {resp.isAnswered ? (
                              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                            ) : (
                              <Circle className="h-4 w-4 text-muted-foreground/40" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <code className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded shrink-0">
                                {item.code}
                              </code>
                              <span className="text-sm font-medium">{item.label}</span>
                            </div>
                            {item.description && (
                              <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                                {item.description}
                              </p>
                            )}
                            <p className="text-xs text-muted-foreground mt-1">
                              Max score: <strong>{item.scoring}</strong>
                            </p>
                          </div>
                        </div>

                        {/* Score input */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-medium text-muted-foreground">Score</label>
                          <ScoreInput
                            maxScoring={item.scoring}
                            value={resp.score}
                            onChange={(v) => {
                              dispatch({ type: "SET_SCORE", itemId: item.id, score: v });
                              scheduleAutoSave(item.id);
                            }}
                          />
                        </div>

                        {/* Comment */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-medium text-muted-foreground">
                            Comment <span className="text-muted-foreground/60">(optional)</span>
                          </label>
                          <Textarea
                            placeholder="Add a comment..."
                            value={resp.comment}
                            onChange={(e) => {
                              dispatch({ type: "SET_COMMENT", itemId: item.id, comment: e.target.value });
                              scheduleAutoSave(item.id);
                            }}
                            rows={2}
                            className="text-sm min-h-0"
                          />
                        </div>

                        {/* Evidence note */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-medium text-muted-foreground">
                            Evidence Note <span className="text-muted-foreground/60">(optional)</span>
                          </label>
                          <Textarea
                            placeholder="Reference to evidence (e.g. document name, ticket number)..."
                            value={resp.evidenceNote}
                            onChange={(e) => {
                              dispatch({ type: "SET_EVIDENCE", itemId: item.id, evidenceNote: e.target.value });
                              scheduleAutoSave(item.id);
                            }}
                            rows={2}
                            className="text-sm min-h-0"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </section>
          ))}
        </main>
      </div>

      {/* ── Submit confirmation dialog ─────────────────────────────────────── */}
      <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Submit Assessment?</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2">
                <p>
                  You are about to finalise and submit <strong>&quot;{assessment.title}&quot;</strong>.
                  This action cannot be undone.
                </p>
                {unansweredCount > 0 && (
                  <div className="rounded-md bg-amber-50 border border-amber-200 p-3 text-amber-800 text-sm">
                    <strong>Warning:</strong> {unansweredCount} item{unansweredCount !== 1 ? "s are" : " is"} still
                    unanswered and will be counted as 0.
                  </div>
                )}
                <p className="text-sm">
                  {answeredCount} of {totalItems} items answered ({Math.round(completionPct)}% complete).
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={submitting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSubmit} disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Assessment"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
