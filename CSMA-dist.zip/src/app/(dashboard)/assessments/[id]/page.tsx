"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, PlayCircle, BarChart2, CheckCircle2, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatDateTime, formatScore } from "@/lib/utils";
import type { AssessmentWithRelations } from "@/types";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function statusVariant(status: string): "secondary" | "warning" | "success" | "outline" | "default" {
  switch (status) {
    case "DRAFT": return "secondary";
    case "IN_PROGRESS": return "warning";
    case "COMPLETED": return "success";
    case "ARCHIVED": return "outline";
    default: return "default";
  }
}

function statusLabel(status: string): string {
  switch (status) {
    case "DRAFT": return "Draft";
    case "IN_PROGRESS": return "In Progress";
    case "COMPLETED": return "Completed";
    case "ARCHIVED": return "Archived";
    default: return status;
  }
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function AssessmentDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const router = useRouter();
  const { toast } = useToast();

  const [assessment, setAssessment] = useState<AssessmentWithRelations | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    fetch(`/api/assessments/${id}`)
      .then((r) => r.json())
      .then((json) => {
        if (json.error) throw new Error(json.error);
        setAssessment(json.data);
      })
      .catch((err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
        router.push("/assessments");
      })
      .finally(() => setLoading(false));
  }, [id, router, toast]);

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <div className="h-8 w-64 bg-muted animate-pulse rounded" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-32 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
        <div className="h-64 bg-muted animate-pulse rounded-lg" />
      </div>
    );
  }

  if (!assessment) return null;

  const totalItems = assessment.template.items.length;
  const answeredCount = assessment.responses.filter((r) => r.isAnswered).length;
  const completionPct = totalItems > 0 ? (answeredCount / totalItems) * 100 : 0;

  const canContinue = assessment.status === "DRAFT" || assessment.status === "IN_PROGRESS";
  const isCompleted = assessment.status === "COMPLETED";

  // Group domain progress
  const domainMap = new Map<string, { total: number; answered: number }>();
  for (const item of assessment.template.items) {
    if (!domainMap.has(item.domain)) domainMap.set(item.domain, { total: 0, answered: 0 });
    const d = domainMap.get(item.domain)!;
    d.total++;
  }
  for (const response of assessment.responses) {
    if (response.isAnswered) {
      const domain = response.templateItem.domain;
      const d = domainMap.get(domain);
      if (d) d.answered++;
    }
  }

  // Get domain scores
  const domainScoreMap = new Map<string, { percentage: number }>();
  for (const ds of assessment.domainScores) {
    domainScoreMap.set(ds.domain, { percentage: ds.percentage });
  }

  // Recent responses (last 10 answered)
  const recentResponses = assessment.responses
    .filter((r) => r.isAnswered)
    .slice(-10)
    .reverse();

  return (
    <div className="space-y-6 p-6">
      {/* Back navigation */}
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/assessments">
            <ArrowLeft className="h-4 w-4" />
            Back to Assessments
          </Link>
        </Button>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold text-foreground">{assessment.title}</h1>
            <Badge variant={statusVariant(assessment.status)}>
              {statusLabel(assessment.status)}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            {assessment.profile.name} &middot; {assessment.template.name} v{assessment.template.version}
          </p>
        </div>
        <div className="flex gap-2 shrink-0">
          {canContinue && (
            <Button asChild>
              <Link href={`/assessments/${id}/conduct`}>
                <PlayCircle className="h-4 w-4" />
                Continue Assessment
              </Link>
            </Button>
          )}
          {isCompleted && (
            <Button asChild>
              <Link href={`/results/${id}`}>
                <BarChart2 className="h-4 w-4" />
                View Results
              </Link>
            </Button>
          )}
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Completion</p>
            <p className="text-2xl font-bold mt-1">{Math.round(completionPct)}%</p>
            <Progress value={completionPct} className="h-1.5 mt-2" />
            <p className="text-xs text-muted-foreground mt-1">{answeredCount} / {totalItems} items</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Overall Score</p>
            <p className="text-2xl font-bold mt-1">
              {assessment.overallScore !== null ? formatScore(assessment.overallScore) : "—"}
            </p>
            <p className="text-xs text-muted-foreground mt-1">{isCompleted ? "Final score" : "Score when completed"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Created</p>
            <p className="text-sm font-semibold mt-1">{formatDate(assessment.createdAt)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">by {assessment.createdBy.name}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Due Date</p>
            <p className="text-sm font-semibold mt-1">
              {assessment.dueDate ? formatDate(assessment.dueDate) : "No due date"}
            </p>
            {assessment.completedAt && (
              <p className="text-xs text-muted-foreground mt-0.5">
                Completed {formatDate(assessment.completedAt)}
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Domain progress */}
      {domainMap.size > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Domain Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from(domainMap.entries()).map(([domain, stats]) => {
                const pct = stats.total > 0 ? (stats.answered / stats.total) * 100 : 0;
                const scorePct = domainScoreMap.get(domain)?.percentage;
                return (
                  <div key={domain} className="space-y-1.5 rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium truncate mr-2">{domain}</p>
                      {scorePct !== undefined && (
                        <span className="text-xs font-semibold text-muted-foreground shrink-0">
                          {scorePct.toFixed(1)}%
                        </span>
                      )}
                    </div>
                    <Progress value={pct} className="h-1.5" />
                    <p className="text-xs text-muted-foreground">
                      {stats.answered}/{stats.total} answered
                    </p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent responses */}
      {recentResponses.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Responses</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">Status</TableHead>
                  <TableHead className="w-24">Code</TableHead>
                  <TableHead>Label</TableHead>
                  <TableHead>Domain</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentResponses.map((response) => (
                  <TableRow key={response.id}>
                    <TableCell>
                      {response.isAnswered ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <Circle className="h-4 w-4 text-muted-foreground/40" />
                      )}
                    </TableCell>
                    <TableCell>
                      <code className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded">
                        {response.templateItem.code}
                      </code>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm">
                      {response.templateItem.label}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {response.templateItem.domain}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {response.templateItem.category}
                    </TableCell>
                    <TableCell className="text-right text-sm font-medium">
                      {response.score !== null
                        ? `${response.score} / ${response.templateItem.scoring}`
                        : "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Notes */}
      {assessment.notes && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{assessment.notes}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
