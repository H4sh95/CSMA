"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Loader2, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Profile {
  id: string;
  name: string;
  identifier: string;
  industry: string | null;
  region: string | null;
}

interface Template {
  id: string;
  name: string;
  version: string;
  description: string | null;
  rowCount: number;
}

interface FormState {
  title: string;
  profileId: string;
  templateId: string;
  dueDate: string;
  notes: string;
}

interface DomainState {
  domains: string[];       // all domains in the selected template (ordered)
  included: Set<string>;   // which ones the assessor wants to include
  loading: boolean;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function NewAssessmentPage() {
  const router = useRouter();
  const { toast } = useToast();

  const [form, setForm] = useState<FormState>({
    title: "",
    profileId: "",
    templateId: "",
    dueDate: "",
    notes: "",
  });

  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loadingProfiles, setLoadingProfiles] = useState(true);
  const [loadingTemplates, setLoadingTemplates] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState | "domains", string>>>({});

  const [domainState, setDomainState] = useState<DomainState>({
    domains: [],
    included: new Set(),
    loading: false,
  });

  // ── Fetch profiles ─────────────────────────────────────────────────────────
  useEffect(() => {
    fetch("/api/profiles?status=ACTIVE&pageSize=200")
      .then((r) => r.json())
      .then((json) => setProfiles(json.data ?? []))
      .catch(() => toast({ title: "Warning", description: "Could not load profiles", variant: "destructive" }))
      .finally(() => setLoadingProfiles(false));
  }, [toast]);

  // ── Fetch active templates ─────────────────────────────────────────────────
  useEffect(() => {
    fetch("/api/templates?status=ACTIVE&pageSize=200")
      .then((r) => r.json())
      .then((json) => setTemplates(json.data ?? []))
      .catch(() => toast({ title: "Warning", description: "Could not load templates", variant: "destructive" }))
      .finally(() => setLoadingTemplates(false));
  }, [toast]);

  // ── Fetch domains when template changes ────────────────────────────────────
  useEffect(() => {
    if (!form.templateId) {
      setDomainState({ domains: [], included: new Set(), loading: false });
      return;
    }
    setDomainState((prev) => ({ ...prev, loading: true }));
    fetch(`/api/templates/${form.templateId}/domains`)
      .then((r) => r.json())
      .then((json) => {
        const domains: string[] = json.data ?? [];
        setDomainState({ domains, included: new Set(domains), loading: false });
      })
      .catch(() => {
        setDomainState({ domains: [], included: new Set(), loading: false });
      });
  }, [form.templateId]);

  // ── Validation ─────────────────────────────────────────────────────────────
  function validate(): boolean {
    const newErrors: Partial<Record<keyof FormState | "domains", string>> = {};
    if (!form.title.trim()) newErrors.title = "Assessment title is required";
    if (!form.profileId) newErrors.profileId = "Please select a customer profile";
    if (!form.templateId) newErrors.templateId = "Please select an assessment template";
    if (domainState.domains.length > 0 && domainState.included.size === 0) {
      newErrors.domains = "At least one domain must be included";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  // ── Submit ─────────────────────────────────────────────────────────────────
  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    try {
      const excludedDomains = domainState.domains.filter(
        (d) => !domainState.included.has(d)
      );

      const body: Record<string, unknown> = {
        title: form.title.trim(),
        profileId: form.profileId,
        templateId: form.templateId,
        excludedDomains,
      };
      if (form.dueDate) body.dueDate = form.dueDate;
      if (form.notes.trim()) body.notes = form.notes.trim();

      const res = await fetch("/api/assessments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const json = await res.json();

      if (!res.ok) {
        throw new Error(json.error ?? "Failed to create assessment");
      }

      const assessmentId = json.data?.id;
      toast({ title: "Assessment created", description: "Redirecting to conduct page...", variant: "success" });
      router.push(`/assessments/${assessmentId}/conduct`);
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to create assessment",
        variant: "destructive",
      });
      setSubmitting(false);
    }
  }

  function setField<K extends keyof FormState>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
  }

  const selectedProfile = profiles.find((p) => p.id === form.profileId);
  const selectedTemplate = templates.find((t) => t.id === form.templateId);

  return (
    <div className="max-w-2xl mx-auto space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/assessments">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">New Assessment</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Create a new cybersecurity maturity assessment</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Main form card */}
        <Card>
          <CardHeader>
            <CardTitle>Assessment Details</CardTitle>
            <CardDescription>Fill in the information below to create your assessment.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Title */}
            <div className="space-y-1.5">
              <Label htmlFor="title">
                Assessment Title <span className="text-destructive">*</span>
              </Label>
              <Input
                id="title"
                placeholder="e.g. Q1 2025 Security Maturity Assessment"
                value={form.title}
                onChange={(e) => setField("title", e.target.value)}
                disabled={submitting}
                aria-invalid={!!errors.title}
              />
              {errors.title && <p className="text-xs text-destructive">{errors.title}</p>}
            </div>

            {/* Customer Profile */}
            <div className="space-y-1.5">
              <Label htmlFor="profileId">
                Customer Profile <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.profileId}
                onValueChange={(v) => setField("profileId", v)}
                disabled={submitting || loadingProfiles}
              >
                <SelectTrigger id="profileId" aria-invalid={!!errors.profileId}>
                  <SelectValue placeholder={loadingProfiles ? "Loading profiles..." : "Select a customer profile"} />
                </SelectTrigger>
                <SelectContent>
                  {profiles.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      <span className="font-medium">{p.name}</span>
                      <span className="ml-2 text-muted-foreground text-xs">{p.identifier}</span>
                    </SelectItem>
                  ))}
                  {!loadingProfiles && profiles.length === 0 && (
                    <SelectItem value="__none__" disabled>No active profiles found</SelectItem>
                  )}
                </SelectContent>
              </Select>
              {errors.profileId && <p className="text-xs text-destructive">{errors.profileId}</p>}
              {selectedProfile && (
                <p className="text-xs text-muted-foreground">
                  {[selectedProfile.industry, selectedProfile.region].filter(Boolean).join(" · ")}
                </p>
              )}
            </div>

            {/* Assessment Template */}
            <div className="space-y-1.5">
              <Label htmlFor="templateId">
                Assessment Template <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.templateId}
                onValueChange={(v) => setField("templateId", v)}
                disabled={submitting || loadingTemplates}
              >
                <SelectTrigger id="templateId" aria-invalid={!!errors.templateId}>
                  <SelectValue placeholder={loadingTemplates ? "Loading templates..." : "Select an assessment template"} />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      <span className="font-medium">{t.name}</span>
                      <span className="ml-2 text-muted-foreground text-xs">v{t.version} · {t.rowCount} items</span>
                    </SelectItem>
                  ))}
                  {!loadingTemplates && templates.length === 0 && (
                    <SelectItem value="__none__" disabled>No active templates found</SelectItem>
                  )}
                </SelectContent>
              </Select>
              {errors.templateId && <p className="text-xs text-destructive">{errors.templateId}</p>}
              {selectedTemplate?.description && (
                <p className="text-xs text-muted-foreground">{selectedTemplate.description}</p>
              )}
            </div>

          </CardContent>
        </Card>

        {/* ── Domain Selection card (appears once a template is chosen) ──── */}
        {form.templateId && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Domain Scope</CardTitle>
              <CardDescription>
                Select which domains to include. Excluded domains will not be
                assessed and will not count towards the score.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {domainState.loading ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading domains…
                </div>
              ) : domainState.domains.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No domains found for this template.
                </p>
              ) : (
                <div className="space-y-3">
                  {/* Select / deselect all */}
                  <div className="flex items-center gap-4 pb-2 border-b">
                    <button
                      type="button"
                      className="text-xs text-primary underline-offset-2 hover:underline"
                      onClick={() =>
                        setDomainState((prev) => ({
                          ...prev,
                          included: new Set(prev.domains),
                        }))
                      }
                    >
                      Select all
                    </button>
                    <button
                      type="button"
                      className="text-xs text-muted-foreground underline-offset-2 hover:underline"
                      onClick={() =>
                        setDomainState((prev) => ({
                          ...prev,
                          included: new Set(),
                        }))
                      }
                    >
                      Deselect all
                    </button>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {domainState.included.size} / {domainState.domains.length} included
                    </span>
                  </div>

                  {domainState.domains.map((domain) => {
                    const checked = domainState.included.has(domain);
                    return (
                      <div key={domain} className="flex items-center gap-3">
                        <Checkbox
                          id={`domain-${domain}`}
                          checked={checked}
                          onCheckedChange={(v) => {
                            setDomainState((prev) => {
                              const next = new Set(prev.included);
                              if (v) next.add(domain);
                              else next.delete(domain);
                              return { ...prev, included: next };
                            });
                            if (errors.domains)
                              setErrors((prev) => ({ ...prev, domains: undefined }));
                          }}
                          disabled={submitting}
                        />
                        <label
                          htmlFor={`domain-${domain}`}
                          className="text-sm font-medium leading-none cursor-pointer select-none"
                        >
                          {domain}
                        </label>
                        {!checked && (
                          <span className="text-xs text-muted-foreground italic">
                            excluded
                          </span>
                        )}
                      </div>
                    );
                  })}

                  {errors.domains && (
                    <p className="text-xs text-destructive">{errors.domains}</p>
                  )}

                  {domainState.included.size < domainState.domains.length &&
                    domainState.included.size > 0 && (
                      <div className="flex items-start gap-2 rounded-md bg-amber-50 border border-amber-200 p-3 text-amber-800 text-xs mt-2">
                        <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                        <span>
                          <strong>
                            {domainState.domains.length - domainState.included.size}{" "}
                            domain
                            {domainState.domains.length - domainState.included.size !== 1
                              ? "s"
                              : ""}{" "}
                            excluded
                          </strong>{" "}
                          — these domains will not appear during the assessment and
                          will not count towards the overall score.
                        </span>
                      </div>
                    )}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* ── Assessment details card (continued) ─────────────────────────── */}
        <Card>
          <CardHeader>
            <CardTitle>Schedule & Notes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Due Date */}
            <div className="space-y-1.5">
              <Label htmlFor="dueDate">
                Due Date <span className="text-muted-foreground text-xs">(optional)</span>
              </Label>
              <Input
                id="dueDate"
                type="date"
                value={form.dueDate}
                onChange={(e) => setField("dueDate", e.target.value)}
                disabled={submitting}
                min={new Date().toISOString().split("T")[0]}
              />
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label htmlFor="notes">
                Notes <span className="text-muted-foreground text-xs">(optional)</span>
              </Label>
              <Textarea
                id="notes"
                placeholder="Add any additional context or instructions for this assessment..."
                value={form.notes}
                onChange={(e) => setField("notes", e.target.value)}
                disabled={submitting}
                rows={4}
              />
            </div>
          </CardContent>
        </Card>

        {/* Action buttons */}
        <div className="flex items-center justify-end gap-3">
          <Button type="button" variant="outline" asChild disabled={submitting}>
            <Link href="/assessments">Cancel</Link>
          </Button>
          <Button type="submit" disabled={submitting || loadingProfiles || loadingTemplates}>
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Assessment"
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
