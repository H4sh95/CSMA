"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { Plus, Search, Trash2, PlayCircle, BarChart2, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useDebounce } from "@/hooks/use-debounce";
import { formatDate, formatScore } from "@/lib/utils";
import { Role } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Profile {
  id: string;
  name: string;
  identifier: string;
}

interface Template {
  id: string;
  name: string;
  version: string;
}

interface Assessment {
  id: string;
  title: string;
  status: "DRAFT" | "IN_PROGRESS" | "COMPLETED" | "ARCHIVED";
  overallScore: number | null;
  createdAt: string;
  dueDate: string | null;
  profile: Profile;
  template: Template;
  createdBy: { id: string; name: string; email: string };
}

interface PaginatedResponse {
  data: Assessment[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function statusVariant(status: string): "secondary" | "warning" | "success" | "outline" | "default" {
  switch (status) {
    case "DRAFT": return "secondary";
    case "IN_PROGRESS": return "warning";
    case "COMPLETED": return "success";
    case "ARCHIVED": return "outline";
    default: return "default";
  }
}

function statusLabel(status: string): string {
  switch (status) {
    case "DRAFT": return "Draft";
    case "IN_PROGRESS": return "In Progress";
    case "COMPLETED": return "Completed";
    case "ARCHIVED": return "Archived";
    default: return status;
  }
}

// ─── Component ────────────────────────────────────────────────────────────────

const PAGE_SIZE = 20;

export default function AssessmentsPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const { toast } = useToast();

  const role = (session?.user as { role?: string })?.role as Role | undefined;
  const canCreate = role === Role.ADMIN || role === Role.ASSESSOR;
  const canDelete = role === Role.ADMIN;

  // ── Filters state ──────────────────────────────────────────────────────────
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [profileFilter, setProfileFilter] = useState("ALL");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);

  const debouncedSearch = useDebounce(search, 350);

  // ── Data state ─────────────────────────────────────────────────────────────
  const [result, setResult] = useState<PaginatedResponse | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<Assessment | null>(null);
  const [deleting, setDeleting] = useState(false);

  // ── Fetch profiles for filter dropdown ───────────────────────────────────
  useEffect(() => {
    fetch("/api/profiles?status=ACTIVE&pageSize=200")
      .then((r) => r.json())
      .then((json) => setProfiles(json.data ?? []))
      .catch(() => {/* silently ignore */});
  }, []);

  // ── Fetch assessments ─────────────────────────────────────────────────────
  const fetchAssessments = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(PAGE_SIZE) });
      if (debouncedSearch) params.set("search", debouncedSearch);
      if (statusFilter !== "ALL") params.set("status", statusFilter);
      if (profileFilter !== "ALL") params.set("profileId", profileFilter);
      if (dateFrom) params.set("dateFrom", dateFrom);
      if (dateTo) params.set("dateTo", dateTo);

      const res = await fetch(`/api/assessments?${params}`);
      if (!res.ok) throw new Error("Failed to load assessments");
      const json = await res.json();
      setResult(json);
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to load assessments", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [page, debouncedSearch, statusFilter, profileFilter, dateFrom, dateTo, toast]);

  useEffect(() => {
    fetchAssessments();
  }, [fetchAssessments]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, statusFilter, profileFilter, dateFrom, dateTo]);

  // ── Delete handler ─────────────────────────────────────────────────────────
  async function handleDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/assessments/${deleteTarget.id}`, { method: "DELETE" });
      if (!res.ok) {
        const json = await res.json();
        throw new Error(json.error ?? "Failed to delete assessment");
      }
      toast({ title: "Assessment archived", description: `"${deleteTarget.title}" has been archived.`, variant: "success" });
      setDeleteTarget(null);
      fetchAssessments();
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed to archive assessment", variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  }

  const assessments = result?.data ?? [];
  const totalPages = result?.totalPages ?? 1;
  const total = result?.total ?? 0;

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Assessments</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage and track cybersecurity maturity assessments</p>
        </div>
        {canCreate && (
          <Button asChild>
            <Link href="/assessments/new">
              <Plus className="h-4 w-4" />
              New Assessment
            </Link>
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Search */}
            <div className="relative lg:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by title or profile..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Status filter */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Statuses</SelectItem>
                <SelectItem value="DRAFT">Draft</SelectItem>
                <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                <SelectItem value="COMPLETED">Completed</SelectItem>
                <SelectItem value="ARCHIVED">Archived</SelectItem>
              </SelectContent>
            </Select>

            {/* Profile filter */}
            <Select value={profileFilter} onValueChange={setProfileFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Profiles" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Profiles</SelectItem>
                {profiles.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Date range */}
            <div className="flex gap-2 items-center">
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="text-sm"
                title="From date"
              />
              <span className="text-muted-foreground text-sm shrink-0">–</span>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="text-sm"
                title="To date"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="py-4 px-6 border-b">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            {loading ? "Loading..." : `${total} assessment${total !== 1 ? "s" : ""} found`}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-0">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-14 border-b bg-muted/20 animate-pulse" />
              ))}
            </div>
          ) : assessments.length === 0 ? (
            <div className="py-16 text-center text-sm text-muted-foreground">
              No assessments found. {canCreate && <Link href="/assessments/new" className="text-primary underline">Create your first assessment.</Link>}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Profile</TableHead>
                  <TableHead>Template</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assessments.map((assessment) => (
                  <TableRow key={assessment.id}>
                    <TableCell className="font-medium max-w-[200px] truncate">
                      <Link
                        href={`/assessments/${assessment.id}`}
                        className="hover:underline text-foreground"
                      >
                        {assessment.title}
                      </Link>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {assessment.profile.name}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {assessment.template.name}
                      <span className="ml-1 text-xs text-muted-foreground/60">v{assessment.template.version}</span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={statusVariant(assessment.status)}>
                        {statusLabel(assessment.status)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {assessment.overallScore !== null ? formatScore(assessment.overallScore) : "—"}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {formatDate(assessment.createdAt)}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {assessment.dueDate ? formatDate(assessment.dueDate) : "—"}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        {(assessment.status === "DRAFT" || assessment.status === "IN_PROGRESS") && (
                          <Button
                            variant="ghost"
                            size="sm"
                            asChild
                            title="Continue assessment"
                          >
                            <Link href={`/assessments/${assessment.id}/conduct`}>
                              <PlayCircle className="h-4 w-4" />
                              <span className="ml-1 hidden sm:inline">Continue</span>
                            </Link>
                          </Button>
                        )}
                        {assessment.status === "COMPLETED" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            asChild
                            title="View results"
                          >
                            <Link href={`/results/${assessment.id}`}>
                              <BarChart2 className="h-4 w-4" />
                              <span className="ml-1 hidden sm:inline">Results</span>
                            </Link>
                          </Button>
                        )}
                        {canDelete && assessment.status !== "ARCHIVED" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={() => setDeleteTarget(assessment)}
                            title="Archive assessment"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Delete confirmation dialog */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Archive Assessment?</AlertDialogTitle>
            <AlertDialogDescription>
              This will archive <strong>&quot;{deleteTarget?.title}&quot;</strong>. Archived assessments are
              hidden from regular views but can be retrieved by an administrator. This action cannot
              be undone from the UI.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? "Archiving..." : "Archive"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
