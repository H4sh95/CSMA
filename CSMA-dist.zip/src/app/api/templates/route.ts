import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  requireAuthUser,
  errorResponse,
  paginatedResponse,
  getPaginationParams,
  getSearchParam,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { parseXlsxTemplate } from "@/lib/xlsx-parser";
import { Role, TemplateStatus } from "@prisma/client";

/**
 * GET /api/templates
 * Lists templates. Admin/Assessor see all; Customer sees only ACTIVE.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { searchParams } = new URL(req.url);
    const { page, pageSize, skip } = getPaginationParams(searchParams);
    const search = getSearchParam(searchParams, "search");
    const statusParam = getSearchParam(searchParams, "status") as
      | TemplateStatus
      | undefined;

    const andClauses: Record<string, unknown>[] = [];

    // Customers can only see ACTIVE templates
    if (user.role === Role.CUSTOMER) {
      andClauses.push({ status: TemplateStatus.ACTIVE });
    } else if (
      statusParam &&
      Object.values(TemplateStatus).includes(statusParam)
    ) {
      andClauses.push({ status: statusParam });
    }

    if (search) {
      andClauses.push({
        OR: [
          { name: { contains: search, mode: "insensitive" } },
          { description: { contains: search, mode: "insensitive" } },
          { version: { contains: search, mode: "insensitive" } },
        ],
      });
    }

    const where = andClauses.length > 0 ? { AND: andClauses } : {};

    const [templates, total] = await Promise.all([
      prisma.template.findMany({
        where,
        skip,
        take: pageSize,
        orderBy: { createdAt: "desc" },
        include: {
          uploadedBy: { select: { id: true, name: true, email: true } },
          _count: { select: { items: true, assessments: true } },
        },
      }),
      prisma.template.count({ where }),
    ]);

    return paginatedResponse(templates, total, page, pageSize);
  } catch (error) {
    console.error("[GET /api/templates]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * POST /api/templates
 * Uploads a new template from multipart/form-data (xlsx file).
 * Requires ADMIN or ASSESSOR.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    let formData: FormData;
    try {
      formData = await req.formData();
    } catch {
      return errorResponse("Expected multipart/form-data", 400);
    }

    const file = formData.get("file") as File | null;
    const name = (formData.get("name") as string | null)?.trim();
    const version = ((formData.get("version") as string | null) ?? "1.0").trim();
    const description = (formData.get("description") as string | null)?.trim() ?? null;

    if (!file) return errorResponse("Missing required field: file", 400);
    if (!name || name.length === 0) {
      return errorResponse("Missing required field: name", 400);
    }
    if (name.length > 150) {
      return errorResponse("Template name must not exceed 150 characters", 422);
    }

    // Read file bytes
    const buffer = Buffer.from(await file.arrayBuffer());

    // Parse and validate xlsx
    const parseResult = parseXlsxTemplate(buffer);
    if (!parseResult.valid) {
      return NextResponse.json(
        {
          error: "Template validation failed",
          details: parseResult.errors,
          warnings: parseResult.warnings,
        },
        { status: 422 }
      );
    }

    if (parseResult.rows.length === 0) {
      return NextResponse.json(
        {
          error: "Template contains no data rows",
          warnings: parseResult.warnings,
        },
        { status: 422 }
      );
    }

    // Save template + items in a transaction
    const template = await prisma.$transaction(async (tx) => {
      const created = await tx.template.create({
        data: {
          name,
          version,
          description,
          status: TemplateStatus.DRAFT,
          uploadedById: user.id,
          rowCount: parseResult.rows.length,
        },
      });

      await tx.templateItem.createMany({
        data: parseResult.rows.map((row) => ({
          templateId: created.id,
          domain: row.domain,
          category: row.category,
          code: row.code,
          description: row.description,
          label: row.label,
          scoring: row.scoring,
          orderIndex: row.orderIndex,
        })),
      });

      return created;
    });

    // Persist the original file to ./uploads/{templateId}.xlsx
    try {
      const uploadsDir = path.join(process.cwd(), "uploads");
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }
      const filePath = path.join(uploadsDir, `${template.id}.xlsx`);
      fs.writeFileSync(filePath, buffer);

      // Update template with original file path reference
      await prisma.template.update({
        where: { id: template.id },
        data: { originalFile: `uploads/${template.id}.xlsx` },
      });
    } catch (fsErr) {
      // Non-fatal — the template is already saved; log and continue
      console.error("[POST /api/templates] File save error:", fsErr);
    }

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "TEMPLATE_UPLOADED",
      entityType: "Template",
      entityId: template.id,
      details: {
        name,
        version,
        rowCount: parseResult.rows.length,
        warnings: parseResult.warnings,
      },
      ipAddress,
      userAgent,
    });

    const result = await prisma.template.findUnique({
      where: { id: template.id },
      include: {
        uploadedBy: { select: { id: true, name: true, email: true } },
        _count: { select: { items: true } },
      },
    });

    return NextResponse.json(
      {
        data: result,
        warnings: parseResult.warnings,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("[POST /api/templates]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
