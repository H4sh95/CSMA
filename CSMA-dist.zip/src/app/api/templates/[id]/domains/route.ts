import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuthUser, errorResponse } from "@/lib/api-helpers";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/templates/[id]/domains
 * Returns the unique, ordered list of domain names for a template.
 * Used by the new-assessment form to populate the domain-exclusion checkboxes.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const template = await prisma.template.findUnique({
      where: { id },
      select: { id: true, status: true },
    });
    if (!template) return errorResponse("Template not found", 404);

    // Return the distinct domain values in the order they first appear
    const items = await prisma.templateItem.findMany({
      where: { templateId: id },
      select: { domain: true, orderIndex: true },
      orderBy: { orderIndex: "asc" },
    });

    // Deduplicate while preserving first-seen order
    const seen = new Set<string>();
    const domains: string[] = [];
    for (const item of items) {
      if (!seen.has(item.domain)) {
        seen.add(item.domain);
        domains.push(item.domain);
      }
    }

    return NextResponse.json({ data: domains });
  } catch (error) {
    console.error("[GET /api/templates/[id]/domains]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
