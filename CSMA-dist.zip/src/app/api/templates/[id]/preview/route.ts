import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuthUser, errorResponse } from "@/lib/api-helpers";
import { Role, TemplateStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/templates/[id]/preview
 * Returns all template items grouped by domain > category.
 * Response: { template: {...}, domains: [{ name, categories: [{ name, items: [...] }] }] }
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const template = await prisma.template.findUnique({
      where: { id },
      select: {
        id: true,
        name: true,
        version: true,
        description: true,
        status: true,
        rowCount: true,
        createdAt: true,
        updatedAt: true,
        uploadedBy: { select: { id: true, name: true, email: true } },
      },
    });

    if (!template) return errorResponse("Template not found", 404);

    // Customers may only preview ACTIVE templates
    if (
      user.role === Role.CUSTOMER &&
      template.status !== TemplateStatus.ACTIVE
    ) {
      return errorResponse("Template not found", 404);
    }

    const items = await prisma.templateItem.findMany({
      where: { templateId: id },
      orderBy: [{ domain: "asc" }, { category: "asc" }, { orderIndex: "asc" }],
    });

    // Group by domain > category
    const domainMap = new Map<
      string,
      Map<
        string,
        Array<(typeof items)[number]>
      >
    >();

    for (const item of items) {
      if (!domainMap.has(item.domain)) {
        domainMap.set(item.domain, new Map());
      }
      const categoryMap = domainMap.get(item.domain)!;
      if (!categoryMap.has(item.category)) {
        categoryMap.set(item.category, []);
      }
      categoryMap.get(item.category)!.push(item);
    }

    const domains = Array.from(domainMap.entries()).map(
      ([domainName, categoryMap]) => ({
        name: domainName,
        itemCount: Array.from(categoryMap.values()).reduce(
          (sum, catItems) => sum + catItems.length,
          0
        ),
        categories: Array.from(categoryMap.entries()).map(
          ([categoryName, catItems]) => ({
            name: categoryName,
            itemCount: catItems.length,
            maxScore: catItems.reduce((sum, i) => sum + i.scoring, 0),
            items: catItems,
          })
        ),
      })
    );

    return NextResponse.json({
      data: {
        template,
        domains,
        summary: {
          domainCount: domains.length,
          categoryCount: domains.reduce(
            (sum, d) => sum + d.categories.length,
            0
          ),
          itemCount: items.length,
          maxScore: items.reduce((sum, i) => sum + i.scoring, 0),
        },
      },
    });
  } catch (error) {
    console.error("[GET /api/templates/[id]/preview]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
