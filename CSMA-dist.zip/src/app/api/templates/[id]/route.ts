import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  requireAuthUser,
  errorResponse,
  validateBody,
  getPaginationParams,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { updateTemplateStatusSchema } from "@/lib/validations";
import { Role, TemplateStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/templates/[id]
 * Returns template details with paginated items.
 */
export async function GET(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;
    const { searchParams } = new URL(req.url);
    const { page, pageSize, skip } = getPaginationParams(searchParams);

    const template = await prisma.template.findUnique({
      where: { id },
      include: {
        uploadedBy: { select: { id: true, name: true, email: true } },
        _count: { select: { items: true, assessments: true } },
      },
    });

    if (!template) return errorResponse("Template not found", 404);

    // Customers may only see ACTIVE templates
    if (
      user.role === Role.CUSTOMER &&
      template.status !== TemplateStatus.ACTIVE
    ) {
      return errorResponse("Template not found", 404);
    }

    // Paginated items
    const [items, totalItems] = await Promise.all([
      prisma.templateItem.findMany({
        where: { templateId: id },
        skip,
        take: pageSize,
        orderBy: { orderIndex: "asc" },
      }),
      prisma.templateItem.count({ where: { templateId: id } }),
    ]);

    return NextResponse.json({
      data: {
        ...template,
        items,
        itemsPagination: {
          total: totalItems,
          page,
          pageSize,
          totalPages: Math.ceil(totalItems / pageSize),
        },
      },
    });
  } catch (error) {
    console.error("[GET /api/templates/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * PATCH /api/templates/[id]
 * Updates template status. Requires ADMIN or ASSESSOR.
 * Valid transitions: DRAFT → ACTIVE, ACTIVE → ARCHIVED.
 */
export async function PATCH(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      updateTemplateStatusSchema
    );
    if (validationError) return validationError;

    const template = await prisma.template.findUnique({ where: { id } });
    if (!template) return errorResponse("Template not found", 404);

    // Enforce valid state transitions
    const validTransitions: Record<TemplateStatus, TemplateStatus[]> = {
      [TemplateStatus.DRAFT]: [TemplateStatus.ACTIVE],
      [TemplateStatus.ACTIVE]: [TemplateStatus.ARCHIVED],
      [TemplateStatus.ARCHIVED]: [],
    };

    if (!validTransitions[template.status].includes(body.status)) {
      return errorResponse(
        `Cannot transition from ${template.status} to ${body.status}`,
        400
      );
    }

    const updated = await prisma.template.update({
      where: { id },
      data: { status: body.status },
    });

    const auditAction =
      body.status === TemplateStatus.ACTIVE
        ? "TEMPLATE_ACTIVATED"
        : "TEMPLATE_ARCHIVED";

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: auditAction,
      entityType: "Template",
      entityId: id,
      details: {
        name: template.name,
        previousStatus: template.status,
        newStatus: body.status,
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: updated });
  } catch (error) {
    console.error("[PATCH /api/templates/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * DELETE /api/templates/[id]
 * Deletes a template. Requires ADMIN.
 * Blocked if assessments exist that use this template.
 */
export async function DELETE(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const template = await prisma.template.findUnique({
      where: { id },
      include: { _count: { select: { assessments: true } } },
    });
    if (!template) return errorResponse("Template not found", 404);

    if (template._count.assessments > 0) {
      return errorResponse(
        `Cannot delete a template that has ${template._count.assessments} associated assessment(s). Archive it instead.`,
        409
      );
    }

    await prisma.template.delete({ where: { id } });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "TEMPLATE_ARCHIVED",
      entityType: "Template",
      entityId: id,
      details: { name: template.name, version: template.version, action: "deleted" },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: { deleted: true } });
  } catch (error) {
    console.error("[DELETE /api/templates/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
