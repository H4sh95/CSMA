import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { calculateScores } from "@/lib/scoring";
import { generateAiAnalysis } from "@/lib/ai/analysisService";
import { Role, AssessmentStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/assessments/[id]/submit
 * Finalises the assessment: calculates final scores, marks as COMPLETED.
 * Requires ASSESSOR or ADMIN.
 */
export async function POST(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { id: assessmentId } = await context.params;

    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
      include: {
        template: {
          include: {
            items: {
              select: { id: true, domain: true, category: true, scoring: true },
              orderBy: { orderIndex: "asc" },
            },
          },
        },
        responses: {
          select: {
            templateItemId: true,
            score: true,
            isAnswered: true,
          },
        },
      },
    });

    if (!assessment) return errorResponse("Assessment not found", 404);

    if (assessment.status === AssessmentStatus.COMPLETED) {
      return errorResponse("Assessment is already completed", 400);
    }
    if (assessment.status === AssessmentStatus.ARCHIVED) {
      return errorResponse("Cannot submit an archived assessment", 400);
    }

    // Access check: ASSESSOR must be the creator or assigned to the profile
    if (user.role === Role.ASSESSOR) {
      const isCreator = assessment.createdById === user.id;
      if (!isCreator) {
        const isAssigned = await prisma.assessorAssignment.findFirst({
          where: { assessorId: user.id, profileId: assessment.profileId },
        });
        if (!isAssigned) return errorResponse("Forbidden", 403);
      }
    }

    // ── Calculate final scores ────────────────────────────────────────────────
    // Excluded domains are not counted in score or totals.
    const scoreResult = calculateScores(
      assessment.template.items,
      assessment.responses,
      assessment.excludedDomains ?? []
    );

    const unansweredCount =
      scoreResult.totalItems - scoreResult.answeredItems;
    const hasUnanswered = unansweredCount > 0;

    // ── Persist everything atomically ─────────────────────────────────────────
    await prisma.$transaction(async (tx) => {
      // Update assessment to COMPLETED
      await tx.assessment.update({
        where: { id: assessmentId },
        data: {
          status: AssessmentStatus.COMPLETED,
          completedAt: new Date(),
          overallScore: scoreResult.overallPercentage,
        },
      });

      // Upsert DomainScore records
      for (const [domain, ds] of Object.entries(scoreResult.domainScores)) {
        await tx.domainScore.upsert({
          where: { assessmentId_domain: { assessmentId, domain } },
          update: {
            score: ds.score,
            maxScore: ds.maxScore,
            percentage: ds.percentage,
            itemCount: ds.itemCount,
            answeredCount: ds.answeredCount,
          },
          create: {
            assessmentId,
            domain,
            score: ds.score,
            maxScore: ds.maxScore,
            percentage: ds.percentage,
            itemCount: ds.itemCount,
            answeredCount: ds.answeredCount,
          },
        });
      }

      // Upsert CategoryScore records
      for (const [domain, categories] of Object.entries(
        scoreResult.categoryScores
      )) {
        for (const [category, cs] of Object.entries(categories)) {
          await tx.categoryScore.upsert({
            where: {
              assessmentId_domain_category: { assessmentId, domain, category },
            },
            update: {
              score: cs.score,
              maxScore: cs.maxScore,
              percentage: cs.percentage,
              itemCount: cs.itemCount,
              answeredCount: cs.answeredCount,
            },
            create: {
              assessmentId,
              domain,
              category,
              score: cs.score,
              maxScore: cs.maxScore,
              percentage: cs.percentage,
              itemCount: cs.itemCount,
              answeredCount: cs.answeredCount,
            },
          });
        }
      }
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "ASSESSMENT_SUBMITTED",
      entityType: "Assessment",
      entityId: assessmentId,
      details: {
        overallPercentage: scoreResult.overallPercentage,
        overallScore: scoreResult.overallScore,
        totalItems: scoreResult.totalItems,
        answeredItems: scoreResult.answeredItems,
        unansweredItems: unansweredCount,
        completionPercentage: scoreResult.completionPercentage,
      },
      ipAddress,
      userAgent,
    });

    // ── Trigger AI analysis asynchronously (non-blocking) ────────────────────
    // We deliberately do NOT await this — AI generation runs in the background
    // so it never delays the submit response or causes it to fail.
    generateAiAnalysis({
      assessmentId,
      triggeredByUserId: user.id,
      mode: "automatic",
    }).catch((err) => {
      console.error("[submit] Background AI analysis failed (non-fatal):", err?.message ?? err);
    });

    return NextResponse.json({
      data: {
        assessmentId,
        status: AssessmentStatus.COMPLETED,
        overallScore: scoreResult.overallScore,
        overallPercentage: scoreResult.overallPercentage,
        totalItems: scoreResult.totalItems,
        answeredItems: scoreResult.answeredItems,
        completionPercentage: scoreResult.completionPercentage,
        warning: hasUnanswered
          ? `${unansweredCount} item(s) were not answered and counted as 0.`
          : undefined,
      },
    });
  } catch (error) {
    console.error("[POST /api/assessments/[id]/submit]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
