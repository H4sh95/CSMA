import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  requireAuthUser,
  errorResponse,
  validateBody,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { updateAssessmentSchema } from "@/lib/validations";
import { Role, AssessmentStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/** Checks whether the current user has read access to the given assessment. */
async function canAccess(
  userId: string,
  role: Role,
  assessmentProfileId: string,
  assessmentCreatedById: string
): Promise<boolean> {
  if (role === Role.ADMIN) return true;

  if (role === Role.ASSESSOR) {
    if (assessmentCreatedById === userId) return true;
    const assigned = await prisma.assessorAssignment.findFirst({
      where: { assessorId: userId, profileId: assessmentProfileId },
    });
    return assigned !== null;
  }

  if (role === Role.CUSTOMER) {
    const access = await prisma.userCustomerAccess.findFirst({
      where: { userId, profileId: assessmentProfileId },
    });
    return access !== null;
  }

  return false;
}

/**
 * GET /api/assessments/[id]
 * Returns full assessment with all responses and template items.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const assessment = await prisma.assessment.findUnique({
      where: { id },
      include: {
        profile: true,
        template: {
          include: {
            items: { orderBy: { orderIndex: "asc" } },
          },
        },
        createdBy: { select: { id: true, name: true, email: true } },
        responses: {
          include: {
            templateItem: true,
          },
          orderBy: { templateItem: { orderIndex: "asc" } },
        },
        domainScores: { orderBy: { domain: "asc" } },
        categoryScores: {
          orderBy: [{ domain: "asc" }, { category: "asc" }],
        },
      },
    });

    if (!assessment) return errorResponse("Assessment not found", 404);

    const allowed = await canAccess(
      user.id,
      user.role,
      assessment.profileId,
      assessment.createdById
    );
    if (!allowed) return errorResponse("Forbidden", 403);

    return NextResponse.json({ data: assessment });
  } catch (error) {
    console.error("[GET /api/assessments/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * PATCH /api/assessments/[id]
 * Updates assessment metadata (title, dueDate, notes). Requires ASSESSOR or ADMIN.
 */
export async function PATCH(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      updateAssessmentSchema
    );
    if (validationError) return validationError;

    const assessment = await prisma.assessment.findUnique({
      where: { id },
      select: {
        id: true,
        title: true,
        profileId: true,
        createdById: true,
        status: true,
      },
    });
    if (!assessment) return errorResponse("Assessment not found", 404);

    // Cannot modify a completed or archived assessment's metadata
    if (
      assessment.status === AssessmentStatus.COMPLETED ||
      assessment.status === AssessmentStatus.ARCHIVED
    ) {
      return errorResponse(
        `Cannot modify a ${assessment.status.toLowerCase()} assessment`,
        400
      );
    }

    const allowed = await canAccess(
      user.id,
      user.role,
      assessment.profileId,
      assessment.createdById
    );
    if (!allowed) return errorResponse("Forbidden", 403);

    const updated = await prisma.assessment.update({
      where: { id },
      data: {
        ...(body.title !== undefined && { title: body.title }),
        ...(body.dueDate !== undefined && {
          dueDate: body.dueDate ? new Date(body.dueDate as unknown as string) : null,
        }),
        ...(body.notes !== undefined && { notes: body.notes }),
      },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "ASSESSMENT_UPDATED",
      entityType: "Assessment",
      entityId: id,
      details: { changes: body },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: updated });
  } catch (error) {
    console.error("[PATCH /api/assessments/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * DELETE /api/assessments/[id]
 * Archives an assessment. Requires ADMIN.
 */
export async function DELETE(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const assessment = await prisma.assessment.findUnique({
      where: { id },
      select: { id: true, title: true, status: true },
    });
    if (!assessment) return errorResponse("Assessment not found", 404);

    if (assessment.status === AssessmentStatus.ARCHIVED) {
      return errorResponse("Assessment is already archived", 400);
    }

    const archived = await prisma.assessment.update({
      where: { id },
      data: { status: AssessmentStatus.ARCHIVED },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "ASSESSMENT_ARCHIVED",
      entityType: "Assessment",
      entityId: id,
      details: {
        title: assessment.title,
        previousStatus: assessment.status,
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: archived });
  } catch (error) {
    console.error("[DELETE /api/assessments/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
