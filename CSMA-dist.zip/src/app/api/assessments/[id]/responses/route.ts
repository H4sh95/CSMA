import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  validateBody,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { batchResponsesSchema } from "@/lib/validations";
import { calculateScores } from "@/lib/scoring";
import { Role, AssessmentStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/assessments/[id]/responses
 * Batch-saves (upserts) assessment responses, then recalculates domain/category scores.
 * Requires ASSESSOR or ADMIN.
 */
export async function POST(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { id: assessmentId } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      batchResponsesSchema
    );
    if (validationError) return validationError;

    // Load assessment with enough data to validate access and run scoring
    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
      include: {
        template: {
          include: {
            items: { select: { id: true, domain: true, category: true, scoring: true } },
          },
        },
      },
    });

    if (!assessment) return errorResponse("Assessment not found", 404);

    if (assessment.status === AssessmentStatus.ARCHIVED) {
      return errorResponse("Cannot modify an archived assessment", 400);
    }
    if (assessment.status === AssessmentStatus.COMPLETED) {
      return errorResponse(
        "Assessment is already completed. Create a new assessment to re-assess.",
        400
      );
    }

    // Verify access: ASSESSOR must have created it or be assigned to the profile
    if (user.role === Role.ASSESSOR) {
      const isCreator = assessment.createdById === user.id;
      const isAssigned = isCreator
        ? true
        : await prisma.assessorAssignment.findFirst({
            where: { assessorId: user.id, profileId: assessment.profileId },
          });
      if (!isCreator && !isAssigned) {
        return errorResponse("Forbidden", 403);
      }
    }

    // Validate that all submitted templateItemIds belong to this assessment's template
    const validItemIds = new Set(assessment.template.items.map((i) => i.id));
    const invalidIds = body.responses
      .map((r) => r.templateItemId)
      .filter((tid) => !validItemIds.has(tid));

    if (invalidIds.length > 0) {
      return errorResponse(
        `Invalid templateItemId(s) for this assessment: ${invalidIds.join(", ")}`,
        400
      );
    }

    // Upsert each response
    await prisma.$transaction(
      body.responses.map((r) =>
        prisma.assessmentResponse.upsert({
          where: {
            assessmentId_templateItemId: {
              assessmentId,
              templateItemId: r.templateItemId,
            },
          },
          update: {
            score: r.score,
            comment: r.comment ?? null,
            evidenceNote: r.evidenceNote ?? null,
            isAnswered: r.isAnswered,
          },
          create: {
            assessmentId,
            templateItemId: r.templateItemId,
            score: r.score,
            comment: r.comment ?? null,
            evidenceNote: r.evidenceNote ?? null,
            isAnswered: r.isAnswered,
          },
        })
      )
    );

    // ── Recalculate domain/category scores ────────────────────────────────────
    const allResponses = await prisma.assessmentResponse.findMany({
      where: { assessmentId },
      select: { templateItemId: true, score: true, isAnswered: true },
    });

    const scoreResult = calculateScores(
      assessment.template.items,
      allResponses
    );

    // Upsert DomainScore records
    await prisma.$transaction([
      ...Object.entries(scoreResult.domainScores).map(([domain, ds]) =>
        prisma.domainScore.upsert({
          where: { assessmentId_domain: { assessmentId, domain } },
          update: {
            score: ds.score,
            maxScore: ds.maxScore,
            percentage: ds.percentage,
            itemCount: ds.itemCount,
            answeredCount: ds.answeredCount,
          },
          create: {
            assessmentId,
            domain,
            score: ds.score,
            maxScore: ds.maxScore,
            percentage: ds.percentage,
            itemCount: ds.itemCount,
            answeredCount: ds.answeredCount,
          },
        })
      ),
      ...Object.entries(scoreResult.categoryScores).flatMap(
        ([domain, categories]) =>
          Object.entries(categories).map(([category, cs]) =>
            prisma.categoryScore.upsert({
              where: {
                assessmentId_domain_category: { assessmentId, domain, category },
              },
              update: {
                score: cs.score,
                maxScore: cs.maxScore,
                percentage: cs.percentage,
                itemCount: cs.itemCount,
                answeredCount: cs.answeredCount,
              },
              create: {
                assessmentId,
                domain,
                category,
                score: cs.score,
                maxScore: cs.maxScore,
                percentage: cs.percentage,
                itemCount: cs.itemCount,
                answeredCount: cs.answeredCount,
              },
            })
          )
      ),
    ]);

    // Advance status from DRAFT to IN_PROGRESS on first save
    if (assessment.status === AssessmentStatus.DRAFT) {
      await prisma.assessment.update({
        where: { id: assessmentId },
        data: { status: AssessmentStatus.IN_PROGRESS },
      });
    }

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "RESPONSE_SAVED",
      entityType: "Assessment",
      entityId: assessmentId,
      details: {
        responseCount: body.responses.length,
        answeredItems: scoreResult.answeredItems,
        totalItems: scoreResult.totalItems,
        overallPercentage: scoreResult.overallPercentage,
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({
      data: {
        saved: body.responses.length,
        scores: {
          overallScore: scoreResult.overallScore,
          overallPercentage: scoreResult.overallPercentage,
          answeredItems: scoreResult.answeredItems,
          totalItems: scoreResult.totalItems,
          completionPercentage: scoreResult.completionPercentage,
        },
      },
    });
  } catch (error) {
    console.error("[POST /api/assessments/[id]/responses]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
