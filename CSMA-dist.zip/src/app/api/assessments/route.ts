import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  requireAuthUser,
  errorResponse,
  paginatedResponse,
  validateBody,
  getPaginationParams,
  getSearchParam,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { createAssessmentSchema } from "@/lib/validations";
import { Role, AssessmentStatus, TemplateStatus } from "@prisma/client";

/**
 * GET /api/assessments
 * Lists assessments with filters. Role-filtered.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { searchParams } = new URL(req.url);
    const { page, pageSize, skip } = getPaginationParams(searchParams);
    const search = getSearchParam(searchParams, "search");
    const statusParam = getSearchParam(searchParams, "status") as
      | AssessmentStatus
      | undefined;
    const profileId = getSearchParam(searchParams, "profileId");
    const templateId = getSearchParam(searchParams, "templateId");
    const dateFrom = searchParams.get("dateFrom");
    const dateTo = searchParams.get("dateTo");

    // ── Role-scoped base filter ───────────────────────────────────────────────
    let baseWhere: Record<string, unknown> = {};

    if (user.role === Role.ASSESSOR) {
      const assignments = await prisma.assessorAssignment.findMany({
        where: { assessorId: user.id },
        select: { profileId: true },
      });
      const profileIds = assignments.map((a) => a.profileId);
      baseWhere = {
        OR: [
          { createdById: user.id },
          { profileId: { in: profileIds } },
        ],
      };
    } else if (user.role === Role.CUSTOMER) {
      const access = await prisma.userCustomerAccess.findMany({
        where: { userId: user.id },
        select: { profileId: true },
      });
      baseWhere = { profileId: { in: access.map((a) => a.profileId) } };
    }

    // ── Additional filters ────────────────────────────────────────────────────
    const andClauses: Record<string, unknown>[] = [baseWhere];

    if (statusParam && Object.values(AssessmentStatus).includes(statusParam)) {
      andClauses.push({ status: statusParam });
    }
    if (profileId) andClauses.push({ profileId });
    if (templateId) andClauses.push({ templateId });
    if (search) {
      andClauses.push({
        OR: [
          { title: { contains: search, mode: "insensitive" } },
          { profile: { name: { contains: search, mode: "insensitive" } } },
        ],
      });
    }
    if (dateFrom) {
      const from = new Date(dateFrom);
      if (!isNaN(from.getTime())) andClauses.push({ createdAt: { gte: from } });
    }
    if (dateTo) {
      const to = new Date(dateTo);
      if (!isNaN(to.getTime())) andClauses.push({ createdAt: { lte: to } });
    }

    const where = { AND: andClauses };

    const [assessments, total] = await Promise.all([
      prisma.assessment.findMany({
        where,
        skip,
        take: pageSize,
        orderBy: { createdAt: "desc" },
        include: {
          profile: { select: { id: true, name: true, identifier: true } },
          template: { select: { id: true, name: true, version: true } },
          createdBy: { select: { id: true, name: true, email: true } },
          _count: { select: { responses: true } },
        },
      }),
      prisma.assessment.count({ where }),
    ]);

    return paginatedResponse(assessments, total, page, pageSize);
  } catch (error) {
    console.error("[GET /api/assessments]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * POST /api/assessments
 * Creates a new assessment with pre-populated response records.
 * Requires ASSESSOR or ADMIN.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { data: body, error: validationError } = await validateBody(
      req,
      createAssessmentSchema
    );
    if (validationError) return validationError;

    // Validate profile exists
    const profile = await prisma.customerProfile.findUnique({
      where: { id: body.profileId },
      select: { id: true, name: true, status: true },
    });
    if (!profile) return errorResponse("Profile not found", 404);

    // Validate template exists and is ACTIVE
    const template = await prisma.template.findUnique({
      where: { id: body.templateId },
      include: {
        items: {
          select: { id: true, domain: true },
          orderBy: { orderIndex: "asc" },
        },
      },
    });
    if (!template) return errorResponse("Template not found", 404);
    if (template.status !== TemplateStatus.ACTIVE) {
      return errorResponse(
        `Template is not active (current status: ${template.status})`,
        400
      );
    }
    if (template.items.length === 0) {
      return errorResponse("Template has no items", 400);
    }

    // Validate excluded domains: must not exclude ALL domains
    const excludedDomains: string[] = body.excludedDomains ?? [];
    const allDomains = [...new Set(template.items.map((i) => i.domain))];
    if (
      excludedDomains.length > 0 &&
      allDomains.every((d) => excludedDomains.includes(d))
    ) {
      return errorResponse(
        "At least one domain must be included in the assessment",
        400
      );
    }

    // Items that will actually be assessed (excluded domains get no stubs)
    const includedItems =
      excludedDomains.length > 0
        ? template.items.filter((i) => !excludedDomains.includes(i.domain))
        : template.items;

    // Assessors may only create assessments for profiles they are assigned to
    if (user.role === Role.ASSESSOR) {
      const assigned = await prisma.assessorAssignment.findFirst({
        where: { assessorId: user.id, profileId: body.profileId },
      });
      if (!assigned) {
        return errorResponse(
          "You are not assigned to this profile",
          403
        );
      }
    }

    // Create assessment + all response stubs atomically
    const assessment = await prisma.$transaction(async (tx) => {
      const created = await tx.assessment.create({
        data: {
          title: body.title,
          profileId: body.profileId,
          templateId: body.templateId,
          createdById: user.id,
          status: AssessmentStatus.DRAFT,
          dueDate: body.dueDate ? new Date(body.dueDate as unknown as string) : null,
          notes: body.notes ?? null,
          excludedDomains,
        },
      });

      // Pre-create response stubs only for included (non-excluded) domains
      await tx.assessmentResponse.createMany({
        data: includedItems.map((item) => ({
          assessmentId: created.id,
          templateItemId: item.id,
          score: null,
          comment: null,
          evidenceNote: null,
          isAnswered: false,
        })),
      });

      return created;
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "ASSESSMENT_CREATED",
      entityType: "Assessment",
      entityId: assessment.id,
      details: {
        title: assessment.title,
        profileId: body.profileId,
        profileName: profile.name,
        templateId: body.templateId,
        templateName: template.name,
        responseCount: includedItems.length,
        excludedDomains,
      },
      ipAddress,
      userAgent,
    });

    const result = await prisma.assessment.findUnique({
      where: { id: assessment.id },
      include: {
        profile: { select: { id: true, name: true, identifier: true } },
        template: { select: { id: true, name: true, version: true } },
        createdBy: { select: { id: true, name: true, email: true } },
        _count: { select: { responses: true } },
      },
    });

    return NextResponse.json({ data: result }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/assessments]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
