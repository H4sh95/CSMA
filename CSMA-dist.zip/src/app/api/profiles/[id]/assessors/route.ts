import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  validateBody,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { assignAssessorSchema, removeAssessorSchema } from "@/lib/validations";
import { Role } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/profiles/[id]/assessors
 * Lists all assessors assigned to this profile. Requires ADMIN or ASSESSOR.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { id: profileId } = await context.params;

    const profile = await prisma.customerProfile.findUnique({
      where: { id: profileId },
      select: { id: true, name: true },
    });
    if (!profile) return errorResponse("Profile not found", 404);

    const assignments = await prisma.assessorAssignment.findMany({
      where: { profileId },
      include: {
        assessor: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
            isActive: true,
            createdAt: true,
          },
        },
      },
      orderBy: { createdAt: "asc" },
    });

    return NextResponse.json({ data: assignments });
  } catch (error) {
    console.error("[GET /api/profiles/[id]/assessors]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * POST /api/profiles/[id]/assessors
 * Assigns an assessor to this profile. Requires ADMIN.
 */
export async function POST(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const { id: profileId } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      assignAssessorSchema
    );
    if (validationError) return validationError;

    const profile = await prisma.customerProfile.findUnique({
      where: { id: profileId },
    });
    if (!profile) return errorResponse("Profile not found", 404);

    // Verify the target user exists and is an ASSESSOR or ADMIN
    const assessor = await prisma.user.findUnique({
      where: { id: body.assessorId },
      select: { id: true, name: true, email: true, role: true, isActive: true },
    });
    if (!assessor) return errorResponse("Assessor not found", 404);
    if (!assessor.isActive) return errorResponse("Assessor account is disabled", 400);
    if (assessor.role === Role.CUSTOMER) {
      return errorResponse("User does not have assessor privileges", 400);
    }

    // Upsert to avoid duplicate assignment errors
    const assignment = await prisma.assessorAssignment.upsert({
      where: {
        assessorId_profileId: {
          assessorId: body.assessorId,
          profileId,
        },
      },
      update: {},
      create: { assessorId: body.assessorId, profileId },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "PROFILE_UPDATED",
      entityType: "AssessorAssignment",
      entityId: assignment.id,
      details: {
        profileId,
        profileName: profile.name,
        assessorId: body.assessorId,
        assessorName: assessor.name,
        action: "assigned",
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: assignment }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/profiles/[id]/assessors]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * DELETE /api/profiles/[id]/assessors
 * Removes an assessor assignment. Requires ADMIN.
 * Body: { assessorId: string }
 */
export async function DELETE(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const { id: profileId } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      removeAssessorSchema
    );
    if (validationError) return validationError;

    const assignment = await prisma.assessorAssignment.findUnique({
      where: {
        assessorId_profileId: {
          assessorId: body.assessorId,
          profileId,
        },
      },
    });
    if (!assignment) {
      return errorResponse("Assignment not found", 404);
    }

    await prisma.assessorAssignment.delete({
      where: { id: assignment.id },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "PROFILE_UPDATED",
      entityType: "AssessorAssignment",
      entityId: assignment.id,
      details: {
        profileId,
        assessorId: body.assessorId,
        action: "removed",
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: { removed: true } });
  } catch (error) {
    console.error("[DELETE /api/profiles/[id]/assessors]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
