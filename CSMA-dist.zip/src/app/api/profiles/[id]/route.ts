import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  requireAuthUser,
  errorResponse,
  validateBody,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { updateProfileSchema } from "@/lib/validations";
import { Role, ProfileStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/profiles/[id]
 * Returns a single profile with assessment count and assigned assessors.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const profile = await prisma.customerProfile.findUnique({
      where: { id },
      include: {
        _count: { select: { assessments: true } },
        assessorAssignments: {
          include: {
            assessor: { select: { id: true, name: true, email: true } },
          },
        },
        createdBy: { select: { id: true, name: true, email: true } },
      },
    });

    if (!profile) {
      return errorResponse("Profile not found", 404);
    }

    // Role-based access check for non-admins
    if (user.role === Role.ASSESSOR) {
      const assigned = await prisma.assessorAssignment.findFirst({
        where: { assessorId: user.id, profileId: id },
      });
      if (!assigned) return errorResponse("Forbidden", 403);
    } else if (user.role === Role.CUSTOMER) {
      const access = await prisma.userCustomerAccess.findFirst({
        where: { userId: user.id, profileId: id },
      });
      if (!access) return errorResponse("Forbidden", 403);
    }

    return NextResponse.json({ data: profile });
  } catch (error) {
    console.error("[GET /api/profiles/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * PUT /api/profiles/[id]
 * Updates a profile. Requires ADMIN or ASSESSOR.
 */
export async function PUT(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      updateProfileSchema
    );
    if (validationError) return validationError;

    const existing = await prisma.customerProfile.findUnique({
      where: { id },
    });
    if (!existing) return errorResponse("Profile not found", 404);

    // Assessors may only update profiles they are assigned to
    if (user.role === Role.ASSESSOR) {
      const assigned = await prisma.assessorAssignment.findFirst({
        where: { assessorId: user.id, profileId: id },
      });
      if (!assigned) return errorResponse("Forbidden", 403);
    }

    // Prevent re-using an identifier that belongs to a different profile
    if (body.identifier && body.identifier !== existing.identifier) {
      const conflict = await prisma.customerProfile.findUnique({
        where: { identifier: body.identifier },
      });
      if (conflict) {
        return errorResponse(
          `Identifier "${body.identifier}" is already in use`,
          409
        );
      }
    }

    const updated = await prisma.customerProfile.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.identifier !== undefined && { identifier: body.identifier }),
        ...(body.industry !== undefined && { industry: body.industry }),
        ...(body.region !== undefined && { region: body.region }),
        ...(body.country !== undefined && { country: body.country }),
        ...(body.primaryContact !== undefined && {
          primaryContact: body.primaryContact,
        }),
        ...(body.primaryEmail !== undefined && {
          primaryEmail: body.primaryEmail,
        }),
        ...(body.notes !== undefined && { notes: body.notes }),
        ...(body.status !== undefined && { status: body.status }),
      },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "PROFILE_UPDATED",
      entityType: "CustomerProfile",
      entityId: id,
      details: { changes: body },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: updated });
  } catch (error) {
    console.error("[PUT /api/profiles/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * DELETE /api/profiles/[id]
 * Soft-deletes a profile by setting status to ARCHIVED. Requires ADMIN.
 */
export async function DELETE(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const existing = await prisma.customerProfile.findUnique({
      where: { id },
    });
    if (!existing) return errorResponse("Profile not found", 404);

    if (existing.status === ProfileStatus.ARCHIVED) {
      return errorResponse("Profile is already archived", 400);
    }

    const archived = await prisma.customerProfile.update({
      where: { id },
      data: { status: ProfileStatus.ARCHIVED },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "PROFILE_ARCHIVED",
      entityType: "CustomerProfile",
      entityId: id,
      details: { name: existing.name, identifier: existing.identifier },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: archived });
  } catch (error) {
    console.error("[DELETE /api/profiles/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
