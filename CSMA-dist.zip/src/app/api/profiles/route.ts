import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  requireAuthUser,
  errorResponse,
  paginatedResponse,
  validateBody,
  getPaginationParams,
  getSearchParam,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { createProfileSchema } from "@/lib/validations";
import { Role, ProfileStatus } from "@prisma/client";

/**
 * GET /api/profiles
 * Lists customer profiles with pagination, search, and status filter.
 * Role-filtered: Admin sees all, Assessor sees assigned, Customer sees linked.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { searchParams } = new URL(req.url);
    const { page, pageSize, skip } = getPaginationParams(searchParams);
    const search = getSearchParam(searchParams, "search");
    const statusParam = getSearchParam(searchParams, "status") as
      | ProfileStatus
      | undefined;

    // ── Build role-scoped WHERE ──────────────────────────────────────────────
    let baseWhere: Record<string, unknown> = {};

    if (user.role === Role.ASSESSOR) {
      const assignments = await prisma.assessorAssignment.findMany({
        where: { assessorId: user.id },
        select: { profileId: true },
      });
      baseWhere = { id: { in: assignments.map((a) => a.profileId) } };
    } else if (user.role === Role.CUSTOMER) {
      const access = await prisma.userCustomerAccess.findMany({
        where: { userId: user.id },
        select: { profileId: true },
      });
      baseWhere = { id: { in: access.map((a) => a.profileId) } };
    }

    // ── Apply filters ────────────────────────────────────────────────────────
    const andClauses: Record<string, unknown>[] = [];

    if (statusParam && Object.values(ProfileStatus).includes(statusParam)) {
      andClauses.push({ status: statusParam });
    }

    if (search) {
      andClauses.push({
        OR: [
          { name: { contains: search, mode: "insensitive" } },
          { identifier: { contains: search, mode: "insensitive" } },
          { industry: { contains: search, mode: "insensitive" } },
          { primaryContact: { contains: search, mode: "insensitive" } },
        ],
      });
    }

    const where =
      andClauses.length > 0
        ? { AND: [baseWhere, ...andClauses] }
        : baseWhere;

    const [profiles, total] = await Promise.all([
      prisma.customerProfile.findMany({
        where,
        skip,
        take: pageSize,
        orderBy: { createdAt: "desc" },
        include: {
          _count: { select: { assessments: true } },
          assessorAssignments: {
            include: {
              assessor: { select: { id: true, name: true, email: true } },
            },
          },
        },
      }),
      prisma.customerProfile.count({ where }),
    ]);

    return paginatedResponse(profiles, total, page, pageSize);
  } catch (error) {
    console.error("[GET /api/profiles]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * POST /api/profiles
 * Creates a new CustomerProfile. Requires ADMIN or ASSESSOR.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN, Role.ASSESSOR]);
    if (user instanceof NextResponse) return user;

    const { data: body, error: validationError } = await validateBody(
      req,
      createProfileSchema
    );
    if (validationError) return validationError;

    // Check identifier uniqueness
    const existing = await prisma.customerProfile.findUnique({
      where: { identifier: body.identifier },
    });
    if (existing) {
      return errorResponse(
        `A profile with identifier "${body.identifier}" already exists`,
        409
      );
    }

    const profile = await prisma.customerProfile.create({
      data: {
        name: body.name,
        identifier: body.identifier,
        industry: body.industry ?? null,
        region: body.region ?? null,
        country: body.country ?? null,
        primaryContact: body.primaryContact ?? null,
        primaryEmail: body.primaryEmail ?? null,
        notes: body.notes ?? null,
        status: body.status ?? ProfileStatus.ACTIVE,
        createdById: user.id,
      },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: "PROFILE_CREATED",
      entityType: "CustomerProfile",
      entityId: profile.id,
      details: { name: profile.name, identifier: profile.identifier },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: profile }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/profiles]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
