import { NextRequest, NextResponse } from "next/server";
import { requireAuthUser } from "@/lib/api-helpers";

/**
 * GET /api/auth/me
 * Returns the current session user or 401 if unauthenticated.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  const user = await requireAuthUser();
  if (user instanceof NextResponse) return user;

  return NextResponse.json({ data: user });
}
