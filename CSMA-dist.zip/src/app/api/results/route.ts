import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireAuthUser,
  errorResponse,
  paginatedResponse,
  getPaginationParams,
  getSearchParam,
} from "@/lib/api-helpers";
import { Role, AssessmentStatus } from "@prisma/client";

/**
 * GET /api/results
 * Lists completed assessments with full score data. Role-filtered.
 * Supports filters: profileId, templateId, dateFrom, dateTo, scoreMin, scoreMax, search.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { searchParams } = new URL(req.url);
    const { page, pageSize, skip } = getPaginationParams(searchParams);
    const search = getSearchParam(searchParams, "search");
    const profileId = getSearchParam(searchParams, "profileId");
    const templateId = getSearchParam(searchParams, "templateId");
    const dateFrom = searchParams.get("dateFrom");
    const dateTo = searchParams.get("dateTo");
    const scoreMin = searchParams.get("scoreMin");
    const scoreMax = searchParams.get("scoreMax");

    // ── Role-scoped base filter ───────────────────────────────────────────────
    let baseWhere: Record<string, unknown> = {};

    if (user.role === Role.ASSESSOR) {
      const assignments = await prisma.assessorAssignment.findMany({
        where: { assessorId: user.id },
        select: { profileId: true },
      });
      const profileIds = assignments.map((a) => a.profileId);
      baseWhere = {
        OR: [
          { createdById: user.id },
          { profileId: { in: profileIds } },
        ],
      };
    } else if (user.role === Role.CUSTOMER) {
      const access = await prisma.userCustomerAccess.findMany({
        where: { userId: user.id },
        select: { profileId: true },
      });
      baseWhere = { profileId: { in: access.map((a) => a.profileId) } };
    }

    // ── Filter clauses ────────────────────────────────────────────────────────
    const andClauses: Record<string, unknown>[] = [
      baseWhere,
      { status: AssessmentStatus.COMPLETED },
    ];

    if (profileId) andClauses.push({ profileId });
    if (templateId) andClauses.push({ templateId });

    if (search) {
      andClauses.push({
        OR: [
          { title: { contains: search, mode: "insensitive" } },
          { profile: { name: { contains: search, mode: "insensitive" } } },
        ],
      });
    }

    if (dateFrom) {
      const from = new Date(dateFrom);
      if (!isNaN(from.getTime()))
        andClauses.push({ completedAt: { gte: from } });
    }
    if (dateTo) {
      const to = new Date(dateTo);
      if (!isNaN(to.getTime())) andClauses.push({ completedAt: { lte: to } });
    }

    if (scoreMin !== null && scoreMin !== "") {
      const min = parseFloat(scoreMin);
      if (!isNaN(min)) andClauses.push({ overallScore: { gte: min } });
    }
    if (scoreMax !== null && scoreMax !== "") {
      const max = parseFloat(scoreMax);
      if (!isNaN(max)) andClauses.push({ overallScore: { lte: max } });
    }

    const where = { AND: andClauses };

    const [assessments, total] = await Promise.all([
      prisma.assessment.findMany({
        where,
        skip,
        take: pageSize,
        orderBy: { completedAt: "desc" },
        include: {
          profile: {
            select: {
              id: true,
              name: true,
              identifier: true,
              industry: true,
              region: true,
            },
          },
          template: { select: { id: true, name: true, version: true } },
          createdBy: { select: { id: true, name: true, email: true } },
          domainScores: { orderBy: { domain: "asc" } },
          categoryScores: {
            orderBy: [{ domain: "asc" }, { category: "asc" }],
          },
          _count: { select: { responses: true } },
        },
      }),
      prisma.assessment.count({ where }),
    ]);

    return paginatedResponse(assessments, total, page, pageSize);
  } catch (error) {
    console.error("[GET /api/results]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
