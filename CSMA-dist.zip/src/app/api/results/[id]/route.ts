import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuthUser, errorResponse } from "@/lib/api-helpers";
import { Role, AssessmentStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/results/[id]
 * Detailed result: metadata, profile, template, all scores, all responses,
 * assessor info, and historical assessments for the same profile.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;

    const assessment = await prisma.assessment.findUnique({
      where: { id },
      include: {
        profile: true,
        template: {
          select: {
            id: true,
            name: true,
            version: true,
            description: true,
            status: true,
            rowCount: true,
            createdAt: true,
            // items needed by the results page to compute totalItems / completion %
            items: { select: { id: true } },
          },
        },
        createdBy: {
          select: { id: true, name: true, email: true, role: true },
        },
        responses: {
          include: {
            templateItem: true,
          },
          orderBy: { templateItem: { orderIndex: "asc" } },
        },
        domainScores: { orderBy: { domain: "asc" } },
        categoryScores: {
          orderBy: [{ domain: "asc" }, { category: "asc" }],
        },
      },
    });

    if (!assessment) return errorResponse("Result not found", 404);

    // Results endpoint only exposes completed assessments
    if (assessment.status !== AssessmentStatus.COMPLETED) {
      return errorResponse("Assessment is not completed", 404);
    }

    // ── Access check ──────────────────────────────────────────────────────────
    if (user.role === Role.ASSESSOR) {
      const isCreator = assessment.createdById === user.id;
      if (!isCreator) {
        const assigned = await prisma.assessorAssignment.findFirst({
          where: { assessorId: user.id, profileId: assessment.profileId },
        });
        if (!assigned) return errorResponse("Forbidden", 403);
      }
    } else if (user.role === Role.CUSTOMER) {
      const access = await prisma.userCustomerAccess.findFirst({
        where: { userId: user.id, profileId: assessment.profileId },
      });
      if (!access) return errorResponse("Forbidden", 403);
    }

    // ── Historical assessments for the same profile ───────────────────────────
    const history = await prisma.assessment.findMany({
      where: {
        profileId: assessment.profileId,
        status: AssessmentStatus.COMPLETED,
        id: { not: id }, // exclude current
      },
      orderBy: { completedAt: "desc" },
      take: 10,
      select: {
        id: true,
        title: true,
        status: true,
        overallScore: true,
        completedAt: true,
        createdAt: true,
        template: { select: { id: true, name: true, version: true } },
        domainScores: { orderBy: { domain: "asc" } },
      },
    });

    return NextResponse.json({
      data: {
        ...assessment,
        history,
      },
    });
  } catch (error) {
    console.error("[GET /api/results/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
