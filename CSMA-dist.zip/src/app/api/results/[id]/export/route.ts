import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuthUser, errorResponse, getRequestMeta } from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { generatePdfReport, generateXlsxReport } from "@/lib/export";
import { Role, AssessmentStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/results/[id]/export?format=pdf|xlsx
 * Exports a completed assessment report as PDF or XLSX.
 */
export async function GET(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id } = await context.params;
    const { searchParams } = new URL(req.url);
    const format = (searchParams.get("format") ?? "pdf").toLowerCase();

    if (format !== "pdf" && format !== "xlsx") {
      return errorResponse(
        'Invalid format. Use "pdf" or "xlsx".',
        400
      );
    }

    // Verify assessment exists, is completed, and user has access
    const assessment = await prisma.assessment.findUnique({
      where: { id },
      select: {
        id: true,
        title: true,
        status: true,
        profileId: true,
        createdById: true,
        profile: { select: { name: true, identifier: true } },
      },
    });

    if (!assessment) return errorResponse("Assessment not found", 404);

    if (assessment.status !== AssessmentStatus.COMPLETED) {
      return errorResponse(
        "Only completed assessments can be exported",
        400
      );
    }

    // ── Access check ──────────────────────────────────────────────────────────
    if (user.role === Role.ASSESSOR) {
      const isCreator = assessment.createdById === user.id;
      if (!isCreator) {
        const assigned = await prisma.assessorAssignment.findFirst({
          where: { assessorId: user.id, profileId: assessment.profileId },
        });
        if (!assigned) return errorResponse("Forbidden", 403);
      }
    } else if (user.role === Role.CUSTOMER) {
      const access = await prisma.userCustomerAccess.findFirst({
        where: { userId: user.id, profileId: assessment.profileId },
      });
      if (!access) return errorResponse("Forbidden", 403);
    }

    // ── Generate report ───────────────────────────────────────────────────────
    const safeTitle = assessment.title.replace(/[^a-z0-9_\-]/gi, "_").slice(0, 60);
    const safeName = assessment.profile.identifier.replace(/[^a-z0-9_\-]/gi, "_");

    let buffer: Buffer;
    let contentType: string;
    let filename: string;
    let auditAction: "EXPORT_PDF" | "EXPORT_XLSX";

    if (format === "pdf") {
      buffer = await generatePdfReport(id);
      contentType = "application/pdf";
      filename = `CSMA_${safeName}_${safeTitle}.pdf`;
      auditAction = "EXPORT_PDF";
    } else {
      buffer = await generateXlsxReport(id);
      contentType =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      filename = `CSMA_${safeName}_${safeTitle}.xlsx`;
      auditAction = "EXPORT_XLSX";
    }

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: user.id,
      action: auditAction,
      entityType: "Assessment",
      entityId: id,
      details: {
        title: assessment.title,
        profileName: assessment.profile.name,
        format,
        filename,
      },
      ipAddress,
      userAgent,
    });

    return new NextResponse(new Uint8Array(buffer), {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Content-Length": String(buffer.length),
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("[GET /api/results/[id]/export]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
