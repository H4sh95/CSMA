import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuthUser, errorResponse, validateBody } from "@/lib/api-helpers";
import { generateAiAnalysis, getAiSettings } from "@/lib/ai/analysisService";
import { generateAiAnalysisSchema } from "@/lib/validations";
import { Role, AssessmentStatus } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/results/[id]/ai-analysis
 * Returns the active AI analysis for a completed assessment, or null if none exists.
 * Respects existing access-control patterns.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    const { id: assessmentId } = await context.params;

    // Verify assessment exists and user has access
    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
      select: { id: true, status: true, profileId: true, createdById: true },
    });

    if (!assessment) return errorResponse("Assessment not found", 404);

    // Access check
    if (user.role === Role.ASSESSOR) {
      const isCreator = assessment.createdById === user.id;
      if (!isCreator) {
        const assigned = await prisma.assessorAssignment.findFirst({
          where: { assessorId: user.id, profileId: assessment.profileId },
        });
        if (!assigned) return errorResponse("Forbidden", 403);
      }
    } else if (user.role === Role.CUSTOMER) {
      const access = await prisma.userCustomerAccess.findFirst({
        where: { userId: user.id, profileId: assessment.profileId },
      });
      if (!access) return errorResponse("Forbidden", 403);
    }

    const analysis = await prisma.aiAnalysis.findFirst({
      where: { assessmentId, isActive: true, status: "success" },
      orderBy: { versionNumber: "desc" },
      include: { generatedBy: { select: { name: true } } },
    });

    if (!analysis) {
      // Also return AI enabled status so UI knows whether to show Generate button
      const aiSettings = await getAiSettings();
      return NextResponse.json({
        data: null,
        aiEnabled: aiSettings?.isEnabled ?? false,
      });
    }

    return NextResponse.json({
      data: {
        id: analysis.id,
        assessmentId: analysis.assessmentId,
        versionNumber: analysis.versionNumber,
        generatedById: analysis.generatedById,
        generatedByName: analysis.generatedBy?.name ?? null,
        generationMode: analysis.generationMode,
        provider: analysis.provider,
        modelUsed: analysis.modelUsed,
        deploymentUsed: analysis.deploymentUsed,
        currentState: analysis.currentState,
        immediateActions: analysis.immediateActions,
        mediumTermActions: analysis.mediumTermActions,
        longTermActions: analysis.longTermActions,
        deduplicationApplied: analysis.deduplicationApplied,
        deduplicationSummary: analysis.deduplicationSummary,
        status: analysis.status,
        tokenCount: analysis.tokenCount,
        isActive: analysis.isActive,
        createdAt: analysis.createdAt,
      },
      aiEnabled: true,
    });
  } catch (error) {
    console.error("[GET /api/results/[id]/ai-analysis]", error);
    return errorResponse(error instanceof Error ? error.message : "Internal server error", 500);
  }
}

/**
 * POST /api/results/[id]/ai-analysis
 * Generates (or regenerates) AI analysis for a completed assessment.
 * ADMIN and ASSESSOR only.
 */
export async function POST(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    // Only ADMIN and ASSESSOR can trigger generation
    if (user.role === Role.CUSTOMER) {
      return errorResponse("Forbidden", 403);
    }

    const { id: assessmentId } = await context.params;

    const { data: body, error: validationError } = await validateBody(req, generateAiAnalysisSchema);
    if (validationError) return validationError;

    // Verify assessment exists and is completed
    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
      select: { status: true, profileId: true, createdById: true },
    });

    if (!assessment) return errorResponse("Assessment not found", 404);
    if (assessment.status !== AssessmentStatus.COMPLETED) {
      return errorResponse("AI analysis can only be generated for completed assessments", 400);
    }

    // Access check for ASSESSOR
    if (user.role === Role.ASSESSOR) {
      const isCreator = assessment.createdById === user.id;
      if (!isCreator) {
        const assigned = await prisma.assessorAssignment.findFirst({
          where: { assessorId: user.id, profileId: assessment.profileId },
        });
        if (!assigned) return errorResponse("Forbidden", 403);
      }
    }

    // Check for existing analysis to determine mode
    const existingActive = await prisma.aiAnalysis.findFirst({
      where: { assessmentId, isActive: true },
    });
    const mode = existingActive ? "regenerated" : (body.mode ?? "manual");

    const result = await generateAiAnalysis({
      assessmentId,
      triggeredByUserId: user.id,
      mode,
    });

    if (!result) {
      return errorResponse("AI analysis is disabled or not configured. Please contact your administrator.", 400);
    }

    return NextResponse.json({ data: result }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/results/[id]/ai-analysis]", error);
    return errorResponse(error instanceof Error ? error.message : "Internal server error", 500);
  }
}
