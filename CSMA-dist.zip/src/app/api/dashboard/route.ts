import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuthUser, errorResponse } from "@/lib/api-helpers";
import { Role, AssessmentStatus } from "@prisma/client";
import type { DashboardStats } from "@/types";

/**
 * GET /api/dashboard
 * Returns role-aware dashboard statistics.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireAuthUser();
    if (user instanceof NextResponse) return user;

    // ── Build WHERE clauses based on role ────────────────────────────────────
    let assessmentWhere: Record<string, unknown> = {};
    let profileWhere: Record<string, unknown> = {};

    if (user.role === Role.ASSESSOR) {
      // Assessors see profiles they are assigned to and assessments they created
      const assignedProfiles = await prisma.assessorAssignment.findMany({
        where: { assessorId: user.id },
        select: { profileId: true },
      });
      const profileIds = assignedProfiles.map((a) => a.profileId);

      assessmentWhere = {
        OR: [{ createdById: user.id }, { profileId: { in: profileIds } }],
      };
      profileWhere = { id: { in: profileIds } };
    } else if (user.role === Role.CUSTOMER) {
      // Customers see only their own linked profiles
      const access = await prisma.userCustomerAccess.findMany({
        where: { userId: user.id },
        select: { profileId: true },
      });
      const profileIds = access.map((a) => a.profileId);

      assessmentWhere = { profileId: { in: profileIds } };
      profileWhere = { id: { in: profileIds } };
    }
    // ADMIN: no filter — sees everything

    // ── Counts ───────────────────────────────────────────────────────────────
    const [totalAssessments, totalProfiles, totalTemplates] = await Promise.all([
      prisma.assessment.count({ where: assessmentWhere }),
      prisma.customerProfile.count({ where: profileWhere }),
      user.role === Role.CUSTOMER
        ? Promise.resolve(0)
        : prisma.template.count(),
    ]);

    // ── Average overall score for completed assessments ───────────────────────
    const avgResult = await prisma.assessment.aggregate({
      where: {
        ...assessmentWhere,
        status: AssessmentStatus.COMPLETED,
        overallScore: { not: null },
      },
      _avg: { overallScore: true },
    });
    const averageScore = avgResult._avg.overallScore ?? 0;

    // ── Completion breakdown ──────────────────────────────────────────────────
    const statusGroups = await prisma.assessment.groupBy({
      by: ["status"],
      where: assessmentWhere,
      _count: { _all: true },
    });

    const completionBreakdown: DashboardStats["completionBreakdown"] = {
      DRAFT: 0,
      IN_PROGRESS: 0,
      COMPLETED: 0,
      ARCHIVED: 0,
    };
    for (const g of statusGroups) {
      completionBreakdown[g.status as keyof typeof completionBreakdown] =
        g._count._all;
    }

    // ── Domain scores (avg across completed assessments) ─────────────────────
    const completedIds = await prisma.assessment.findMany({
      where: { ...assessmentWhere, status: AssessmentStatus.COMPLETED },
      select: { id: true },
    });
    const completedAssessmentIds = completedIds.map((a) => a.id);

    const domainAggregates = await prisma.domainScore.groupBy({
      by: ["domain"],
      where: { assessmentId: { in: completedAssessmentIds } },
      _avg: { percentage: true, score: true, maxScore: true },
    });

    const domainScores: DashboardStats["domainScores"] = domainAggregates.map(
      (d) => ({
        domain: d.domain,
        score: d._avg.score ?? 0,
        maxScore: d._avg.maxScore ?? 0,
        percentage: d._avg.percentage ?? 0,
      })
    );

    // ── Recent assessments (last 10) ──────────────────────────────────────────
    const recentRaw = await prisma.assessment.findMany({
      where: assessmentWhere,
      orderBy: { createdAt: "desc" },
      take: 10,
      select: {
        id: true,
        title: true,
        status: true,
        overallScore: true,
        createdAt: true,
        updatedAt: true,
        profile: { select: { name: true } },
      },
    });

    const recentAssessments: DashboardStats["recentAssessments"] =
      recentRaw.map((a) => ({
        id: a.id,
        title: a.title,
        profileName: a.profile.name,
        status: a.status,
        overallScore: a.overallScore,
        createdAt: a.createdAt,
        updatedAt: a.updatedAt,
      }));

    // ── Attention items ───────────────────────────────────────────────────────
    // Drafts older than 7 days or completed with score < 40%
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    const attentionRaw = await prisma.assessment.findMany({
      where: {
        ...assessmentWhere,
        OR: [
          // Stale drafts
          {
            status: AssessmentStatus.DRAFT,
            createdAt: { lt: sevenDaysAgo },
          },
          // In-progress older than 7 days
          {
            status: AssessmentStatus.IN_PROGRESS,
            updatedAt: { lt: sevenDaysAgo },
          },
          // Completed with low score
          {
            status: AssessmentStatus.COMPLETED,
            overallScore: { not: null },
          },
        ],
      },
      select: {
        id: true,
        title: true,
        status: true,
        dueDate: true,
        overallScore: true,
        createdAt: true,
        updatedAt: true,
        profile: { select: { name: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 20,
    });

    const attentionItems: DashboardStats["attentionItems"] = attentionRaw
      .filter((a) => {
        if (
          a.status === AssessmentStatus.DRAFT &&
          a.createdAt < sevenDaysAgo
        ) {
          return true;
        }
        if (
          a.status === AssessmentStatus.IN_PROGRESS &&
          a.updatedAt < sevenDaysAgo
        ) {
          return true;
        }
        if (
          a.status === AssessmentStatus.COMPLETED &&
          a.overallScore !== null &&
          a.overallScore < 40
        ) {
          return true;
        }
        return false;
      })
      .map((a) => {
        let reason = "";
        if (
          a.status === AssessmentStatus.DRAFT &&
          a.createdAt < sevenDaysAgo
        ) {
          reason = "Draft assessment older than 7 days";
        } else if (
          a.status === AssessmentStatus.IN_PROGRESS &&
          a.updatedAt < sevenDaysAgo
        ) {
          reason = "In-progress assessment not updated in 7 days";
        } else if (
          a.status === AssessmentStatus.COMPLETED &&
          a.overallScore !== null &&
          a.overallScore < 40
        ) {
          reason = `Low maturity score: ${a.overallScore.toFixed(1)}%`;
        }
        return {
          id: a.id,
          title: a.title,
          profileName: a.profile.name,
          status: a.status,
          dueDate: a.dueDate,
          overallScore: a.overallScore,
          reason,
        };
      });

    const stats: DashboardStats = {
      totalAssessments,
      totalProfiles,
      totalTemplates,
      averageScore,
      completionBreakdown,
      domainScores,
      recentAssessments,
      attentionItems,
    };

    return NextResponse.json({ data: stats });
  } catch (error) {
    console.error("[GET /api/dashboard]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
