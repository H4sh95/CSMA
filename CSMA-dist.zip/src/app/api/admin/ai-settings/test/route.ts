import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, errorResponse } from "@/lib/api-helpers";
import { decrypt, isEncrypted } from "@/lib/ai/encryption";
import { testAzureConnection } from "@/lib/ai/azureOpenAiClient";
import { Role } from "@prisma/client";

/**
 * POST /api/admin/ai-settings/test
 * Tests the current Azure OpenAI configuration. ADMIN only.
 * Returns { ok: boolean, message: string }.
 */
export async function POST(_req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const settings = await prisma.aiSettings.findFirst({ orderBy: { createdAt: "asc" } });

    if (!settings) {
      return NextResponse.json({ data: { ok: false, message: "AI settings have not been configured yet." } });
    }
    if (!settings.isEnabled) {
      return NextResponse.json({ data: { ok: false, message: "AI analysis is currently disabled." } });
    }
    if (!settings.endpoint || !settings.deployment || !settings.encryptedApiKey) {
      return NextResponse.json({
        data: { ok: false, message: "Missing required fields: endpoint, deployment, and API key must all be set." },
      });
    }

    let apiKey: string;
    try {
      apiKey = isEncrypted(settings.encryptedApiKey)
        ? decrypt(settings.encryptedApiKey)
        : settings.encryptedApiKey;
    } catch {
      return NextResponse.json({ data: { ok: false, message: "Failed to decrypt API key. Please re-enter the key." } });
    }

    const result = await testAzureConnection({
      endpoint: settings.endpoint,
      deployment: settings.deployment,
      apiKey,
    });

    return NextResponse.json({ data: result });
  } catch (error) {
    console.error("[POST /api/admin/ai-settings/test]", error);
    return errorResponse(error instanceof Error ? error.message : "Internal server error", 500);
  }
}
