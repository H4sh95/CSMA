import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, errorResponse, validateBody, getRequestMeta } from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { updateAiSettingsSchema } from "@/lib/validations";
import { encrypt } from "@/lib/ai/encryption";
import { getAiSettings } from "@/lib/ai/analysisService";
import { Role } from "@prisma/client";

/**
 * GET /api/admin/ai-settings
 * Returns AI settings with API key masked. ADMIN only.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const settings = await getAiSettings();
    return NextResponse.json({ data: settings });
  } catch (error) {
    console.error("[GET /api/admin/ai-settings]", error);
    return errorResponse(error instanceof Error ? error.message : "Internal server error", 500);
  }
}

/**
 * PUT /api/admin/ai-settings
 * Creates or updates AI settings. ADMIN only.
 * The API key is encrypted at rest. Send null/omit to keep existing key.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const { data: body, error: validationError } = await validateBody(req, updateAiSettingsSchema);
    if (validationError) return validationError;

    // Load existing settings to preserve encrypted key if not being changed
    const existing = await prisma.aiSettings.findFirst({ orderBy: { createdAt: "asc" } });

    let encryptedApiKey = existing?.encryptedApiKey ?? null;
    if (body.apiKey && body.apiKey.trim().length > 0) {
      encryptedApiKey = encrypt(body.apiKey.trim());
    }

    const wasEnabled = existing?.isEnabled ?? false;
    const nowEnabled = body.isEnabled;

    const settings = existing
      ? await prisma.aiSettings.update({
          where: { id: existing.id },
          data: {
            isEnabled: body.isEnabled,
            endpoint: body.endpoint ?? null,
            deployment: body.deployment ?? null,
            model: body.model ?? null,
            encryptedApiKey,
            systemPromptTemplate: body.systemPromptTemplate ?? null,
            recommendationStyle: body.recommendationStyle ?? "detailed",
            maxTokens: body.maxTokens ?? 2000,
            temperature: body.temperature ?? 0.3,
            includeAssessorComments: body.includeAssessorComments ?? true,
            includeHistorical: body.includeHistorical ?? false,
            updatedById: user.id,
          },
        })
      : await prisma.aiSettings.create({
          data: {
            isEnabled: body.isEnabled,
            endpoint: body.endpoint ?? null,
            deployment: body.deployment ?? null,
            model: body.model ?? null,
            encryptedApiKey,
            systemPromptTemplate: body.systemPromptTemplate ?? null,
            recommendationStyle: body.recommendationStyle ?? "detailed",
            maxTokens: body.maxTokens ?? 2000,
            temperature: body.temperature ?? 0.3,
            includeAssessorComments: body.includeAssessorComments ?? true,
            includeHistorical: body.includeHistorical ?? false,
            updatedById: user.id,
          },
        });

    const { ipAddress, userAgent } = getRequestMeta(req);

    // Log enable/disable toggle separately for clear audit trail
    if (!wasEnabled && nowEnabled) {
      await auditLog({ userId: user.id, action: "AI_SETTINGS_ENABLED", entityType: "AiSettings", entityId: settings.id, ipAddress, userAgent });
    } else if (wasEnabled && !nowEnabled) {
      await auditLog({ userId: user.id, action: "AI_SETTINGS_DISABLED", entityType: "AiSettings", entityId: settings.id, ipAddress, userAgent });
    }
    await auditLog({
      userId: user.id,
      action: "AI_SETTINGS_UPDATED",
      entityType: "AiSettings",
      entityId: settings.id,
      details: {
        isEnabled: body.isEnabled,
        endpoint: body.endpoint ?? null,
        deployment: body.deployment ?? null,
        model: body.model ?? null,
        apiKeyChanged: !!(body.apiKey && body.apiKey.trim().length > 0),
        recommendationStyle: body.recommendationStyle,
        maxTokens: body.maxTokens,
        temperature: body.temperature,
      },
      ipAddress,
      userAgent,
    });

    // Return masked settings (same as GET)
    const masked = await getAiSettings();
    return NextResponse.json({ data: masked });
  } catch (error) {
    console.error("[PUT /api/admin/ai-settings]", error);
    return errorResponse(error instanceof Error ? error.message : "Internal server error", 500);
  }
}
