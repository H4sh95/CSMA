import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  validateBody,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { updateSettingsSchema } from "@/lib/validations";
import { Role } from "@prisma/client";

/**
 * GET /api/admin/settings
 * Returns all system settings as key-value pairs. Requires ADMIN.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const settings = await prisma.systemSetting.findMany({
      orderBy: { key: "asc" },
    });

    // Return as a flat key-value map for convenience
    const settingsMap = Object.fromEntries(
      settings.map((s) => [s.key, s.value])
    );

    return NextResponse.json({
      data: {
        settings: settingsMap,
        list: settings,
      },
    });
  } catch (error) {
    console.error("[GET /api/admin/settings]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * PUT /api/admin/settings
 * Creates or updates one or more system settings. Requires ADMIN.
 * Body: { settings: [{ key: string, value: string }] }
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { data: body, error: validationError } = await validateBody(
      req,
      updateSettingsSchema
    );
    if (validationError) return validationError;

    // Upsert each setting in a transaction
    const upserted = await prisma.$transaction(
      body.settings.map((s) =>
        prisma.systemSetting.upsert({
          where: { key: s.key },
          update: { value: s.value },
          create: { key: s.key, value: s.value },
        })
      )
    );

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: admin.id,
      action: "SETTINGS_UPDATED",
      entityType: "SystemSetting",
      details: {
        updatedKeys: body.settings.map((s) => s.key),
        count: body.settings.length,
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: upserted });
  } catch (error) {
    console.error("[PUT /api/admin/settings]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
