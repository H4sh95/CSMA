import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  paginatedResponse,
  getPaginationParams,
  getSearchParam,
} from "@/lib/api-helpers";
import { Role, AuditAction } from "@prisma/client";

/**
 * GET /api/admin/audit-logs
 * Lists audit log entries with pagination and filters. Requires ADMIN.
 * Filters: userId, action, entityType, dateFrom, dateTo.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { searchParams } = new URL(req.url);
    const { page, pageSize, skip } = getPaginationParams(searchParams);
    const filterUserId = getSearchParam(searchParams, "userId");
    const filterAction = getSearchParam(searchParams, "action") as
      | AuditAction
      | undefined;
    const entityType = getSearchParam(searchParams, "entityType");
    const entityId = getSearchParam(searchParams, "entityId");
    const dateFrom = searchParams.get("dateFrom");
    const dateTo = searchParams.get("dateTo");
    const search = getSearchParam(searchParams, "search");

    const andClauses: Record<string, unknown>[] = [];

    if (filterUserId) andClauses.push({ userId: filterUserId });

    if (filterAction && Object.values(AuditAction).includes(filterAction)) {
      andClauses.push({ action: filterAction });
    }

    if (entityType) andClauses.push({ entityType });
    if (entityId) andClauses.push({ entityId });

    if (dateFrom) {
      const from = new Date(dateFrom);
      if (!isNaN(from.getTime())) andClauses.push({ createdAt: { gte: from } });
    }
    if (dateTo) {
      const to = new Date(dateTo);
      if (!isNaN(to.getTime())) andClauses.push({ createdAt: { lte: to } });
    }

    // Search by user name or email
    if (search) {
      andClauses.push({
        OR: [
          { user: { name: { contains: search, mode: "insensitive" } } },
          { user: { email: { contains: search, mode: "insensitive" } } },
          { entityType: { contains: search, mode: "insensitive" } },
        ],
      });
    }

    const where = andClauses.length > 0 ? { AND: andClauses } : {};

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        skip,
        take: pageSize,
        orderBy: { createdAt: "desc" },
        include: {
          user: {
            select: { id: true, name: true, email: true, role: true },
          },
        },
      }),
      prisma.auditLog.count({ where }),
    ]);

    return paginatedResponse(logs, total, page, pageSize);
  } catch (error) {
    console.error("[GET /api/admin/audit-logs]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
