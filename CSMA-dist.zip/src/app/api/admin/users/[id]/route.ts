import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  validateBody,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { updateUserSchema } from "@/lib/validations";
import { Role } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

// Password reset is handled in /api/admin/users/[id]/reset-password/route.ts

/**
 * GET /api/admin/users/[id]
 * Returns a single user with customer access mappings. Requires ADMIN.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { id } = await context.params;

    const user = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
        updatedAt: true,
        customerAccess: {
          include: {
            profile: {
              select: {
                id: true,
                name: true,
                identifier: true,
                status: true,
                industry: true,
              },
            },
          },
        },
        assessorAssignments: {
          include: {
            profile: {
              select: {
                id: true,
                name: true,
                identifier: true,
                status: true,
              },
            },
          },
        },
        _count: {
          select: {
            createdAssessments: true,
            uploadedTemplates: true,
            createdProfiles: true,
          },
        },
      },
    });

    if (!user) return errorResponse("User not found", 404);

    return NextResponse.json({ data: user });
  } catch (error) {
    console.error("[GET /api/admin/users/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * PUT /api/admin/users/[id]
 * Updates user name, email, role, or isActive status. Requires ADMIN.
 */
export async function PUT(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { id } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      updateUserSchema
    );
    if (validationError) return validationError;

    const existing = await prisma.user.findUnique({ where: { id } });
    if (!existing) return errorResponse("User not found", 404);

    // Prevent admin from accidentally de-activating themselves
    if (id === admin.id && body.isActive === false) {
      return errorResponse("Admins cannot deactivate their own account", 400);
    }

    // Check email uniqueness if changing email
    if (body.email && body.email !== existing.email) {
      const conflict = await prisma.user.findUnique({
        where: { email: body.email.toLowerCase().trim() },
      });
      if (conflict) {
        return errorResponse(
          `Email "${body.email}" is already in use`,
          409
        );
      }
    }

    const updated = await prisma.user.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name.trim() }),
        ...(body.email !== undefined && {
          email: body.email.toLowerCase().trim(),
        }),
        ...(body.role !== undefined && { role: body.role }),
        ...(body.isActive !== undefined && { isActive: body.isActive }),
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);

    // Determine the most specific audit action
    let auditAction: "USER_UPDATED" | "USER_DISABLED" | "USER_ENABLED" | "ROLE_CHANGED" =
      "USER_UPDATED";
    if (body.isActive === false) auditAction = "USER_DISABLED";
    else if (body.isActive === true) auditAction = "USER_ENABLED";
    else if (body.role && body.role !== existing.role) auditAction = "ROLE_CHANGED";

    await auditLog({
      userId: admin.id,
      action: auditAction,
      entityType: "User",
      entityId: id,
      details: {
        changes: body,
        previousRole: existing.role,
        previousIsActive: existing.isActive,
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: updated });
  } catch (error) {
    console.error("[PUT /api/admin/users/[id]]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

