import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { Role } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

const BCRYPT_ROUNDS = 12;

/** Generates a random temporary password (16 chars, alphanumeric + specials). */
function generateTempPassword(): string {
  const chars =
    "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%^&*";
  let result = "";
  for (let i = 0; i < 16; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * POST /api/admin/users/[id]/reset-password
 * Generates a temporary password, hashes it, stores it, and returns the
 * plain-text temporary password to the admin. Requires ADMIN.
 */
export async function POST(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { id } = await context.params;

    const target = await prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true, name: true, isActive: true },
    });
    if (!target) return errorResponse("User not found", 404);
    if (!target.isActive) {
      return errorResponse("Cannot reset password for a disabled account", 400);
    }

    const tempPassword = generateTempPassword();
    const passwordHash = await bcrypt.hash(tempPassword, BCRYPT_ROUNDS);

    await prisma.user.update({
      where: { id },
      data: { passwordHash },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: admin.id,
      action: "PASSWORD_RESET",
      entityType: "User",
      entityId: id,
      details: { targetEmail: target.email, targetName: target.name },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({
      data: {
        userId: id,
        email: target.email,
        temporaryPassword: tempPassword,
        message:
          "Password has been reset. Share the temporary password securely. The user should change it immediately after next login.",
      },
    });
  } catch (error) {
    console.error("[POST /api/admin/users/[id]/reset-password]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
