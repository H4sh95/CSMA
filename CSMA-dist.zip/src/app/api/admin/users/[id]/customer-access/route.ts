import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  validateBody,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import {
  addCustomerAccessSchema,
  removeCustomerAccessSchema,
} from "@/lib/validations";
import { Role } from "@prisma/client";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/admin/users/[id]/customer-access
 * Lists all customer profiles linked to this user. Requires ADMIN.
 */
export async function GET(
  _req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { id: userId } = await context.params;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, email: true },
    });
    if (!user) return errorResponse("User not found", 404);

    const access = await prisma.userCustomerAccess.findMany({
      where: { userId },
      include: {
        profile: {
          select: {
            id: true,
            name: true,
            identifier: true,
            industry: true,
            region: true,
            status: true,
            createdAt: true,
          },
        },
      },
      orderBy: { createdAt: "asc" },
    });

    return NextResponse.json({ data: access });
  } catch (error) {
    console.error("[GET /api/admin/users/[id]/customer-access]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * POST /api/admin/users/[id]/customer-access
 * Links a user to a customer profile. Requires ADMIN.
 * Body: { profileId: string }
 */
export async function POST(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { id: userId } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      addCustomerAccessSchema
    );
    if (validationError) return validationError;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, email: true, role: true, isActive: true },
    });
    if (!user) return errorResponse("User not found", 404);
    if (!user.isActive) {
      return errorResponse("Cannot grant access to a disabled user account", 400);
    }

    const profile = await prisma.customerProfile.findUnique({
      where: { id: body.profileId },
      select: { id: true, name: true, identifier: true },
    });
    if (!profile) return errorResponse("Profile not found", 404);

    // Upsert to prevent duplicate access records
    const access = await prisma.userCustomerAccess.upsert({
      where: {
        userId_profileId: { userId, profileId: body.profileId },
      },
      update: {},
      create: { userId, profileId: body.profileId },
      include: {
        profile: {
          select: { id: true, name: true, identifier: true, status: true },
        },
      },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: admin.id,
      action: "USER_UPDATED",
      entityType: "UserCustomerAccess",
      entityId: access.id,
      details: {
        targetUserId: userId,
        targetUserEmail: user.email,
        profileId: body.profileId,
        profileName: profile.name,
        action: "access_granted",
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: access }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/admin/users/[id]/customer-access]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * DELETE /api/admin/users/[id]/customer-access
 * Removes a user's access to a customer profile. Requires ADMIN.
 * Body: { profileId: string }
 */
export async function DELETE(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  try {
    const admin = await requireRole([Role.ADMIN]);
    if (admin instanceof NextResponse) return admin;

    const { id: userId } = await context.params;

    const { data: body, error: validationError } = await validateBody(
      req,
      removeCustomerAccessSchema
    );
    if (validationError) return validationError;

    const access = await prisma.userCustomerAccess.findUnique({
      where: {
        userId_profileId: { userId, profileId: body.profileId },
      },
    });
    if (!access) return errorResponse("Access record not found", 404);

    await prisma.userCustomerAccess.delete({ where: { id: access.id } });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: admin.id,
      action: "USER_UPDATED",
      entityType: "UserCustomerAccess",
      entityId: access.id,
      details: {
        targetUserId: userId,
        profileId: body.profileId,
        action: "access_revoked",
      },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: { removed: true } });
  } catch (error) {
    console.error("[DELETE /api/admin/users/[id]/customer-access]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
