import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import {
  requireRole,
  errorResponse,
  paginatedResponse,
  validateBody,
  getPaginationParams,
  getSearchParam,
  getRequestMeta,
} from "@/lib/api-helpers";
import { auditLog } from "@/lib/audit";
import { createUserSchema } from "@/lib/validations";
import { Role } from "@prisma/client";

const BCRYPT_ROUNDS = 12;

/**
 * GET /api/admin/users
 * Lists all users with pagination and search. Requires ADMIN.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    const user = await requireRole([Role.ADMIN]);
    if (user instanceof NextResponse) return user;

    const { searchParams } = new URL(req.url);
    const { page, pageSize, skip } = getPaginationParams(searchParams);
    const search = getSearchParam(searchParams, "search");
    const roleParam = getSearchParam(searchParams, "role") as Role | undefined;
    const isActiveParam = searchParams.get("isActive");

    const andClauses: Record<string, unknown>[] = [];

    if (search) {
      andClauses.push({
        OR: [
          { name: { contains: search, mode: "insensitive" } },
          { email: { contains: search, mode: "insensitive" } },
        ],
      });
    }

    if (roleParam && Object.values(Role).includes(roleParam)) {
      andClauses.push({ role: roleParam });
    }

    if (isActiveParam === "true") andClauses.push({ isActive: true });
    if (isActiveParam === "false") andClauses.push({ isActive: false });

    const where = andClauses.length > 0 ? { AND: andClauses } : {};

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: pageSize,
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          email: true,
          name: true,
          role: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
          _count: {
            select: {
              customerAccess: true,
              assessorAssignments: true,
              createdAssessments: true,
            },
          },
        },
      }),
      prisma.user.count({ where }),
    ]);

    return paginatedResponse(users, total, page, pageSize);
  } catch (error) {
    console.error("[GET /api/admin/users]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}

/**
 * POST /api/admin/users
 * Creates a new user with a hashed password. Requires ADMIN.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const adminUser = await requireRole([Role.ADMIN]);
    if (adminUser instanceof NextResponse) return adminUser;

    const { data: body, error: validationError } = await validateBody(
      req,
      createUserSchema
    );
    if (validationError) return validationError;

    // Check email uniqueness
    const existing = await prisma.user.findUnique({
      where: { email: body.email.toLowerCase().trim() },
    });
    if (existing) {
      return errorResponse(
        `A user with email "${body.email}" already exists`,
        409
      );
    }

    const passwordHash = await bcrypt.hash(body.password, BCRYPT_ROUNDS);

    const newUser = await prisma.user.create({
      data: {
        email: body.email.toLowerCase().trim(),
        name: body.name.trim(),
        passwordHash,
        role: body.role,
        isActive: true,
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    const { ipAddress, userAgent } = getRequestMeta(req);
    await auditLog({
      userId: adminUser.id,
      action: "USER_CREATED",
      entityType: "User",
      entityId: newUser.id,
      details: { email: newUser.email, name: newUser.name, role: newUser.role },
      ipAddress,
      userAgent,
    });

    return NextResponse.json({ data: newUser }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/admin/users]", error);
    return errorResponse(
      error instanceof Error ? error.message : "Internal server error",
      500
    );
  }
}
