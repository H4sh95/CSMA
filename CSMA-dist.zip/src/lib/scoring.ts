import type { ScoreResult, DomainScoreMap, CategoryScoreMap } from "@/types";

export interface ResponseInput {
  templateItemId: string;
  score: number | null;
  isAnswered: boolean;
}

export interface TemplateItemInput {
  id: string;
  domain: string;
  category: string;
  scoring: number; // max score for this item
}

/**
 * Pure scoring engine — no DB calls. Takes items and responses as input.
 * @param excludedDomains  Domain names to skip entirely (not counted in score or totals).
 */
export function calculateScores(
  items: TemplateItemInput[],
  responses: ResponseInput[],
  excludedDomains: string[] = []
): ScoreResult {
  // Remove excluded domains before any processing
  if (excludedDomains.length > 0) {
    const excluded = new Set(excludedDomains);
    items = items.filter((i) => !excluded.has(i.domain));
  }

  // Build response lookup map by templateItemId
  const responseMap = new Map<string, ResponseInput>();
  for (const response of responses) {
    responseMap.set(response.templateItemId, response);
  }

  // Aggregation accumulators
  let totalMaxScore = 0;
  let totalActualScore = 0;
  let totalItems = items.length;
  let answeredItems = 0;

  // Domain accumulators: domain -> { score, maxScore, itemCount, answeredCount }
  const domainAccum = new Map<
    string,
    { score: number; maxScore: number; itemCount: number; answeredCount: number }
  >();

  // Category accumulators: domain -> category -> { ... }
  const categoryAccum = new Map<
    string,
    Map<
      string,
      { score: number; maxScore: number; itemCount: number; answeredCount: number }
    >
  >();

  for (const item of items) {
    const response = responseMap.get(item.id);
    const isAnswered = response?.isAnswered === true && response?.score !== null;
    const actualScore = isAnswered ? (response!.score as number) : 0;

    totalMaxScore += item.scoring;
    totalActualScore += actualScore;
    if (isAnswered) answeredItems++;

    // Domain accumulation
    if (!domainAccum.has(item.domain)) {
      domainAccum.set(item.domain, {
        score: 0,
        maxScore: 0,
        itemCount: 0,
        answeredCount: 0,
      });
    }
    const da = domainAccum.get(item.domain)!;
    da.score += actualScore;
    da.maxScore += item.scoring;
    da.itemCount++;
    if (isAnswered) da.answeredCount++;

    // Category accumulation
    if (!categoryAccum.has(item.domain)) {
      categoryAccum.set(item.domain, new Map());
    }
    const catMap = categoryAccum.get(item.domain)!;
    if (!catMap.has(item.category)) {
      catMap.set(item.category, {
        score: 0,
        maxScore: 0,
        itemCount: 0,
        answeredCount: 0,
      });
    }
    const ca = catMap.get(item.category)!;
    ca.score += actualScore;
    ca.maxScore += item.scoring;
    ca.itemCount++;
    if (isAnswered) ca.answeredCount++;
  }

  // Build domain scores map
  const domainScores: DomainScoreMap = {};
  for (const [domain, da] of domainAccum.entries()) {
    domainScores[domain] = {
      score: da.score,
      maxScore: da.maxScore,
      percentage:
        da.maxScore > 0 ? (da.score / da.maxScore) * 100 : 0,
      itemCount: da.itemCount,
      answeredCount: da.answeredCount,
    };
  }

  // Build category scores map
  const categoryScores: CategoryScoreMap = {};
  for (const [domain, catMap] of categoryAccum.entries()) {
    categoryScores[domain] = {};
    for (const [category, ca] of catMap.entries()) {
      categoryScores[domain][category] = {
        score: ca.score,
        maxScore: ca.maxScore,
        percentage:
          ca.maxScore > 0 ? (ca.score / ca.maxScore) * 100 : 0,
        itemCount: ca.itemCount,
        answeredCount: ca.answeredCount,
      };
    }
  }

  const overallScore = totalActualScore;
  const overallPercentage =
    totalMaxScore > 0 ? (totalActualScore / totalMaxScore) * 100 : 0;
  const completionPercentage =
    totalItems > 0 ? (answeredItems / totalItems) * 100 : 0;

  return {
    overallScore,
    overallPercentage,
    domainScores,
    categoryScores,
    totalItems,
    answeredItems,
    completionPercentage,
  };
}

/**
 * Returns a human-readable maturity label for a given percentage score.
 * 0-20: Critical, 21-40: Low, 41-60: Moderate, 61-80: Good, 81-100: Excellent
 */
export function getScoreLabel(percentage: number): string {
  if (percentage <= 20) return "Critical";
  if (percentage <= 40) return "Low";
  if (percentage <= 60) return "Moderate";
  if (percentage <= 80) return "Good";
  return "Excellent";
}

/**
 * Returns a Tailwind CSS color class for a given percentage score.
 */
export function getScoreColor(percentage: number): string {
  if (percentage <= 20) return "red-500";
  if (percentage <= 40) return "orange-500";
  if (percentage <= 60) return "yellow-500";
  if (percentage <= 80) return "green-500";
  return "emerald-500";
}
