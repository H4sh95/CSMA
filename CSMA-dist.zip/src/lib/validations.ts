import { z } from "zod";
import { Role, ProfileStatus, TemplateStatus, AssessmentStatus } from "@prisma/client";

// ─── Auth ─────────────────────────────────────────────────────────────────────

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

// ─── Customer Profile ─────────────────────────────────────────────────────────

export const createProfileSchema = z.object({
  name: z
    .string()
    .min(2, "Name must be at least 2 characters")
    .max(255, "Name must not exceed 255 characters")
    .trim(),
  identifier: z
    .string()
    .min(2, "Identifier must be at least 2 characters")
    .max(100, "Identifier must not exceed 100 characters")
    .trim()
    .regex(
      /^[a-zA-Z0-9_\-]+$/,
      "Identifier may only contain letters, numbers, underscores, and hyphens"
    ),
  industry: z.string().max(255).trim().optional().nullable(),
  region: z.string().max(255).trim().optional().nullable(),
  country: z.string().max(255).trim().optional().nullable(),
  primaryContact: z.string().max(255).trim().optional().nullable(),
  primaryEmail: z
    .string()
    .email("Must be a valid email address")
    .max(255)
    .trim()
    .optional()
    .nullable()
    .or(z.literal("")),
  notes: z.string().max(5000).trim().optional().nullable(),
  status: z.nativeEnum(ProfileStatus).optional().default(ProfileStatus.ACTIVE),
});

export const updateProfileSchema = createProfileSchema.partial();

// ─── Assessor Assignment ──────────────────────────────────────────────────────

export const assignAssessorSchema = z.object({
  assessorId: z.string().min(1, "Assessor ID is required"),
});

export const removeAssessorSchema = z.object({
  assessorId: z.string().min(1, "Assessor ID is required"),
});

// ─── Template ─────────────────────────────────────────────────────────────────

export const createTemplateSchema = z.object({
  name: z
    .string()
    .min(2, "Template name must be at least 2 characters")
    .max(150, "Template name must not exceed 150 characters")
    .trim(),
  version: z
    .string()
    .min(1, "Version is required")
    .max(20, "Version must not exceed 20 characters")
    .trim()
    .default("1.0"),
  description: z
    .string()
    .max(1000, "Description must not exceed 1000 characters")
    .trim()
    .optional()
    .nullable(),
});

export const updateTemplateSchema = createTemplateSchema.partial().extend({
  status: z.nativeEnum(TemplateStatus).optional(),
});

export const updateTemplateStatusSchema = z.object({
  status: z.nativeEnum(TemplateStatus),
});

// ─── Assessment ───────────────────────────────────────────────────────────────

export const createAssessmentSchema = z.object({
  title: z
    .string()
    .min(2, "Title must be at least 2 characters")
    .max(200, "Title must not exceed 200 characters")
    .trim(),
  profileId: z.string().min(1, "Profile ID is required"),
  templateId: z.string().min(1, "Template ID is required"),
  dueDate: z.coerce.date().optional().nullable(),
  notes: z.string().max(5000).trim().optional().nullable(),
  // Domain names to skip during conduct and scoring.
  // Domains not in this list are fully assessed and counted.
  excludedDomains: z
    .array(z.string().min(1))
    .optional()
    .default([]),
});

export const updateAssessmentSchema = createAssessmentSchema.partial().extend({
  status: z.nativeEnum(AssessmentStatus).optional(),
});

// ─── Assessment Responses ─────────────────────────────────────────────────────

export const assessmentResponseItemSchema = z.object({
  templateItemId: z.string().min(1, "Template item ID is required"),
  score: z.number().min(0).nullable(),
  comment: z.string().max(5000).trim().optional().nullable(),
  evidenceNote: z.string().max(5000).trim().optional().nullable(),
  isAnswered: z.boolean(),
});

/** Named alias matching the spec */
export const saveResponseSchema = assessmentResponseItemSchema;

export const batchResponsesSchema = z.object({
  responses: z
    .array(assessmentResponseItemSchema)
    .min(1, "At least one response is required")
    .max(500, "Cannot save more than 500 responses in a single batch"),
});

/** Named alias matching the spec */
export const batchSaveResponsesSchema = batchResponsesSchema;

// ─── Users ────────────────────────────────────────────────────────────────────

export const createUserSchema = z.object({
  email: z
    .string()
    .email("Must be a valid email address")
    .max(255, "Email must not exceed 255 characters")
    .trim()
    .toLowerCase(),
  name: z
    .string()
    .min(2, "Name must be at least 2 characters")
    .max(100, "Name must not exceed 100 characters")
    .trim(),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .max(128, "Password must not exceed 128 characters"),
  role: z.nativeEnum(Role).default(Role.CUSTOMER),
});

export const updateUserSchema = createUserSchema
  .omit({ password: true })
  .partial()
  .extend({
    isActive: z.boolean().optional(),
  });

// ─── Pagination / Filters ─────────────────────────────────────────────────────

export const paginationSchema = z.object({
  page: z.coerce
    .number()
    .int("Page must be an integer")
    .min(1, "Page must be at least 1")
    .default(1),
  pageSize: z.coerce
    .number()
    .int("Page size must be an integer")
    .min(1, "Page size must be at least 1")
    .max(100, "Page size must not exceed 100")
    .default(20),
  search: z
    .string()
    .max(200, "Search term must not exceed 200 characters")
    .trim()
    .optional(),
});

export const filterAssessmentsSchema = paginationSchema.extend({
  status: z.nativeEnum(AssessmentStatus).optional(),
  profileId: z.string().optional(),
  templateId: z.string().optional(),
  assessorId: z.string().optional(),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
  scoreMin: z.coerce.number().min(0).max(100).optional(),
  scoreMax: z.coerce.number().min(0).max(100).optional(),
});

export const filterProfilesSchema = paginationSchema.extend({
  status: z.nativeEnum(ProfileStatus).optional(),
  industry: z.string().trim().optional(),
  region: z.string().trim().optional(),
});

// ─── Customer Access ──────────────────────────────────────────────────────────

export const addCustomerAccessSchema = z.object({
  profileId: z.string().min(1, "Profile ID is required"),
});

export const removeCustomerAccessSchema = z.object({
  profileId: z.string().min(1, "Profile ID is required"),
});

// ─── System Settings ──────────────────────────────────────────────────────────

export const updateSettingsSchema = z.object({
  settings: z
    .array(
      z.object({
        key: z.string().min(1, "Key is required").max(255),
        value: z.string().max(65535),
      })
    )
    .min(1, "At least one setting is required"),
});

// ─── AI Settings ──────────────────────────────────────────────────────────────

export const updateAiSettingsSchema = z.object({
  isEnabled: z.boolean(),
  endpoint: z.string().url("Must be a valid URL").max(500).trim().optional().nullable(),
  deployment: z.string().max(200).trim().optional().nullable(),
  model: z.string().max(200).trim().optional().nullable(),
  /** Send the raw API key only when changing it; omit or send null to keep existing */
  apiKey: z.string().max(500).trim().optional().nullable(),
  systemPromptTemplate: z.string().max(10000).trim().optional().nullable(),
  recommendationStyle: z.enum(["concise", "detailed", "executive"]).optional().default("detailed"),
  maxTokens: z.coerce.number().int().min(100).max(8000).optional().default(2000),
  temperature: z.coerce.number().min(0).max(1).optional().default(0.3),
  includeAssessorComments: z.boolean().optional().default(true),
  includeHistorical: z.boolean().optional().default(false),
});

export const generateAiAnalysisSchema = z.object({
  mode: z.enum(["manual", "regenerated"]).optional().default("manual"),
});

export type UpdateAiSettingsInput = z.infer<typeof updateAiSettingsSchema>;
export type GenerateAiAnalysisInput = z.infer<typeof generateAiAnalysisSchema>;

// ─── Exported Types ───────────────────────────────────────────────────────────

export type CreateProfileInput = z.infer<typeof createProfileSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type CreateTemplateInput = z.infer<typeof createTemplateSchema>;
export type UpdateTemplateInput = z.infer<typeof updateTemplateSchema>;
export type CreateAssessmentInput = z.infer<typeof createAssessmentSchema>;
export type UpdateAssessmentInput = z.infer<typeof updateAssessmentSchema>;
export type SaveResponseInput = z.infer<typeof saveResponseSchema>;
export type BatchSaveResponsesInput = z.infer<typeof batchSaveResponsesSchema>;
export type CreateUserInput = z.infer<typeof createUserSchema>;
export type UpdateUserInput = z.infer<typeof updateUserSchema>;
export type PaginationInput = z.infer<typeof paginationSchema>;
export type FilterAssessmentsInput = z.infer<typeof filterAssessmentsSchema>;
export type FilterProfilesInput = z.infer<typeof filterProfilesSchema>;
