import { Role } from "@prisma/client";
import { prisma } from "./prisma";
import type { SessionUser } from "@/types";

/**
 * Determines whether a user can access a specific customer profile.
 *
 * Rules:
 * - ADMIN: always yes
 * - ASSESSOR: yes if they have an AssessorAssignment for this profile,
 *             OR if they have no assignments at all (unassigned assessor can see everything)
 * - CUSTOMER: yes only if they have a UserCustomerAccess record for this profile
 */
export async function canAccessProfile(
  user: SessionUser,
  profileId: string
): Promise<boolean> {
  if (user.role === Role.ADMIN) return true;

  if (user.role === Role.ASSESSOR) {
    // Check if this assessor has any assignments
    const totalAssignments = await prisma.assessorAssignment.count({
      where: { assessorId: user.id },
    });

    if (totalAssignments === 0) {
      // Unassigned assessor — can access all profiles
      return true;
    }

    // Has assignments — check if this profile is one of them
    const assignment = await prisma.assessorAssignment.findUnique({
      where: {
        assessorId_profileId: {
          assessorId: user.id,
          profileId,
        },
      },
    });

    return assignment !== null;
  }

  if (user.role === Role.CUSTOMER) {
    const access = await prisma.userCustomerAccess.findUnique({
      where: {
        userId_profileId: {
          userId: user.id,
          profileId,
        },
      },
    });

    return access !== null;
  }

  return false;
}

/**
 * Determines whether a user can view a specific assessment.
 * Access is derived from profile access — if you can see the profile, you can see its assessments.
 */
export async function canAccessAssessment(
  user: SessionUser,
  assessmentId: string
): Promise<boolean> {
  if (user.role === Role.ADMIN) return true;

  const assessment = await prisma.assessment.findUnique({
    where: { id: assessmentId },
    select: { profileId: true },
  });

  if (!assessment) return false;

  return canAccessProfile(user, assessment.profileId);
}

/**
 * Returns true if the user can create or update profiles.
 * Only ADMIN and ASSESSOR roles can modify profiles.
 */
export function canModifyProfile(user: SessionUser): boolean {
  return user.role === Role.ADMIN || user.role === Role.ASSESSOR;
}

/**
 * Returns true if the user can upload, activate, or archive templates.
 * Only ADMIN and ASSESSOR roles can manage templates.
 */
export function canManageTemplates(user: SessionUser): boolean {
  return user.role === Role.ADMIN || user.role === Role.ASSESSOR;
}

/**
 * Returns true if the user is an ADMIN.
 */
export function isAdmin(user: SessionUser): boolean {
  return user.role === Role.ADMIN;
}

/**
 * Returns true if the user can create new assessments.
 * Only ADMIN and ASSESSOR roles can initiate assessments.
 */
export function canCreateAssessment(user: SessionUser): boolean {
  return user.role === Role.ADMIN || user.role === Role.ASSESSOR;
}
