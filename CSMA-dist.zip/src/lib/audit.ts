import { prisma } from "./prisma";
import { AuditAction, Prisma } from "@prisma/client";

interface AuditParams {
  userId?: string;
  action: AuditAction;
  entityType?: string;
  entityId?: string;
  details?: Prisma.InputJsonObject;
  ipAddress?: string;
  userAgent?: string;
}

export async function auditLog(params: AuditParams): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId ?? null,
        action: params.action,
        entityType: params.entityType ?? null,
        entityId: params.entityId ?? null,
        details: params.details ?? undefined,
        ipAddress: params.ipAddress ?? null,
        userAgent: params.userAgent ?? null,
      },
    });
  } catch (error) {
    // Audit failures must never break main flows — log to console only
    console.error("[auditLog] Failed to write audit log entry:", {
      action: params.action,
      userId: params.userId,
      entityType: params.entityType,
      entityId: params.entityId,
      error: error instanceof Error ? error.message : String(error),
    });
  }
}
