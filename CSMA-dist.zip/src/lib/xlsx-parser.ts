import * as XLSX from "xlsx";
import type { ParsedTemplateRow, XlsxValidationResult } from "@/types";

// Canonical header names (lower-cased for comparison)
const REQUIRED_HEADERS = [
  "domain",
  "category",
  "code",
  "description",
  "label",
  "scoring",
] as const;

/**
 * Parses an XLSX buffer following the CSMA template format.
 * Returns a validation result with parsed rows, errors, and warnings.
 */
export function parseXlsxTemplate(buffer: Buffer): XlsxValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const rows: ParsedTemplateRow[] = [];

  let workbook: XLSX.WorkBook;
  try {
    workbook = XLSX.read(buffer, { type: "buffer" });
  } catch (err) {
    return {
      valid: false,
      rows: [],
      errors: [
        `Failed to read workbook: ${err instanceof Error ? err.message : String(err)}`,
      ],
      warnings: [],
    };
  }

  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) {
    return {
      valid: false,
      rows: [],
      errors: ["Workbook contains no sheets."],
      warnings: [],
    };
  }

  const sheet = workbook.Sheets[firstSheetName];
  const rawData = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
    header: 1,
    defval: "",
  }) as unknown[][];

  if (rawData.length === 0) {
    return {
      valid: false,
      rows: [],
      errors: ["The worksheet is empty."],
      warnings: [],
    };
  }

  // ── Header row validation ──────────────────────────────────────────────────
  const headerRow = rawData[0].map((cell) =>
    String(cell ?? "")
      .trim()
      .toLowerCase()
  );

  // Build a map: canonical name -> column index
  const colIndex: Record<string, number> = {};
  for (const required of REQUIRED_HEADERS) {
    const idx = headerRow.findIndex((h) => h === required);
    if (idx === -1) {
      errors.push(
        `Missing required header column: "${required}". Found headers: [${rawData[0]
          .map((c) => String(c).trim())
          .join(", ")}]`
      );
    } else {
      colIndex[required] = idx;
    }
  }

  // If any headers are missing we cannot proceed with row parsing
  if (errors.length > 0) {
    return { valid: false, rows: [], errors, warnings };
  }

  // ── Data rows ──────────────────────────────────────────────────────────────
  for (let i = 1; i < rawData.length; i++) {
    const rawRow = rawData[i];
    const rowNumber = i + 1; // 1-based for user-facing messages

    const getCellStr = (field: string): string =>
      String(rawRow[colIndex[field]] ?? "").trim();

    const domain = getCellStr("domain");
    const category = getCellStr("category");
    const code = getCellStr("code");
    const description = getCellStr("description");
    const label = getCellStr("label");
    const scoringRaw = getCellStr("scoring");

    // Skip entirely blank rows
    const allEmpty = [domain, category, code, description, label, scoringRaw].every(
      (v) => v === ""
    );
    if (allEmpty) continue;

    let hasRowError = false;

    // Required string field validation
    const requiredStringFields: Array<[string, string]> = [
      ["domain", domain],
      ["category", category],
      ["code", code],
      ["description", description],
      ["label", label],
    ];
    for (const [fieldName, value] of requiredStringFields) {
      if (!value) {
        errors.push(`Row ${rowNumber}: missing required field "${fieldName}"`);
        hasRowError = true;
      }
    }

    // Scoring validation
    let scoring = 0;
    const parsedScoring = Number(scoringRaw);
    if (scoringRaw === "" || isNaN(parsedScoring) || parsedScoring <= 0) {
      errors.push(
        `Row ${rowNumber}: scoring must be a positive number, got "${scoringRaw}"`
      );
      hasRowError = true;
    } else {
      scoring = parsedScoring;
    }

    if (!hasRowError) {
      rows.push({
        domain,
        category,
        code,
        description,
        label,
        scoring,
        orderIndex: rows.length, // sequential, zero-based
      });
    }
  }

  if (rows.length === 0 && errors.length === 0) {
    warnings.push("The template contains no data rows.");
  }

  return {
    valid: errors.length === 0,
    rows,
    errors,
    warnings,
  };
}
