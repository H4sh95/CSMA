// ─── AI Analysis types ────────────────────────────────────────────────────────

export interface AiSettingsData {
  id: string;
  isEnabled: boolean;
  endpoint: string | null;
  deployment: string | null;
  model: string | null;
  /** API key is never returned to the client — this field is always null/masked */
  apiKeyConfigured: boolean;
  systemPromptTemplate: string | null;
  recommendationStyle: "concise" | "detailed" | "executive";
  maxTokens: number;
  temperature: number;
  includeAssessorComments: boolean;
  includeHistorical: boolean;
  updatedAt: Date;
  updatedById: string | null;
}

export interface AiAnalysisData {
  id: string;
  assessmentId: string;
  versionNumber: number;
  generatedById: string | null;
  generatedByName: string | null;
  generationMode: "automatic" | "manual" | "regenerated";
  provider: string;
  modelUsed: string | null;
  deploymentUsed: string | null;
  currentState: string;
  immediateActions: string[];
  mediumTermActions: string[];
  longTermActions: string[];
  deduplicationApplied: boolean;
  deduplicationSummary: string | null;
  status: "success" | "failed" | "pending";
  errorMessage: string | null;
  tokenCount: number | null;
  isActive: boolean;
  createdAt: Date;
}

/** Raw structure expected from the AI model response */
export interface AiModelResponse {
  currentState: string;
  immediateActions: string[];
  mediumTermActions: string[];
  longTermActions: string[];
}

/** Domain score context sent to the AI */
export interface DomainScoreContext {
  domain: string;
  score: number;
  maxScore: number;
  percentage: number;
  itemCount: number;
  answeredCount: number;
  level: string;
}

/** Category score context sent to the AI */
export interface CategoryScoreContext {
  domain: string;
  category: string;
  percentage: number;
  level: string;
  answeredCount: number;
  itemCount: number;
}

/** Full context package assembled before calling the AI */
export interface AnalysisContext {
  assessmentId: string;
  assessmentTitle: string;
  customerName: string;
  templateName: string;
  assessorName: string;
  completedAt: string;
  overallScore: number;
  completionPercentage: number;
  includedDomains: DomainScoreContext[];
  excludedDomains: string[];
  categoryScores: CategoryScoreContext[];
  strengths: DomainScoreContext[];
  weaknesses: DomainScoreContext[];
  assessorComments: Array<{ code: string; domain: string; category: string; comment: string }>;
  historicalComparisons: Array<{ title: string; completedAt: string; overallScore: number }>;
  recommendationStyle: "concise" | "detailed" | "executive";
}
