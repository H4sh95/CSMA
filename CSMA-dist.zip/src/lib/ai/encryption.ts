/**
 * AES-256-GCM encryption for sensitive config values (API keys).
 * Key is derived from ENCRYPTION_KEY env var (must be 32-byte hex string = 64 chars).
 * Falls back to a deterministic but weak key in development if not set — this
 * is safe because the dev DB is never production-accessible.
 */
import { createCipheriv, createDecipheriv, randomBytes } from "crypto";

const ALGORITHM = "aes-256-gcm";
const IV_LEN = 12;   // 96-bit IV for GCM
const TAG_LEN = 16;  // 128-bit auth tag

function getEncryptionKey(): Buffer {
  const raw = process.env.ENCRYPTION_KEY;
  if (raw && raw.length === 64) {
    return Buffer.from(raw, "hex");
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "ENCRYPTION_KEY environment variable is required in production. " +
      "Set it to a 64-character hex string (32 random bytes)."
    );
  }
  // Dev fallback — never used in production
  return Buffer.from("0".repeat(64), "hex");
}

/**
 * Encrypts a plaintext string.
 * Returns a base64-encoded string: iv(12) + tag(16) + ciphertext
 */
export function encrypt(plaintext: string): string {
  const key = getEncryptionKey();
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGORITHM, key, iv);

  const encrypted = Buffer.concat([
    cipher.update(plaintext, "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();

  // Layout: [iv (12)] [tag (16)] [ciphertext]
  const combined = Buffer.concat([iv, tag, encrypted]);
  return combined.toString("base64");
}

/**
 * Decrypts a base64-encoded string produced by `encrypt`.
 */
export function decrypt(ciphertext: string): string {
  const key = getEncryptionKey();
  const combined = Buffer.from(ciphertext, "base64");

  const iv       = combined.subarray(0, IV_LEN);
  const tag      = combined.subarray(IV_LEN, IV_LEN + TAG_LEN);
  const payload  = combined.subarray(IV_LEN + TAG_LEN);

  const decipher = createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);

  return Buffer.concat([decipher.update(payload), decipher.final()]).toString("utf8");
}

/** Returns true if the string looks like an encrypted value produced by encrypt(). */
export function isEncrypted(value: string): boolean {
  try {
    const buf = Buffer.from(value, "base64");
    return buf.length > IV_LEN + TAG_LEN;
  } catch {
    return false;
  }
}
