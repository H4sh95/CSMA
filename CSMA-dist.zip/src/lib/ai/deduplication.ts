import type { AiModelResponse } from "./types";

/**
 * Normalise a recommendation string for comparison:
 * - lowercase
 * - strip punctuation and common filler words
 * - collapse whitespace
 */
function normalise(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, " ")
    .replace(/\b(the|a|an|and|or|to|in|of|for|with|by|is|are|should|must|will|that|this|be|it|its|from|on|at|as|we|you|your|our|ensure|implement|deploy|establish|review|conduct|consider|enable|disable|perform|provide|create|update|define|develop|use|make|set|get|put|add|remove|check|verify|assess|manage|monitor|improve|increase|decrease|reduce)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Computes a simple token-overlap similarity score between two strings (0–1).
 */
function similarity(a: string, b: string): number {
  const tokensA = new Set(normalise(a).split(" ").filter(Boolean));
  const tokensB = new Set(normalise(b).split(" ").filter(Boolean));
  if (tokensA.size === 0 && tokensB.size === 0) return 1;
  if (tokensA.size === 0 || tokensB.size === 0) return 0;

  let intersection = 0;
  for (const t of tokensA) {
    if (tokensB.has(t)) intersection++;
  }
  // Jaccard similarity
  const union = tokensA.size + tokensB.size - intersection;
  return intersection / union;
}

const SIMILARITY_THRESHOLD = 0.55; // items with ≥55% token overlap are considered duplicates

export interface DeduplicationResult {
  immediateActions: string[];
  mediumTermActions: string[];
  longTermActions: string[];
  removedCount: number;
  summary: string;
}

/**
 * Removes duplicate and near-duplicate recommendations from the AI response.
 *
 * Rules:
 * 1. Remove exact duplicates (case-insensitive) within each list.
 * 2. Remove near-duplicates across ALL three lists — keeping the one from the higher-priority list
 *    (immediate > medium > long).
 * 3. Record what was removed for transparency.
 */
export function deduplicateRecommendations(raw: AiModelResponse): DeduplicationResult {
  const removedItems: string[] = [];

  // Step 1: Deduplicate within each list
  function dedupeWithin(items: string[]): string[] {
    const seen: string[] = [];
    for (const item of items) {
      const isDup = seen.some((s) => similarity(s, item) >= SIMILARITY_THRESHOLD);
      if (!isDup) {
        seen.push(item);
      } else {
        removedItems.push(`[intra-list duplicate] "${item.slice(0, 80)}"`);
      }
    }
    return seen;
  }

  let immediate = dedupeWithin(raw.immediateActions);
  let medium    = dedupeWithin(raw.mediumTermActions);
  let longTerm  = dedupeWithin(raw.longTermActions);

  // Step 2: Cross-list deduplication — higher priority list wins
  // Medium vs Immediate
  medium = medium.filter((m) => {
    const conflict = immediate.find((i) => similarity(i, m) >= SIMILARITY_THRESHOLD);
    if (conflict) {
      removedItems.push(`[cross-list duplicate, kept in Immediate] "${m.slice(0, 80)}"`);
      return false;
    }
    return true;
  });

  // Long vs Immediate
  longTerm = longTerm.filter((l) => {
    const conflict = immediate.find((i) => similarity(i, l) >= SIMILARITY_THRESHOLD);
    if (conflict) {
      removedItems.push(`[cross-list duplicate, kept in Immediate] "${l.slice(0, 80)}"`);
      return false;
    }
    return true;
  });

  // Long vs Medium
  longTerm = longTerm.filter((l) => {
    const conflict = medium.find((m) => similarity(m, l) >= SIMILARITY_THRESHOLD);
    if (conflict) {
      removedItems.push(`[cross-list duplicate, kept in Medium Term] "${l.slice(0, 80)}"`);
      return false;
    }
    return true;
  });

  const summary =
    removedItems.length === 0
      ? "No duplicates detected."
      : `Removed ${removedItems.length} duplicate/near-duplicate recommendation(s): ${removedItems.join("; ")}`;

  return {
    immediateActions: immediate,
    mediumTermActions: medium,
    longTermActions: longTerm,
    removedCount: removedItems.length,
    summary,
  };
}
