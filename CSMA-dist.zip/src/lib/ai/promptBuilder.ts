import type { AnalysisContext } from "./types";
import type { ChatMessage } from "./azureOpenAiClient";

export type { ChatMessage };

const DEFAULT_SYSTEM_PROMPT = `You are an experienced cybersecurity maturity advisor and risk consultant. Your role is to analyse cybersecurity maturity assessment results and provide clear, actionable, prioritised guidance.

Rules you MUST follow:
1. Base your analysis ONLY on the supplied assessment data — do not invent or assume facts not present.
2. Respect scope: analyse and recommend only for INCLUDED domains. For EXCLUDED domains you may note their absence but must not make recommendations as if they were assessed.
3. Never repeat the same recommendation across sections. Each action must appear exactly once.
4. Do not produce vague generic advice. Every recommendation must be specific and grounded in the assessment data.
5. Separate urgency clearly: immediate actions address critical gaps NOW; medium-term actions address improvement over months; long-term actions address strategic maturity.
6. Return ONLY valid JSON matching the exact schema provided — no markdown, no prose outside the JSON.

Output schema (strict):
{
  "currentState": "string — 2-4 paragraph narrative of current security posture",
  "immediateActions": ["string — specific action"],
  "mediumTermActions": ["string — specific action"],
  "longTermActions": ["string — specific action"]
}`;

/**
 * Builds the chat messages array for the Azure OpenAI call.
 */
export function buildAnalysisMessages(
  context: AnalysisContext,
  customSystemPrompt?: string | null
): ChatMessage[] {
  const systemPrompt = (customSystemPrompt?.trim()) || DEFAULT_SYSTEM_PROMPT;

  const stylePreamble =
    context.recommendationStyle === "executive"
      ? "Write for a senior executive audience: concise, business-focused, limited technical jargon."
      : context.recommendationStyle === "concise"
      ? "Be concise. Use short, direct sentences."
      : "Be detailed and thorough. Include technical specifics where relevant.";

  const includedDomainLines = context.includedDomains
    .map(
      (d) =>
        `  - ${d.domain}: ${d.percentage.toFixed(1)}% (${d.level}) — ${d.answeredCount}/${d.itemCount} controls assessed`
    )
    .join("\n");

  const categoryLines = context.categoryScores
    .sort((a, b) => a.percentage - b.percentage)
    .slice(0, 20) // cap to top/bottom 20 to manage token usage
    .map(
      (c) =>
        `  - [${c.domain}] ${c.category}: ${c.percentage.toFixed(1)}% (${c.level})`
    )
    .join("\n");

  const strengthLines = context.strengths
    .map((d) => `  - ${d.domain}: ${d.percentage.toFixed(1)}%`)
    .join("\n");

  const weaknessLines = context.weaknesses
    .map((d) => `  - ${d.domain}: ${d.percentage.toFixed(1)}%`)
    .join("\n");

  const commentLines =
    context.assessorComments.length > 0
      ? context.assessorComments
          .slice(0, 30) // cap comments
          .map((c) => `  [${c.code}/${c.domain}]: ${c.comment}`)
          .join("\n")
      : "  None provided.";

  const historyLines =
    context.historicalComparisons.length > 0
      ? context.historicalComparisons
          .map(
            (h) =>
              `  - ${h.title} (${h.completedAt}): ${h.overallScore.toFixed(1)}%`
          )
          .join("\n")
      : "  No previous assessments available.";

  const userPrompt = `${stylePreamble}

## Assessment Context
- Customer: ${context.customerName}
- Assessment: ${context.assessmentTitle}
- Template: ${context.templateName}
- Assessor: ${context.assessorName}
- Completed: ${context.completedAt}
- Overall Score: ${context.overallScore.toFixed(1)}%
- Completion Rate: ${context.completionPercentage.toFixed(1)}%

## Included Domains (IN SCOPE — analyse these)
${includedDomainLines || "  None"}

## Excluded Domains (OUT OF SCOPE — do not recommend for these)
${context.excludedDomains.length > 0 ? context.excludedDomains.map((d) => `  - ${d}`).join("\n") : "  None — all domains included"}

## Category Scores (lowest first, top 20)
${categoryLines || "  None"}

## Top Strengths
${strengthLines || "  None"}

## Areas Requiring Attention
${weaknessLines || "  None"}

## Assessor Comments (if applicable)
${commentLines}

## Historical Comparison
${historyLines}

---
Produce your analysis as strict JSON only (no markdown code blocks, no extra text). Follow the output schema exactly.
Do NOT duplicate any recommendation across sections. Each action must appear in exactly one list.`;

  return [
    { role: "system", content: systemPrompt },
    { role: "user",   content: userPrompt },
  ];
}
