import type { AiModelResponse } from "./types";

export interface AzureOpenAiConfig {
  endpoint: string;
  deployment: string;
  apiKey: string;
  apiVersion?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface AzureCallResult {
  response: AiModelResponse;
  tokenCount: number;
}

const DEFAULT_API_VERSION = "2024-08-01-preview";

/**
 * Calls Azure OpenAI chat completions and expects a JSON response matching AiModelResponse.
 * All credentials are server-side only — never called from client code.
 */
export async function callAzureOpenAi(
  config: AzureOpenAiConfig,
  messages: ChatMessage[]
): Promise<AzureCallResult> {
  const apiVersion = config.apiVersion ?? DEFAULT_API_VERSION;
  const url = `${config.endpoint.replace(/\/$/, "")}/openai/deployments/${config.deployment}/chat/completions?api-version=${apiVersion}`;

  const body = {
    messages,
    max_tokens: config.maxTokens ?? 2000,
    temperature: config.temperature ?? 0.3,
    response_format: { type: "json_object" },
  };

  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": config.apiKey,
      },
      body: JSON.stringify(body),
      // Server-side fetch — TLS verification is handled by Node.js
    });
  } catch (err) {
    throw new Error(
      `Azure OpenAI network error: ${err instanceof Error ? err.message : String(err)}`
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Azure OpenAI API error ${res.status}: ${text.slice(0, 300)}`);
  }

  const json = await res.json();

  const content: string = json?.choices?.[0]?.message?.content ?? "";
  if (!content) {
    throw new Error("Azure OpenAI returned an empty response");
  }

  const tokenCount: number =
    json?.usage?.total_tokens ?? 0;

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new Error(`Azure OpenAI response was not valid JSON: ${content.slice(0, 200)}`);
  }

  const validated = validateAiModelResponse(parsed);
  return { response: validated, tokenCount };
}

/**
 * Validates and coerces the raw AI response to AiModelResponse.
 * Throws if the structure is invalid.
 */
export function validateAiModelResponse(raw: unknown): AiModelResponse {
  if (!raw || typeof raw !== "object") {
    throw new Error("AI response is not an object");
  }

  const obj = raw as Record<string, unknown>;

  if (typeof obj.currentState !== "string" || obj.currentState.trim() === "") {
    throw new Error("AI response missing or empty 'currentState' field");
  }

  const coerceStringArray = (val: unknown, field: string): string[] => {
    if (!Array.isArray(val)) {
      throw new Error(`AI response '${field}' is not an array`);
    }
    return val.map((item, i) => {
      if (typeof item !== "string") {
        throw new Error(`AI response '${field}[${i}]' is not a string`);
      }
      return item.trim();
    }).filter(Boolean);
  };

  return {
    currentState: obj.currentState.trim(),
    immediateActions: coerceStringArray(obj.immediateActions, "immediateActions"),
    mediumTermActions: coerceStringArray(obj.mediumTermActions, "mediumTermActions"),
    longTermActions: coerceStringArray(obj.longTermActions, "longTermActions"),
  };
}

/**
 * Lightweight connection test: sends a minimal ping to Azure OpenAI.
 * Returns true if the endpoint responds with a valid model response.
 */
export async function testAzureConnection(
  config: Omit<AzureOpenAiConfig, "maxTokens" | "temperature">
): Promise<{ ok: boolean; message: string }> {
  try {
    await callAzureOpenAi(
      { ...config, maxTokens: 50, temperature: 0 },
      [
        { role: "system", content: "You are a test assistant. Reply with valid JSON only." },
        {
          role: "user",
          content:
            'Respond with exactly this JSON and nothing else: {"currentState":"ok","immediateActions":[],"mediumTermActions":[],"longTermActions":[]}',
        },
      ]
    );
    return { ok: true, message: "Connection successful" };
  } catch (err) {
    return {
      ok: false,
      message: err instanceof Error ? err.message : "Unknown error",
    };
  }
}
