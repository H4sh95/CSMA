import { prisma } from "@/lib/prisma";
import { getScoreLabel } from "@/lib/scoring";
import { decrypt, isEncrypted } from "./encryption";
import { buildAnalysisMessages } from "./promptBuilder";
import { callAzureOpenAi } from "./azureOpenAiClient";
import { deduplicateRecommendations } from "./deduplication";
import { auditLog } from "@/lib/audit";
import type { AnalysisContext, AiSettingsData } from "./types";

// ─── Settings helpers ─────────────────────────────────────────────────────────

/**
 * Loads AI settings from the database, masking the API key.
 * Returns null if no settings row exists yet.
 */
export async function getAiSettings(): Promise<AiSettingsData | null> {
  const row = await prisma.aiSettings.findFirst({ orderBy: { createdAt: "asc" } });
  if (!row) return null;
  return {
    id: row.id,
    isEnabled: row.isEnabled,
    endpoint: row.endpoint,
    deployment: row.deployment,
    model: row.model,
    apiKeyConfigured: !!row.encryptedApiKey,
    systemPromptTemplate: row.systemPromptTemplate,
    recommendationStyle: (row.recommendationStyle as AiSettingsData["recommendationStyle"]) ?? "detailed",
    maxTokens: row.maxTokens,
    temperature: row.temperature,
    includeAssessorComments: row.includeAssessorComments,
    includeHistorical: row.includeHistorical,
    updatedAt: row.updatedAt,
    updatedById: row.updatedById,
  };
}

/**
 * Loads the raw (decrypted) API key from AI settings.
 * Throws if settings are missing or key is not configured.
 */
async function getDecryptedApiKey(): Promise<string> {
  const row = await prisma.aiSettings.findFirst({ orderBy: { createdAt: "asc" } });
  if (!row?.encryptedApiKey) {
    throw new Error("Azure OpenAI API key is not configured");
  }
  if (isEncrypted(row.encryptedApiKey)) {
    return decrypt(row.encryptedApiKey);
  }
  // Legacy: plaintext (should not happen in production)
  return row.encryptedApiKey;
}

// ─── Context builder ──────────────────────────────────────────────────────────

async function buildAnalysisContext(
  assessmentId: string,
  settings: { includeAssessorComments: boolean; includeHistorical: boolean; recommendationStyle: string }
): Promise<AnalysisContext> {
  const assessment = await prisma.assessment.findUniqueOrThrow({
    where: { id: assessmentId },
    include: {
      profile: true,
      template: true,
      createdBy: { select: { name: true } },
      domainScores: true,
      categoryScores: true,
      responses: {
        include: { templateItem: { select: { code: true, domain: true, category: true } } },
        where: { comment: { not: null } },
      },
    },
  });

  const includedDomains = assessment.domainScores
    .filter((d) => !assessment.excludedDomains.includes(d.domain))
    .map((d) => ({
      domain: d.domain,
      score: d.score,
      maxScore: d.maxScore,
      percentage: d.percentage,
      itemCount: d.itemCount,
      answeredCount: d.answeredCount,
      level: getScoreLabel(d.percentage),
    }));

  const sortedByPct = [...includedDomains].sort((a, b) => b.percentage - a.percentage);
  const strengths  = sortedByPct.slice(0, 3);
  const weaknesses = [...sortedByPct].reverse().slice(0, 3);

  const categoryScores = assessment.categoryScores
    .filter((c) => !assessment.excludedDomains.includes(c.domain))
    .map((c) => ({
      domain: c.domain,
      category: c.category,
      percentage: c.percentage,
      level: getScoreLabel(c.percentage),
      answeredCount: c.answeredCount,
      itemCount: c.itemCount,
    }));

  const assessorComments = settings.includeAssessorComments
    ? assessment.responses
        .filter((r) => r.comment && r.comment.trim().length > 0)
        .map((r) => ({
          code: r.templateItem.code,
          domain: r.templateItem.domain,
          category: r.templateItem.category,
          comment: r.comment as string,
        }))
    : [];

  let historicalComparisons: AnalysisContext["historicalComparisons"] = [];
  if (settings.includeHistorical) {
    const history = await prisma.assessment.findMany({
      where: {
        profileId: assessment.profileId,
        status: "COMPLETED",
        id: { not: assessmentId },
      },
      orderBy: { completedAt: "desc" },
      take: 5,
      select: { title: true, completedAt: true, overallScore: true },
    });
    historicalComparisons = history
      .filter((h) => h.completedAt && h.overallScore !== null)
      .map((h) => ({
        title: h.title,
        completedAt: h.completedAt!.toLocaleDateString("en-US", { year: "numeric", month: "short" }),
        overallScore: h.overallScore ?? 0,
      }));
  }

  return {
    assessmentId,
    assessmentTitle: assessment.title,
    customerName: assessment.profile.name,
    templateName: `${assessment.template.name} v${assessment.template.version}`,
    assessorName: assessment.createdBy.name,
    completedAt: assessment.completedAt
      ? assessment.completedAt.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })
      : "Unknown",
    overallScore: assessment.overallScore ?? 0,
    completionPercentage:
      assessment.domainScores.length > 0
        ? (includedDomains.reduce((s, d) => s + d.answeredCount, 0) /
            Math.max(1, includedDomains.reduce((s, d) => s + d.itemCount, 0))) *
          100
        : 0,
    includedDomains,
    excludedDomains: assessment.excludedDomains,
    categoryScores,
    strengths,
    weaknesses,
    assessorComments,
    historicalComparisons,
    recommendationStyle: (settings.recommendationStyle as AnalysisContext["recommendationStyle"]) ?? "detailed",
  };
}

// ─── Generation ───────────────────────────────────────────────────────────────

export type GenerationMode = "automatic" | "manual" | "regenerated";

export interface GenerateOptions {
  assessmentId: string;
  triggeredByUserId?: string;
  mode?: GenerationMode;
}

/**
 * Generates (or regenerates) AI analysis for a completed assessment.
 * - Marks any existing active analysis as inactive (versioning).
 * - Calls Azure OpenAI with the assembled context.
 * - Deduplicates recommendations.
 * - Persists the result.
 * - Writes audit log entries.
 *
 * This function is designed to be called server-side only.
 * It will not throw if AI is disabled — it returns null instead.
 */
export async function generateAiAnalysis(
  options: GenerateOptions
): Promise<{ analysisId: string } | null> {
  const { assessmentId, triggeredByUserId, mode = "manual" } = options;

  // ── Load and validate settings ───────────────────────────────────────────────
  const settings = await prisma.aiSettings.findFirst({ orderBy: { createdAt: "asc" } });

  if (!settings?.isEnabled) return null;
  if (!settings.endpoint || !settings.deployment || !settings.encryptedApiKey) {
    throw new Error("Azure OpenAI is not fully configured. Please set endpoint, deployment, and API key.");
  }

  // ── Verify assessment is completed ──────────────────────────────────────────
  const assessment = await prisma.assessment.findUnique({
    where: { id: assessmentId },
    select: { status: true },
  });
  if (!assessment || assessment.status !== "COMPLETED") {
    throw new Error("AI analysis can only be generated for completed assessments");
  }

  // ── Determine next version number ────────────────────────────────────────────
  const latestAnalysis = await prisma.aiAnalysis.findFirst({
    where: { assessmentId },
    orderBy: { versionNumber: "desc" },
    select: { versionNumber: true },
  });
  const nextVersion = (latestAnalysis?.versionNumber ?? 0) + 1;

  // ── Build context and messages ───────────────────────────────────────────────
  const context = await buildAnalysisContext(assessmentId, {
    includeAssessorComments: settings.includeAssessorComments,
    includeHistorical: settings.includeHistorical,
    recommendationStyle: settings.recommendationStyle,
  });

  const messages = buildAnalysisMessages(context, settings.systemPromptTemplate);

  // ── Call Azure OpenAI ────────────────────────────────────────────────────────
  const apiKey = await getDecryptedApiKey();

  let rawResponse;
  let tokenCount = 0;
  let callError: string | null = null;

  try {
    const result = await callAzureOpenAi(
      {
        endpoint: settings.endpoint,
        deployment: settings.deployment,
        apiKey,
        maxTokens: settings.maxTokens,
        temperature: settings.temperature,
      },
      messages
    );
    rawResponse = result.response;
    tokenCount  = result.tokenCount;
  } catch (err) {
    callError = err instanceof Error ? err.message : String(err);
    console.error("[generateAiAnalysis] Azure OpenAI call failed:", callError);

    // Persist failure record
    const failed = await prisma.aiAnalysis.create({
      data: {
        assessmentId,
        versionNumber: nextVersion,
        generatedById: triggeredByUserId ?? null,
        generationMode: mode,
        provider: "azure_openai",
        modelUsed: settings.model ?? null,
        deploymentUsed: settings.deployment,
        currentState: "",
        immediateActions: [],
        mediumTermActions: [],
        longTermActions: [],
        status: "failed",
        errorMessage: callError,
        isActive: false,
      },
    });

    await auditLog({
      userId: triggeredByUserId,
      action: "AI_ANALYSIS_FAILED",
      entityType: "Assessment",
      entityId: assessmentId,
      details: { error: callError, version: nextVersion },
    });

    throw new Error(`AI analysis failed: ${callError}`);
  }

  // ── Deduplicate ──────────────────────────────────────────────────────────────
  const dedupResult = deduplicateRecommendations(rawResponse);

  // ── Mark previous analyses as inactive ───────────────────────────────────────
  await prisma.aiAnalysis.updateMany({
    where: { assessmentId, isActive: true },
    data: { isActive: false },
  });

  // ── Persist new analysis ─────────────────────────────────────────────────────
  const saved = await prisma.aiAnalysis.create({
    data: {
      assessmentId,
      versionNumber: nextVersion,
      generatedById: triggeredByUserId ?? null,
      generationMode: mode,
      provider: "azure_openai",
      modelUsed: settings.model ?? null,
      deploymentUsed: settings.deployment,
      currentState: rawResponse.currentState,
      immediateActions: dedupResult.immediateActions,
      mediumTermActions: dedupResult.mediumTermActions,
      longTermActions: dedupResult.longTermActions,
      deduplicationApplied: dedupResult.removedCount > 0,
      deduplicationSummary: dedupResult.summary,
      status: "success",
      tokenCount,
      isActive: true,
    },
  });

  const auditAction = nextVersion === 1 ? "AI_ANALYSIS_GENERATED" : "AI_ANALYSIS_REGENERATED";
  await auditLog({
    userId: triggeredByUserId,
    action: auditAction,
    entityType: "Assessment",
    entityId: assessmentId,
    details: {
      analysisId: saved.id,
      version: nextVersion,
      mode,
      tokenCount,
      deduplicationApplied: dedupResult.removedCount > 0,
    },
  });

  return { analysisId: saved.id };
}
