import { NextRequest, NextResponse } from "next/server";
import { auth } from "./auth";
import { Role } from "@prisma/client";
import type { ZodSchema, ZodError } from "zod";
import type { SessionUser } from "@/types";

// ─── Response Helpers ────────────────────────────────────────────────────────

export function successResponse<T>(data: T, status = 200): NextResponse {
  return NextResponse.json({ data }, { status });
}

export function errorResponse(message: string, status = 400): NextResponse {
  return NextResponse.json({ error: message }, { status });
}

export function paginatedResponse<T>(
  data: T[],
  total: number,
  page: number,
  pageSize: number
): NextResponse {
  return NextResponse.json({
    data,
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  });
}

// ─── Body Validation ─────────────────────────────────────────────────────────

/**
 * Parses and validates the JSON body against a Zod schema.
 * Returns { data } on success or { error: NextResponse } on failure.
 */
export async function validateBody<T>(
  req: NextRequest,
  schema: ZodSchema<T>
): Promise<{ data: T; error: null } | { data: null; error: NextResponse }> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return {
      data: null,
      error: errorResponse("Invalid JSON body", 400),
    };
  }

  const result = schema.safeParse(raw);
  if (!result.success) {
    const messages = (result.error as ZodError).errors.map(
      (e) => `${e.path.join(".")}: ${e.message}`
    );
    return {
      data: null,
      error: errorResponse(messages.join("; "), 422),
    };
  }

  return { data: result.data, error: null };
}

// ─── Auth Helpers ─────────────────────────────────────────────────────────────

/**
 * Resolves the current session user and enforces role access.
 *
 * Pass a single Role or an array of Roles. ADMIN always passes.
 * Returns the SessionUser on success, or a NextResponse (401/403) on failure.
 *
 * Typical usage:
 *   const result = await requireRole(Role.ASSESSOR);
 *   if (result instanceof NextResponse) return result;
 *   const user = result; // SessionUser
 */
export async function requireRole(
  minRole: Role | Role[]
): Promise<SessionUser | NextResponse> {
  const session = await auth();

  if (!session?.user?.id) {
    return errorResponse("Unauthorized", 401);
  }

  const user: SessionUser = {
    id: session.user.id,
    email: session.user.email as string,
    name: session.user.name as string,
    role: session.user.role,
  };

  // ADMIN always bypasses role restrictions
  if (user.role === Role.ADMIN) {
    return user;
  }

  const allowedRoles = Array.isArray(minRole) ? minRole : [minRole];
  if (!allowedRoles.includes(user.role)) {
    return errorResponse("Forbidden", 403);
  }

  return user;
}

/**
 * Resolves the current session user without role restriction.
 * Returns the SessionUser or a NextResponse 401 if not authenticated.
 */
export async function requireAuthUser(): Promise<SessionUser | NextResponse> {
  const session = await auth();

  if (!session?.user?.id) {
    return errorResponse("Unauthorized", 401);
  }

  return {
    id: session.user.id,
    email: session.user.email as string,
    name: session.user.name as string,
    role: session.user.role,
  };
}

// ─── Pagination ───────────────────────────────────────────────────────────────

export interface PaginationParams {
  page: number;
  pageSize: number;
  skip: number;
}

/**
 * Reads `page` and `pageSize` from a URLSearchParams instance.
 * Defaults: page=1, pageSize=20. Maximum pageSize is capped at 100.
 */
export function getPaginationParams(
  searchParams: URLSearchParams
): PaginationParams {
  const page = Math.max(1, parseInt(searchParams.get("page") ?? "1", 10) || 1);
  const pageSize = Math.min(
    100,
    Math.max(1, parseInt(searchParams.get("pageSize") ?? "20", 10) || 20)
  );
  return { page, pageSize, skip: (page - 1) * pageSize };
}

/**
 * Reads a single string query param, returning undefined if absent or empty.
 */
export function getSearchParam(
  searchParams: URLSearchParams,
  key: string
): string | undefined {
  const value = searchParams.get(key);
  if (value === null || value.trim() === "") return undefined;
  return value.trim();
}

// ─── Request Metadata ────────────────────────────────────────────────────────

export function getRequestMeta(req: NextRequest): {
  ipAddress: string | undefined;
  userAgent: string | undefined;
} {
  return {
    ipAddress:
      req.headers.get("x-forwarded-for") ??
      req.headers.get("x-real-ip") ??
      undefined,
    userAgent: req.headers.get("user-agent") ?? undefined,
  };
}
