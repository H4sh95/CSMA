import { prisma } from "./prisma";
import { calculateScores, getScoreLabel } from "./scoring";
import type { AssessmentWithRelations } from "@/types";

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function fetchAssessment(assessmentId: string): Promise<AssessmentWithRelations> {
  const assessment = await prisma.assessment.findUniqueOrThrow({
    where: { id: assessmentId },
    include: {
      profile: true,
      template: {
        include: { items: { orderBy: { orderIndex: "asc" } } },
      },
      createdBy: { select: { id: true, name: true, email: true } },
      responses: {
        include: { templateItem: true },
      },
      domainScores: true,
      categoryScores: true,
    },
  });

  return assessment as AssessmentWithRelations;
}

// ─── Brand colours (RGB tuples) ───────────────────────────────────────────────

const CP_PINK   = [238, 12,  93]  as const;  // #EE0C5D
const CP_DARK   = [35,  31,  32]  as const;  // #231F20
const CP_NAVY   = [22,  30,  48]  as const;  // #161E30
const SLATE_700 = [51,  65,  85]  as const;
const SLATE_400 = [148, 163, 184] as const;

// ─── PDF: logo mark ───────────────────────────────────────────────────────────

/**
 * Draw the Check Point logo mark using jsPDF drawing primitives.
 *
 * Recreates the same "C" shape + satellite dot + network icon as the SVG:
 *   1. Full magenta circle
 *   2. A background-coloured circle carves out the concave bite
 *   3. Black dot sits in the bite (gap ring = biteR – dotR)
 *   4. White network icon inside
 *
 * @param bgColor   RGB of the surface behind the logo (used for the bite colour)
 */
function drawCPLogoMark(
  doc: import("jspdf").jsPDF,
  x: number,
  y: number,
  size: number = 12,
  bgColor: readonly [number, number, number] = [255, 255, 255]
) {
  const mainR  = size / 2;
  const cx     = x + mainR * 1.05;
  const cy     = y + mainR * 1.08;

  // Proportions from the SVG (viewBox 90×80, mainR≡31):
  //   bite centre offset from main centre ≈ 38.9 / 31 ≈ 1.255 × mainR
  //   bite radius ≈ 14 / 31 ≈ 0.452 × mainR
  //   dot  radius ≈ 12 / 31 ≈ 0.387 × mainR
  //   angle ≈ atan2(-29, 26) ≈ -48° from horizontal  (upper-right)
  const biteAngle = -0.840; // radians ≈ −48°
  const biteDist  = mainR * 1.255;
  const biteR     = mainR * 0.452;
  const dotR      = mainR * 0.387;
  const biteCx    = cx + biteDist * Math.cos(biteAngle);
  const biteCy    = cy + biteDist * Math.sin(biteAngle);

  // ── Main magenta circle ──
  doc.setFillColor(...CP_PINK);
  doc.circle(cx, cy, mainR, "F");

  // ── Bite — drawn in the surface background colour to create the C shape ──
  doc.setFillColor(...bgColor);
  doc.circle(biteCx, biteCy, biteR, "F");

  // ── Black satellite dot ──
  doc.setFillColor(...CP_DARK);
  doc.circle(biteCx, biteCy, dotR, "F");

  // ── White network icon ──
  // Hub ring centre and diamond centre scaled from SVG coords
  const hubX = cx + mainR * ((38 - 36) / 31);   // ≈ cx + 0.065 mainR
  const hubY = cy + mainR * ((54 - 46) / 31);   // ≈ cy + 0.258 mainR
  const hubR = mainR * (8.5 / 31);
  const dmX  = cx + mainR * ((20 - 36) / 31);   // ≈ cx − 0.516 mainR
  const dmY  = cy + mainR * ((36 - 46) / 31);   // ≈ cy − 0.323 mainR
  const dmD  = mainR * (9 / 31);                 // half-width of diamond

  // Connector line
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(mainR * 0.11);
  doc.line(dmX, dmY, hubX, hubY);

  // Hub ring (stroke only)
  doc.setLineWidth(mainR * 0.11);
  doc.circle(hubX, hubY, hubR, "S");

  // Diamond (4 outline lines forming a rotated square — fill via overpainting)
  doc.setFillColor(255, 255, 255);
  doc.circle(dmX, dmY, dmD * 0.9, "F"); // simplified as small filled circle for PDF
}

// ─── PDF: horizontal bar chart ────────────────────────────────────────────────

/**
 * Draws a branded horizontal bar chart in a jsPDF document.
 * Bars are colour-coded by score level (green → amber → red).
 */
function drawPdfBarChart(
  doc: import("jspdf").jsPDF,
  x: number,
  y: number,
  w: number,
  h: number,
  data: { label: string; value: number }[]
) {
  const n = data.length;
  if (n === 0) return;

  const labelW = 38;
  const barAreaW = w - labelW - 14; // right margin for value labels
  const spacing = 3;
  const barH = Math.min(10, Math.floor((h - spacing * (n - 1) - 10) / n));

  // ── Axis marks ──
  doc.setFontSize(6.5);
  doc.setTextColor(...SLATE_400);
  for (const pct of [0, 25, 50, 75, 100]) {
    const gx = x + labelW + barAreaW * (pct / 100);
    doc.text(`${pct}%`, gx, y + 6, { align: "center" });
  }

  // ── Grid lines ──
  doc.setDrawColor(225, 228, 235);
  doc.setLineWidth(0.2);
  for (const pct of [25, 50, 75, 100]) {
    const gx = x + labelW + barAreaW * (pct / 100);
    doc.line(gx, y + 8, gx, y + 8 + n * (barH + spacing));
  }

  // ── Bars ──
  for (let i = 0; i < n; i++) {
    const by    = y + 8 + i * (barH + spacing);
    const val   = Math.min(Math.max(data[i].value, 0), 100);
    const barW  = barAreaW * (val / 100);

    // Label (right-aligned before bar)
    const label = data[i].label.length > 15 ? data[i].label.slice(0, 14) + "…" : data[i].label;
    doc.setFontSize(7.5);
    doc.setTextColor(...SLATE_700);
    doc.text(label, x + labelW - 2, by + barH * 0.68, { align: "right" });

    // Background track
    doc.setFillColor(240, 242, 248);
    doc.rect(x + labelW, by, barAreaW, barH, "F");

    // Coloured fill (score-level colours)
    let r = 238, g = 12, b = 93;
    if (val >= 80)      { r = 16;  g = 185; b = 129; }  // emerald
    else if (val >= 60) { r = 34;  g = 197; b = 94;  }  // green
    else if (val >= 40) { r = 234; g = 179; b = 8;   }  // amber
    else if (val >= 20) { r = 249; g = 115; b = 22;  }  // orange
    else                { r = 239; g = 68;  b = 68;  }  // red
    doc.setFillColor(r, g, b);
    if (barW > 0) doc.rect(x + labelW, by, barW, barH, "F");

    // Value label
    doc.setFontSize(7);
    const valText = `${val.toFixed(1)}%`;
    if (barW > 12) {
      doc.setTextColor(255, 255, 255);
      doc.text(valText, x + labelW + barW - 2, by + barH * 0.71, { align: "right" });
    } else {
      doc.setTextColor(...SLATE_700);
      doc.text(valText, x + labelW + barW + 2, by + barH * 0.71, { align: "left" });
    }
  }

  // Reset
  doc.setDrawColor(0, 0, 0);
  doc.setFillColor(0, 0, 0);
  doc.setLineWidth(0.5);
  doc.setFontSize(10);
  doc.setTextColor(...SLATE_700);
}

// ─── PDF Export ───────────────────────────────────────────────────────────────

export async function generatePdfReport(assessmentId: string): Promise<Buffer> {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;

  const assessment = await fetchAssessment(assessmentId);

  const items = assessment.template.items.map((item) => ({
    id: item.id,
    domain: item.domain,
    category: item.category,
    scoring: item.scoring,
  }));
  const responses = assessment.responses.map((r) => ({
    templateItemId: r.templateItemId,
    score: r.score,
    isAnswered: r.isAnswered,
  }));

  const scores = calculateScores(items, responses);
  const scoreLabel = getScoreLabel(scores.overallPercentage);
  const reportDate = new Date().toLocaleDateString("en-US", {
    year: "numeric", month: "long", day: "numeric",
  });

  // ── Fetch AI analysis if available ─────────────────────────────────────────
  const aiAnalysis = await prisma.aiAnalysis.findFirst({
    where: { assessmentId, isActive: true, status: "success" },
    orderBy: { versionNumber: "desc" },
  });

  const doc      = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pageW    = doc.internal.pageSize.getWidth();
  const pageH    = doc.internal.pageSize.getHeight();
  const margin   = 20;
  const cW       = pageW - margin * 2;

  // ── Helpers ────────────────────────────────────────────────────────────────

  function addPageHeader(pageNum: number, totalPages: number) {
    doc.setFillColor(...CP_NAVY);
    doc.rect(0, 0, pageW, 16, "F");

    // "CHECK POINT" wordmark — text only, no logo mark
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    doc.text("CHECK POINT", margin, 8);
    doc.setFontSize(6.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(180, 195, 220);
    doc.text("Cyber Security Assessment Platform", margin, 12.5);

    // Page number
    doc.setFontSize(7.5);
    doc.setTextColor(180, 190, 210);
    doc.text(`Page ${pageNum} of ${totalPages}`, pageW - margin, 9.5, { align: "right" });

    // Pink accent line
    doc.setFillColor(...CP_PINK);
    doc.rect(0, 16, pageW, 0.7, "F");
  }

  function addPageFooter() {
    doc.setFillColor(240, 242, 248);
    doc.rect(0, pageH - 9, pageW, 9, "F");
    doc.setFontSize(7);
    doc.setTextColor(...SLATE_400);
    doc.text(
      `Check Point Software Technologies Ltd.  ·  Confidential  ·  Generated ${reportDate}`,
      pageW / 2, pageH - 3.5, { align: "center" }
    );
  }

  // ── COVER PAGE ─────────────────────────────────────────────────────────────
  doc.setFillColor(...CP_NAVY);
  doc.rect(0, 0, pageW, pageH, "F");

  // Pink footer band
  doc.setFillColor(...CP_PINK);
  doc.rect(0, pageH - 18, pageW, 18, "F");

  // "CHECK POINT" — large, centred, text only (no logo mark)
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(28);
  doc.setFont("helvetica", "bold");
  doc.text("CHECK POINT", pageW / 2, 58, { align: "center" });

  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(180, 195, 220);
  doc.text("Cyber Security Assessment Platform", pageW / 2, 69, { align: "center" });

  // Divider
  doc.setFillColor(...CP_PINK);
  doc.rect(margin, 76, cW, 0.6, "F");

  // Report title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("Cyber Security Maturity Report", pageW / 2, 89, { align: "center" });

  // Meta
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(200, 210, 230);
  [assessment.profile.name, assessment.title, reportDate].forEach((line, i) => {
    doc.text(line, pageW / 2, 102 + i * 9, { align: "center" });
  });

  // Score badge
  doc.setFillColor(...CP_PINK);
  doc.roundedRect(pageW / 2 - 30, 134, 60, 19, 3, 3, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text(
    `${scores.overallPercentage.toFixed(1)}%  ·  ${scoreLabel}`,
    pageW / 2, 146, { align: "center" }
  );

  // "Overall Maturity Score" label — increased gap, larger, bold, white
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(255, 255, 255);
  doc.text("Overall Maturity Score", pageW / 2, 163, { align: "center" });

  // Cover footer text
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text("Check Point Software Technologies Ltd.", pageW / 2, pageH - 7, { align: "center" });
  doc.setFontSize(7);
  doc.setTextColor(255, 200, 220);
  doc.text("CONFIDENTIAL", pageW / 2, pageH - 2.5, { align: "center" });

  // ── EXECUTIVE SUMMARY ──────────────────────────────────────────────────────
  doc.addPage();

  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...CP_NAVY);
  doc.text("Executive Summary", margin, 28);
  doc.setDrawColor(...SLATE_400);
  doc.setLineWidth(0.3);
  doc.line(margin, 30, pageW - margin, 30);

  autoTable(doc, {
    startY: 34,
    head: [["Metric", "Value"]],
    body: [
      ["Overall Score",      `${scores.overallScore.toFixed(2)}`],
      ["Overall Percentage", `${scores.overallPercentage.toFixed(1)}%`],
      ["Maturity Level",     scoreLabel],
      ["Completion",         `${scores.completionPercentage.toFixed(1)}% (${scores.answeredItems}/${scores.totalItems} items)`],
      ["Template",           assessment.template.name],
      ["Template Version",   assessment.template.version],
      ["Assessed By",        assessment.createdBy.name],
    ],
    margin: { top: 24, left: margin, right: margin },
    headStyles: { fillColor: CP_NAVY as [number, number, number], textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    styles: { fontSize: 10, cellPadding: 4 },
    columnStyles: { 0: { fontStyle: "bold", cellWidth: 60 } },
  });

  const sumEnd = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;

  // ── Domain scores BAR CHART on executive summary page ─────────────────────
  const domainBarData = Object.entries(scores.domainScores).map(([domain, ds]) => ({
    label: domain,
    value: ds.percentage,
  }));

  if (domainBarData.length > 0) {
    const chartY = sumEnd + 10;
    const chartH = Math.min(60, pageH - chartY - 30);

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...CP_NAVY);
    doc.text("Domain Maturity Scores", margin, chartY - 2);

    drawPdfBarChart(doc, margin, chartY, cW, chartH, domainBarData);
  }

  // ── AI ANALYSIS (if available) — placed immediately after Executive Summary ─
  if (aiAnalysis && aiAnalysis.currentState) {
    doc.addPage();

    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...CP_NAVY);
    doc.text("AI-Generated Analysis", margin, 28);
    doc.setDrawColor(...SLATE_400);
    doc.setLineWidth(0.3);
    doc.line(margin, 30, pageW - margin, 30);

    doc.setFontSize(7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...SLATE_400);
    doc.text(
      `AI analysis • ${aiAnalysis.modelUsed ?? "Azure OpenAI"} • Generated ${new Date(aiAnalysis.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}`,
      margin, 36
    );

    let aiY = 42;
    const aiLineH = 5;
    const maxW = cW;

    function aiSection(title: string, color: [number, number, number], items: string[] | null, isNarrative = false) {
      // On a new page, leave room for the running page header (ends at y ≈ 16.7mm)
      if (aiY > pageH - 30) { doc.addPage(); aiY = 24; }

      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(...color);
      doc.text(title, margin, aiY);
      aiY += 6;

      doc.setFontSize(8.5);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...SLATE_700);

      if (isNarrative && typeof items === "string") {
        const lines = doc.splitTextToSize(items as unknown as string, maxW);
        for (const line of lines) {
          if (aiY > pageH - 20) { doc.addPage(); aiY = 24; }
          doc.text(line, margin, aiY);
          aiY += aiLineH;
        }
      } else if (Array.isArray(items)) {
        items.forEach((item, idx) => {
          const prefix = `${idx + 1}. `;
          const lines = doc.splitTextToSize(prefix + item, maxW - 4);
          for (let li = 0; li < lines.length; li++) {
            if (aiY > pageH - 20) { doc.addPage(); aiY = 24; }
            doc.text(li === 0 ? lines[0] : "    " + lines[li], margin + (li === 0 ? 0 : 4), aiY);
            aiY += aiLineH;
          }
        });
      }
      aiY += 4;
    }

    aiSection("Current Security Posture", CP_NAVY as unknown as [number, number, number], aiAnalysis.currentState as unknown as string[] | null, true);
    if (aiAnalysis.immediateActions?.length) aiSection("Immediate Actions", [220, 38, 38], aiAnalysis.immediateActions);
    if (aiAnalysis.mediumTermActions?.length) aiSection("Medium Term Actions", [180, 100, 0], aiAnalysis.mediumTermActions);
    if (aiAnalysis.longTermActions?.length) aiSection("Long Term Actions", [21, 128, 61], aiAnalysis.longTermActions);
  }

  // ── DOMAIN SCORES TABLE ────────────────────────────────────────────────────
  doc.addPage();

  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...CP_NAVY);
  doc.text("Domain Scores", margin, 28);
  doc.setDrawColor(...SLATE_400);
  doc.setLineWidth(0.3);
  doc.line(margin, 30, pageW - margin, 30);

  autoTable(doc, {
    startY: 34,
    head: [["Domain", "Score", "Max Score", "Percentage", "Level", "Answered"]],
    body: Object.entries(scores.domainScores).map(([domain, ds]) => [
      domain,
      ds.score.toFixed(2),
      ds.maxScore.toFixed(2),
      `${ds.percentage.toFixed(1)}%`,
      getScoreLabel(ds.percentage),
      `${ds.answeredCount}/${ds.itemCount}`,
    ]),
    margin: { top: 24, left: margin, right: margin },
    headStyles: { fillColor: CP_NAVY as [number, number, number], textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    styles: { fontSize: 9, cellPadding: 3 },
  });

  // ── CATEGORY SCORES ────────────────────────────────────────────────────────
  doc.addPage();

  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...CP_NAVY);
  doc.text("Category Scores", margin, 28);
  doc.setDrawColor(...SLATE_400);
  doc.setLineWidth(0.3);
  doc.line(margin, 30, pageW - margin, 30);

  const catRows: string[][] = [];
  for (const [domain, categories] of Object.entries(scores.categoryScores)) {
    for (const [category, cs] of Object.entries(categories)) {
      catRows.push([
        domain, category,
        cs.score.toFixed(2), cs.maxScore.toFixed(2),
        `${cs.percentage.toFixed(1)}%`, getScoreLabel(cs.percentage),
      ]);
    }
  }

  autoTable(doc, {
    startY: 34,
    head: [["Domain", "Category", "Score", "Max Score", "Percentage", "Level"]],
    body: catRows,
    margin: { top: 24, left: margin, right: margin },
    headStyles: { fillColor: CP_NAVY as [number, number, number], textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    styles: { fontSize: 9, cellPadding: 3 },
  });

  // ── DETAILED RESPONSES ─────────────────────────────────────────────────────
  doc.addPage();

  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...CP_NAVY);
  doc.text("Detailed Responses", margin, 28);
  doc.setDrawColor(...SLATE_400);
  doc.setLineWidth(0.3);
  doc.line(margin, 30, pageW - margin, 30);

  autoTable(doc, {
    startY: 34,
    head: [["Code", "Domain", "Category", "Description", "Label", "Score", "Comment"]],
    body: assessment.responses
      .sort((a, b) => a.templateItem.orderIndex - b.templateItem.orderIndex)
      .map((r) => [
        r.templateItem.code,
        r.templateItem.domain,
        r.templateItem.category,
        r.templateItem.description.slice(0, 80) + (r.templateItem.description.length > 80 ? "…" : ""),
        r.templateItem.label,
        r.isAnswered && r.score !== null ? `${r.score}/${r.templateItem.scoring}` : "—",
        r.comment ?? "",
      ]),
    margin: { top: 24, left: margin, right: margin },
    headStyles: { fillColor: CP_NAVY as [number, number, number], textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    styles: { fontSize: 7, cellPadding: 2, overflow: "linebreak" },
    columnStyles: {
      0: { cellWidth: 18 },
      1: { cellWidth: 25 },
      2: { cellWidth: 25 },
      3: { cellWidth: 55 },
      4: { cellWidth: 22 },
      5: { cellWidth: 14 },
      6: { cellWidth: 30 },
    },
  });

  // ── HEADERS + FOOTERS (skip cover = page 1) ────────────────────────────────
  const totalPages = (doc.internal as unknown as { getNumberOfPages: () => number }).getNumberOfPages();
  for (let p = 2; p <= totalPages; p++) {
    doc.setPage(p);
    addPageHeader(p - 1, totalPages - 1);
    addPageFooter();
  }

  return Buffer.from(doc.output("arraybuffer"));
}

// ─── XLSX Export ──────────────────────────────────────────────────────────────

export async function generateXlsxReport(assessmentId: string): Promise<Buffer> {
  const XLSX = await import("xlsx");

  const assessment = await fetchAssessment(assessmentId);

  const items = assessment.template.items.map((item) => ({
    id: item.id, domain: item.domain, category: item.category, scoring: item.scoring,
  }));
  const responses = assessment.responses.map((r) => ({
    templateItemId: r.templateItemId, score: r.score, isAnswered: r.isAnswered,
  }));

  const scores = calculateScores(items, responses);
  const wb = XLSX.utils.book_new();

  // ── Summary ────────────────────────────────────────────────────────────────
  const wsSummary = XLSX.utils.aoa_to_sheet([
    ["Check Point Software Technologies", ""],
    ["Cyber Security Assessment Platform", ""],
    [""],
    ["Assessment",      assessment.title],
    ["Customer",        assessment.profile.name],
    ["Status",          assessment.status],
    ["Template",        assessment.template.name],
    ["Template Version",assessment.template.version],
    ["Assessed By",     assessment.createdBy.name],
    ["Report Generated",new Date().toISOString()],
    [""],
    ["Score Summary",   ""],
    ["Overall Score",   scores.overallScore],
    ["Overall %",       `${scores.overallPercentage.toFixed(1)}%`],
    ["Maturity Level",  getScoreLabel(scores.overallPercentage)],
    ["Total Items",     scores.totalItems],
    ["Answered Items",  scores.answeredItems],
    ["Completion",      `${scores.completionPercentage.toFixed(1)}%`],
  ]);
  wsSummary["!cols"] = [{ wch: 35 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(wb, wsSummary, "Summary");

  // ── Domain Scores ──────────────────────────────────────────────────────────
  const domainRows: (string | number)[][] = [
    ["Domain", "Score", "Max Score", "Percentage", "Level", "Answered", "Total Items"],
  ];
  for (const [domain, ds] of Object.entries(scores.domainScores)) {
    domainRows.push([
      domain,
      parseFloat(ds.score.toFixed(2)),
      parseFloat(ds.maxScore.toFixed(2)),
      parseFloat(ds.percentage.toFixed(2)),
      getScoreLabel(ds.percentage),
      ds.answeredCount,
      ds.itemCount,
    ]);
  }
  const wsDomains = XLSX.utils.aoa_to_sheet(domainRows);
  wsDomains["!cols"] = [
    { wch: 30 }, { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 14 }, { wch: 12 }, { wch: 12 },
  ];
  XLSX.utils.book_append_sheet(wb, wsDomains, "Domain Scores");

  // ── Category Scores ────────────────────────────────────────────────────────
  const catRows: (string | number)[][] = [
    ["Domain", "Category", "Score", "Max Score", "Percentage", "Level", "Answered", "Total Items"],
  ];
  for (const [domain, categories] of Object.entries(scores.categoryScores)) {
    for (const [category, cs] of Object.entries(categories)) {
      catRows.push([
        domain, category,
        parseFloat(cs.score.toFixed(2)), parseFloat(cs.maxScore.toFixed(2)),
        parseFloat(cs.percentage.toFixed(2)), getScoreLabel(cs.percentage),
        cs.answeredCount, cs.itemCount,
      ]);
    }
  }
  const wsCategories = XLSX.utils.aoa_to_sheet(catRows);
  wsCategories["!cols"] = [
    { wch: 30 }, { wch: 30 }, { wch: 12 }, { wch: 12 },
    { wch: 14 }, { wch: 14 }, { wch: 12 }, { wch: 12 },
  ];
  XLSX.utils.book_append_sheet(wb, wsCategories, "Category Scores");

  // ── Detailed Responses ─────────────────────────────────────────────────────
  const respRows: (string | number | boolean)[][] = [
    ["Code", "Domain", "Category", "Description", "Label",
     "Max Score", "Actual Score", "Answered", "Comment", "Evidence Note"],
  ];
  for (const r of [...assessment.responses].sort((a, b) => a.templateItem.orderIndex - b.templateItem.orderIndex)) {
    respRows.push([
      r.templateItem.code, r.templateItem.domain, r.templateItem.category,
      r.templateItem.description, r.templateItem.label, r.templateItem.scoring,
      r.isAnswered && r.score !== null ? r.score : "",
      r.isAnswered ? "Yes" : "No",
      r.comment ?? "", r.evidenceNote ?? "",
    ]);
  }
  const wsResponses = XLSX.utils.aoa_to_sheet(respRows);
  wsResponses["!cols"] = [
    { wch: 16 }, { wch: 28 }, { wch: 28 }, { wch: 60 }, { wch: 20 },
    { wch: 12 }, { wch: 14 }, { wch: 12 }, { wch: 40 }, { wch: 40 },
  ];
  XLSX.utils.book_append_sheet(wb, wsResponses, "Detailed Responses");

  return XLSX.write(wb, { bookType: "xlsx", type: "buffer" }) as Buffer;
}
