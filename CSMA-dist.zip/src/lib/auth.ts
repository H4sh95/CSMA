import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { prisma } from "./prisma";
import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";
import { auditLog } from "./audit";
import type { SessionUser } from "@/types";

const nextAuth = NextAuth({
  // Required for non-Vercel / self-hosted deployments.
  // Without this, NextAuth v5 validates the incoming Host header against
  // NEXTAUTH_URL and throws UntrustedHost if they don't match exactly
  // (common behind Docker port mapping or any non-standard origin).
  trustHost: true,
  secret: process.env.AUTH_SECRET,
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: "/login",
    error: "/login",
  },
  providers: [
    Credentials({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials, req) {
        const email = credentials?.email as string | undefined;
        const password = credentials?.password as string | undefined;

        if (!email || !password) {
          return null;
        }

        let user: {
          id: string;
          email: string;
          name: string;
          role: Role;
          passwordHash: string;
          isActive: boolean;
        } | null = null;

        try {
          user = await prisma.user.findUnique({
            where: { email: email.toLowerCase().trim() },
            select: {
              id: true,
              email: true,
              name: true,
              role: true,
              passwordHash: true,
              isActive: true,
            },
          });
        } catch (error) {
          console.error("[auth] Database error during login:", error);
          return null;
        }

        // Extract request metadata for audit
        const ipAddress =
          (req as Request & { headers?: Headers })?.headers?.get(
            "x-forwarded-for"
          ) ??
          (req as Request & { headers?: Headers })?.headers?.get(
            "x-real-ip"
          ) ??
          undefined;
        const userAgent =
          (req as Request & { headers?: Headers })?.headers?.get(
            "user-agent"
          ) ?? undefined;

        if (!user || !user.isActive) {
          await auditLog({
            action: "LOGIN_FAILED",
            details: {
              email,
              reason: !user ? "user_not_found" : "account_disabled",
            },
            ipAddress,
            userAgent,
          });
          return null;
        }

        const passwordValid = await bcrypt.compare(password, user.passwordHash);

        if (!passwordValid) {
          await auditLog({
            userId: user.id,
            action: "LOGIN_FAILED",
            details: { email, reason: "invalid_password" },
            ipAddress,
            userAgent,
          });
          return null;
        }

        // Update lastLoginAt
        try {
          await prisma.user.update({
            where: { id: user.id },
            data: { lastLoginAt: new Date() },
          });
        } catch (error) {
          console.error("[auth] Failed to update lastLoginAt:", error);
        }

        await auditLog({
          userId: user.id,
          action: "LOGIN",
          details: { email },
          ipAddress,
          userAgent,
        });

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id as string;
        token.email = user.email as string;
        token.name = user.name as string;
        token.role = user.role as Role;
      }
      return token;
    },
    async session({ session, token }) {
      if (token && session.user) {
        session.user.id = token.id as string;
        session.user.email = token.email as string;
        session.user.name = token.name as string;
        session.user.role = token.role as Role;
      }
      return session;
    },
  },
});

export const { auth, signIn, signOut, handlers } = nextAuth;
export const { GET, POST } = handlers;

/**
 * Returns the current server-side session user, or null if unauthenticated.
 */
export async function getServerSession(): Promise<SessionUser | null> {
  const session = await auth();
  if (!session?.user?.id) return null;

  return {
    id: session.user.id,
    email: session.user.email as string,
    name: session.user.name as string,
    role: session.user.role,
  };
}

/**
 * Throws if the current user is not authenticated or lacks the required role.
 * Pass a Role or array of Roles to enforce role-based access.
 */
export async function requireAuth(
  role?: Role | Role[]
): Promise<SessionUser> {
  const user = await getServerSession();

  if (!user) {
    throw new Error("UNAUTHORIZED");
  }

  if (role !== undefined) {
    const allowedRoles = Array.isArray(role) ? role : [role];

    // ADMIN always has access
    if (!allowedRoles.includes(user.role) && user.role !== Role.ADMIN) {
      throw new Error("FORBIDDEN");
    }
  }

  return user;
}
