import { cn } from "@/lib/utils";

/**
 * Check Point logo mark.
 *
 * The pink element is a "C" shape — a circle with a concave circular bite
 * removed at the upper-right. This is achieved with a compound SVG path and
 * fillRule="evenodd": the main circle + the bite sub-path together punch the
 * concave notch into the pink fill.  The black satellite dot sits in that
 * notch.  A thin gap ring (bite r=14, dot r=12) separates them cleanly.
 *
 * Uses `currentColor` for the pink fill so the caller can override via className.
 */
export function CPLogo({ className }: { className?: string }) {
  return (
    <svg
      className={cn("text-[#EE0C5D]", className)}
      viewBox="0 0 90 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Check Point logo"
      role="img"
    >
      {/*
        Pink "C" shape.
        Outer circle: cx=36 cy=46 r=31  (top: 36,15  bottom: 36,77)
        Bite circle:  cx=62 cy=17 r=14  (top: 62,3   bottom: 62,31)
        Distance between centres ≈38.9, overlap ≈6.1 units.
        fillRule="evenodd" punches the bite out of the pink fill.
      */}
      <path
        d="M 36 15 A 31 31 0 0 1 36 77 A 31 31 0 0 1 36 15 Z
           M 62  3 A 14 14 0 0 1 62 31 A 14 14 0 0 1 62  3 Z"
        fill="currentColor"
        fillRule="evenodd"
      />

      {/* Black satellite dot — nestled in the bite, r=12 (bite r=14 ⇒ 2-unit gap ring) */}
      <circle cx="62" cy="17" r="12" fill="#231F20" />

      {/* White network connectivity icon inside the pink C */}
      {/* Connector line drawn first so nodes sit on top */}
      <line
        x1="20" y1="36" x2="38" y2="54"
        stroke="white" strokeWidth="3.5" strokeLinecap="round"
      />
      {/* Hub: open ring node */}
      <circle cx="38" cy="54" r="8.5" stroke="white" strokeWidth="3.5" fill="none" />
      {/* Diamond node (filled square rotated 45°) */}
      <polygon points="20,27 29,36 20,45 11,36" fill="white" />
    </svg>
  );
}

/**
 * Full Check Point wordmark: company name + application subtitle (no logo mark).
 */
export function CPWordmark({ className }: { className?: string }) {
  return (
    <div className={cn("flex flex-col leading-none gap-1 items-center", className)}>
      <span className="text-2xl font-black tracking-widest text-foreground uppercase">
        Check Point
        <sup className="text-[10px] font-semibold ml-0.5 align-super">™</sup>
      </span>
      <span className="text-[11px] font-medium text-muted-foreground tracking-wide">
        Cyber Security Assessment Platform
      </span>
    </div>
  );
}
