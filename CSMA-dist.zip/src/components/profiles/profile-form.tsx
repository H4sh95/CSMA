"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ProfileStatus } from "@prisma/client";

// ─── Types ─────────────────────────────────────────────────────────────────────

export type ProfileFormValues = {
  name: string;
  identifier: string;
  industry: string;
  region: string;
  country: string;
  primaryContact: string;
  primaryEmail: string;
  notes: string;
  status: ProfileStatus;
};

interface ProfileFormProps {
  defaultValues?: Partial<ProfileFormValues>;
  onSubmit: (data: ProfileFormValues) => Promise<void>;
  isLoading?: boolean;
}

type FormErrors = Partial<Record<keyof ProfileFormValues, string>>;

const INDUSTRIES = [
  "Finance",
  "Technology",
  "Healthcare",
  "Manufacturing",
  "Government",
  "Retail",
  "Education",
  "Energy",
  "Other",
] as const;

// ─── Validation ────────────────────────────────────────────────────────────────

function validate(values: ProfileFormValues): FormErrors {
  const errors: FormErrors = {};

  if (!values.name.trim()) {
    errors.name = "Name is required";
  } else if (values.name.trim().length < 2) {
    errors.name = "Name must be at least 2 characters";
  } else if (values.name.trim().length > 255) {
    errors.name = "Name must not exceed 255 characters";
  }

  if (!values.identifier.trim()) {
    errors.identifier = "Identifier is required";
  } else if (values.identifier.trim().length < 2) {
    errors.identifier = "Identifier must be at least 2 characters";
  } else if (values.identifier.trim().length > 100) {
    errors.identifier = "Identifier must not exceed 100 characters";
  } else if (!/^[a-zA-Z0-9_\-]+$/.test(values.identifier.trim())) {
    errors.identifier =
      "Identifier may only contain letters, numbers, underscores, and hyphens";
  }

  if (values.primaryEmail && values.primaryEmail.trim()) {
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(values.primaryEmail.trim())) {
      errors.primaryEmail = "Must be a valid email address";
    }
  }

  if (values.notes && values.notes.length > 5000) {
    errors.notes = "Notes must not exceed 5000 characters";
  }

  return errors;
}

// ─── Component ─────────────────────────────────────────────────────────────────

export function ProfileForm({ defaultValues, onSubmit, isLoading = false }: ProfileFormProps) {
  const router = useRouter();

  const [values, setValues] = useState<ProfileFormValues>({
    name: defaultValues?.name ?? "",
    identifier: defaultValues?.identifier ?? "",
    // "_none" is the internal sentinel for "Not specified" because
    // @radix-ui/react-select v2 forbids SelectItem value=""
    industry: defaultValues?.industry || "_none",
    region: defaultValues?.region ?? "",
    country: defaultValues?.country ?? "",
    primaryContact: defaultValues?.primaryContact ?? "",
    primaryEmail: defaultValues?.primaryEmail ?? "",
    notes: defaultValues?.notes ?? "",
    status: defaultValues?.status ?? ProfileStatus.ACTIVE,
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);

  const busy = isLoading || submitting;
  const isEditing = !!defaultValues && Object.keys(defaultValues).length > 0;

  function setField<K extends keyof ProfileFormValues>(key: K, value: ProfileFormValues[K]) {
    setValues((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) {
      setErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const newErrors = validate(values);
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit({
        ...values,
        name: values.name.trim(),
        identifier: values.identifier.trim(),
        // Convert internal sentinel back to empty string for the API
        industry: values.industry === "_none" ? "" : values.industry.trim(),
        region: values.region.trim(),
        country: values.country.trim(),
        primaryContact: values.primaryContact.trim(),
        primaryEmail: values.primaryEmail.trim(),
        notes: values.notes.trim(),
      });
    } catch {
      // Parent handles toast; just re-enable the form
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* ── Section: Basic Info ─────────────────────────────────────────── */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide">
          Basic Information
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Customer Name */}
          <div className="space-y-1.5">
            <Label htmlFor="name">
              Customer Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="name"
              placeholder="Acme Corporation"
              value={values.name}
              onChange={(e) => setField("name", e.target.value)}
              disabled={busy}
              aria-invalid={!!errors.name}
            />
            {errors.name && (
              <p className="text-xs text-destructive">{errors.name}</p>
            )}
          </div>

          {/* Identifier */}
          <div className="space-y-1.5">
            <Label htmlFor="identifier">
              Identifier <span className="text-destructive">*</span>
            </Label>
            <Input
              id="identifier"
              placeholder="acme-corp"
              value={values.identifier}
              onChange={(e) => setField("identifier", e.target.value)}
              disabled={busy}
              aria-invalid={!!errors.identifier}
            />
            {errors.identifier ? (
              <p className="text-xs text-destructive">{errors.identifier}</p>
            ) : (
              <p className="text-xs text-muted-foreground">
                Unique slug. Letters, numbers, underscores and hyphens only.
              </p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Industry */}
          <div className="space-y-1.5">
            <Label htmlFor="industry">Industry</Label>
            <Select
              value={values.industry}
              onValueChange={(val) => setField("industry", val)}
              disabled={busy}
            >
              <SelectTrigger id="industry">
                <SelectValue placeholder="Select industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="_none">Not specified</SelectItem>
                {INDUSTRIES.map((ind) => (
                  <SelectItem key={ind} value={ind}>
                    {ind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Status */}
          <div className="space-y-1.5">
            <Label htmlFor="status">Status</Label>
            <Select
              value={values.status}
              onValueChange={(val) => setField("status", val as ProfileStatus)}
              disabled={busy}
            >
              <SelectTrigger id="status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ProfileStatus.ACTIVE}>Active</SelectItem>
                <SelectItem value={ProfileStatus.INACTIVE}>Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Region */}
          <div className="space-y-1.5">
            <Label htmlFor="region">Region</Label>
            <Input
              id="region"
              placeholder="e.g. EMEA, North America"
              value={values.region}
              onChange={(e) => setField("region", e.target.value)}
              disabled={busy}
            />
          </div>

          {/* Country */}
          <div className="space-y-1.5">
            <Label htmlFor="country">Country</Label>
            <Input
              id="country"
              placeholder="e.g. United Kingdom"
              value={values.country}
              onChange={(e) => setField("country", e.target.value)}
              disabled={busy}
            />
          </div>
        </div>
      </div>

      {/* ── Section: Contact ─────────────────────────────────────────────── */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide">
          Primary Contact
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Contact name */}
          <div className="space-y-1.5">
            <Label htmlFor="primaryContact">Contact Name</Label>
            <Input
              id="primaryContact"
              placeholder="Jane Smith"
              value={values.primaryContact}
              onChange={(e) => setField("primaryContact", e.target.value)}
              disabled={busy}
            />
          </div>

          {/* Contact email */}
          <div className="space-y-1.5">
            <Label htmlFor="primaryEmail">Contact Email</Label>
            <Input
              id="primaryEmail"
              type="email"
              placeholder="jane@example.com"
              value={values.primaryEmail}
              onChange={(e) => setField("primaryEmail", e.target.value)}
              disabled={busy}
              aria-invalid={!!errors.primaryEmail}
            />
            {errors.primaryEmail && (
              <p className="text-xs text-destructive">{errors.primaryEmail}</p>
            )}
          </div>
        </div>
      </div>

      {/* ── Section: Notes ───────────────────────────────────────────────── */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide">
          Additional Information
        </h3>
        <div className="space-y-1.5">
          <Label htmlFor="notes">Notes</Label>
          <Textarea
            id="notes"
            placeholder="Any additional context about this customer…"
            rows={4}
            value={values.notes}
            onChange={(e) => setField("notes", e.target.value)}
            disabled={busy}
          />
          {errors.notes && (
            <p className="text-xs text-destructive">{errors.notes}</p>
          )}
        </div>
      </div>

      {/* ── Actions ──────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-end gap-3 pt-2 border-t">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.push("/profiles")}
          disabled={busy}
        >
          Cancel
        </Button>
        <Button type="submit" disabled={busy}>
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}
          {isEditing ? "Save changes" : "Create profile"}
        </Button>
      </div>
    </form>
  );
}
