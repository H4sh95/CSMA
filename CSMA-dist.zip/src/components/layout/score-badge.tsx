import * as React from "react";
import { cn } from "@/lib/utils";

interface ScoreBadgeProps {
  percentage: number | null | undefined;
  showLabel?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
}

type ScoreTier = {
  label: string;
  className: string;
};

function getScoreTier(percentage: number): ScoreTier {
  if (percentage < 20) {
    return {
      label: "Critical",
      className: "bg-red-100 text-red-800 border-red-200",
    };
  }
  if (percentage < 40) {
    return {
      label: "Low",
      className: "bg-orange-100 text-orange-800 border-orange-200",
    };
  }
  if (percentage < 60) {
    return {
      label: "Moderate",
      className: "bg-yellow-100 text-yellow-800 border-yellow-200",
    };
  }
  if (percentage < 80) {
    return {
      label: "Good",
      className: "bg-green-100 text-green-800 border-green-200",
    };
  }
  return {
    label: "Excellent",
    className: "bg-emerald-100 text-emerald-800 border-emerald-200",
  };
}

const sizeClasses = {
  sm: "px-2 py-0.5 text-xs",
  md: "px-2.5 py-0.5 text-sm",
  lg: "px-3 py-1 text-base",
};

export function ScoreBadge({
  percentage,
  showLabel = false,
  size = "md",
  className,
}: ScoreBadgeProps) {
  if (percentage === null || percentage === undefined) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1 rounded-full border font-medium",
          "bg-gray-100 text-gray-600 border-gray-200",
          sizeClasses[size],
          className
        )}
      >
        N/A
      </span>
    );
  }

  const tier = getScoreTier(percentage);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border font-medium",
        tier.className,
        sizeClasses[size],
        className
      )}
    >
      {percentage.toFixed(1)}%
      {showLabel && (
        <span className="opacity-75">· {tier.label}</span>
      )}
    </span>
  );
}

export function getScoreLabel(percentage: number | null | undefined): string {
  if (percentage === null || percentage === undefined) return "N/A";
  return getScoreTier(percentage).label;
}
