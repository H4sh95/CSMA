"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import {
  LayoutDashboard,
  Users,
  FileSpreadsheet,
  ClipboardList,
  BarChart3,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  roles?: string[];
}

const NAV_ITEMS: NavItem[] = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    label: "Profiles",
    href: "/profiles",
    icon: Users,
    roles: ["ADMIN", "ASSESSOR"],
  },
  {
    label: "Templates",
    href: "/templates",
    icon: FileSpreadsheet,
    roles: ["ADMIN", "ASSESSOR"],
  },
  {
    label: "Assessments",
    href: "/assessments",
    icon: ClipboardList,
    roles: ["ADMIN", "ASSESSOR"],
  },
  {
    label: "Results",
    href: "/results",
    icon: BarChart3,
  },
  {
    label: "Admin",
    href: "/admin",
    icon: Settings,
    roles: ["ADMIN"],
  },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle?: () => void;
}

function getInitials(name?: string | null): string {
  if (!name) return "?";
  return name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const userRole = (session?.user as { role?: string } | undefined)?.role;

  const visibleNavItems = NAV_ITEMS.filter(
    (item) => !item.roles || (userRole && item.roles.includes(userRole))
  );

  return (
    <TooltipProvider delayDuration={0}>
      <aside
        className={cn(
          "flex h-full flex-col border-r transition-all duration-300",
          "bg-[hsl(var(--sidebar-background))] text-[hsl(var(--sidebar-foreground))]",
          "border-[hsl(var(--sidebar-border))]",
          collapsed ? "w-16" : "w-64"
        )}
      >
        {/* Logo / App name */}
        <div
          className={cn(
            "flex h-16 items-center border-b border-[hsl(var(--sidebar-border))]",
            collapsed ? "justify-center px-3" : "gap-2.5 px-4"
          )}
        >
            {collapsed ? (
            <span className="text-[11px] font-black tracking-widest text-[hsl(var(--sidebar-foreground))] uppercase opacity-80">
              CP
            </span>
          ) : (
            <div className="min-w-0 flex-1">
              <p className="text-sm font-black leading-tight text-[hsl(var(--sidebar-foreground))] tracking-widest uppercase">
                Check Point
              </p>
              <p className="text-[10px] font-medium leading-tight text-[hsl(var(--sidebar-foreground))] opacity-60 tracking-wide uppercase">
                Cyber Security
              </p>
            </div>
          )}

          {!collapsed && onToggle && (
            <button
              onClick={onToggle}
              className="ml-auto rounded-md p-1 text-[hsl(var(--sidebar-foreground))] opacity-50 hover:opacity-100 hover:bg-[hsl(var(--sidebar-accent))] transition-colors shrink-0"
              aria-label="Collapse sidebar"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
          )}
          {collapsed && onToggle && (
            <button
              onClick={onToggle}
              className="absolute right-0 translate-x-1/2 top-[3.5rem] z-10 hidden md:flex h-5 w-5 items-center justify-center rounded-full border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-background))] text-[hsl(var(--sidebar-foreground))] opacity-70 hover:opacity-100 transition-colors"
              aria-label="Expand sidebar"
            >
              <ChevronRight className="h-3 w-3" />
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-2">
            {visibleNavItems.map((item) => {
              const isActive =
                pathname === item.href ||
                (item.href !== "/dashboard" && pathname.startsWith(item.href));
              const Icon = item.icon;

              const linkContent = (
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    collapsed && "justify-center px-2",
                    isActive
                      ? "bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]"
                      : "text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-accent-foreground))]"
                  )}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  {!collapsed && <span>{item.label}</span>}
                </Link>
              );

              return (
                <li key={item.href}>
                  {collapsed ? (
                    <Tooltip>
                      <TooltipTrigger asChild>{linkContent}</TooltipTrigger>
                      <TooltipContent side="right">{item.label}</TooltipContent>
                    </Tooltip>
                  ) : (
                    linkContent
                  )}
                </li>
              );
            })}
          </ul>
        </nav>

        {/* User section */}
        <div className="border-t border-[hsl(var(--sidebar-border))] p-3">
          {collapsed ? (
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => signOut({ callbackUrl: "/login" })}
                  className="flex w-full items-center justify-center rounded-md p-2 text-[hsl(var(--sidebar-foreground))] opacity-70 hover:opacity-100 hover:bg-[hsl(var(--sidebar-accent))] transition-colors"
                  aria-label="Sign out"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="right">Sign out</TooltipContent>
            </Tooltip>
          ) : (
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarImage src={session?.user?.image ?? undefined} />
                <AvatarFallback className="bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))] text-xs">
                  {getInitials(session?.user?.name)}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-[hsl(var(--sidebar-foreground))]">
                  {session?.user?.name ?? "User"}
                </p>
                <p className="truncate text-xs text-[hsl(var(--sidebar-foreground))] opacity-60">
                  {session?.user?.email ?? ""}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0 text-[hsl(var(--sidebar-foreground))] opacity-60 hover:opacity-100 hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-foreground))]"
                onClick={() => signOut({ callbackUrl: "/login" })}
                aria-label="Sign out"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </aside>
    </TooltipProvider>
  );
}
